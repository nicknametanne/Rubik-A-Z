import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, access } from 'node:fs/promises';
import { join } from 'node:path';

const root = new URL('../', import.meta.url);
const read = relative => readFile(new URL(relative, root), 'utf8');

test('PWA manifest has a valid app identity, relative scope and install icons', async () => {
  const manifest = JSON.parse(await read('manifest.webmanifest'));
  assert.equal(manifest.name, 'Rubik Universe');
  assert.equal(manifest.start_url, './');
  assert.equal(manifest.scope, './');
  assert.equal(manifest.display, 'standalone');
  for (const icon of manifest.icons) await access(new URL(icon.src.replace(/^\.\//, ''), root));
});

test('Service worker pre-caches all local app modules', async () => {
  const worker = await read('sw.js');
  const required = ['index.html', 'styles.css', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png', 'src/app.js', 'src/core.js', 'src/cfop-data.js', 'src/cube.js', 'src/solver.js', 'src/solver-worker.js', 'src/knowledge-data.js'];
  for (const path of required) {
    assert.ok(worker.includes(`'./${path}'`), `Service worker misses ${path}`);
    await access(new URL(path, root));
  }
});

test('GitHub Pages workflow supports ZIP upload and direct source deployment', async () => {
  const workflow = await read('.github/workflows/deploy-pages.yml');
  assert.ok(workflow.includes("actions/checkout@v6"));
  assert.ok(workflow.includes('Rubik-Universe-v5.5*.zip'));
  assert.ok(workflow.includes('actions/upload-pages-artifact@v4'));
  assert.ok(workflow.includes('actions/deploy-pages@v4'));
  assert.ok(workflow.includes('pages: write'));
  assert.ok(workflow.includes('id-token: write'));
  assert.ok(workflow.includes('ready=false'));
  assert.ok(workflow.includes("steps.prepare.outputs.ready == 'true'"));
  assert.ok(workflow.includes('No Rubik Universe ZIP or source files yet'));
});
