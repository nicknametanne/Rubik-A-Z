const CACHE_NAME = 'rubik-universe-v14-0';
const APP_SHELL = [
  './', './index.html', './styles.css', './manifest.webmanifest', './icon.svg',
  './icon-192.png', './icon-512.png', './src/app.js', './src/core.js',
  './src/academy-data.js', './src/methods-data.js', './src/scramble-generator.js', './src/cfop-data.js', './src/cube.js', './src/cube3d.js', './src/analytics.js', './src/solver.js',
  './src/solver-worker.js', './src/smart-cube.js', './src/smart-cube-core.js', './src/knowledge-data.js', './src/cfop-visuals.js', './src/multi-scramble.js'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(
    keys.filter(key => key.startsWith('rubik-universe-') && key !== CACHE_NAME).map(key => caches.delete(key))
  )).then(() => self.clients.claim()));
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).then(response => {
      if (response.ok) caches.open(CACHE_NAME).then(cache => cache.put('./index.html', response.clone()));
      return response;
    }).catch(() => caches.match('./index.html')));
    return;
  }

  // Network-first avoids pinning an old JS/CSS file after a Pages deployment.
  event.respondWith(fetch(request).then(response => {
    if (response.ok) {
      const copy = response.clone();
      caches.open(CACHE_NAME).then(cache => cache.put(request, copy));
    }
    return response;
  }).catch(async () => {
    const cached = await caches.match(request);
    if (cached) return cached;
    throw new Error(`No cached response for ${request.url}`);
  }));
});
