# Hướng dẫn đưa Rubik Universe V14 lên GitHub Pages

## 1. Tệp cần dùng

- `Rubik-Universe-V14.zip`: gói website nguồn.
- `Rubik-Universe-V14-GitHub-Upload-Kit.zip`: gói GitHub gồm website, mã nguồn, test, README và workflow Pages.

## 2. Đưa lên repository hiện tại

1. Mở repository Rubik Universe trên GitHub.
2. Giải nén `Rubik-Universe-V14-GitHub-Upload-Kit.zip` trên máy tính.
3. Vào repository, chọn **Add file → Upload files**.
4. Kéo toàn bộ nội dung đã giải nén (không kéo thư mục bao ngoài) vào repository, cho phép ghi đè các tệp V13 tương ứng.
5. Giữ thư mục `.github/workflows/` và các thư mục `src/`, `tests/`.
6. Commit thay đổi vào nhánh `main`.
7. Mở tab **Actions**, đợi workflow `Publish Rubik Universe to GitHub Pages` hoàn tất.

Workflow ưu tiên ZIP V14 nếu bạn upload ZIP vào repository; nếu upload trực tiếp file nguồn thì workflow dùng `index.html`, `styles.css`, `src/` và các asset tại root.

## 3. Sau khi deploy

- Mở website bằng HTTPS (GitHub Pages có HTTPS), reload cứng một lần để Service Worker nhận cache V14 mới.
- Dùng Chrome hoặc Edge trên máy tính để mở **Smart Cube Arena**.
- Chờ trạng thái driver đa hãng sẵn sàng rồi mới bấm **Kết nối cube**. Khi hộp thoại Bluetooth xuất hiện, chọn đúng cube và cấp quyền.
- Mỗi cube kết nối bằng một lần bấm riêng. GAN Smart Timer có nút kết nối riêng. Chỉ FACELETS có `source: "device"` mới được dùng tự động xác minh solved. Nếu cube không cung cấp FACELETS từ phần cứng, hãy dừng thủ công; Local/Online Arena sẽ không xác định người thắng nếu chưa xác minh solved.
- Để thi đấu Online: người tạo phòng gửi mã Offer, người tham gia tạo mã Answer rồi gửi ngược lại; người tạo phòng dán Answer và nhấn nhận mã. Hai bên dùng cùng scramble.

## 4. Lưu ý

- Không cần build npm để chạy website tĩnh. Có thể kiểm tra mã nguồn bằng `npm test`.
- Driver Smart Cube được tải từ `https://esm.sh/smartcube-web-bluetooth@4.1.0?bundle`, vì vậy cần Internet khi mở Smart Cube Arena lần đầu.
- Web Bluetooth không chạy khi mở `file://`; cần HTTPS hoặc localhost và browser hỗ trợ.
- Không phải mọi model / firmware đều tương thích. Xem bảng hỗ trợ và giới hạn trong README.
- Online Arena hiện trao đổi mã Offer / Answer thủ công, chưa có server signaling, tài khoản, matchmaking tự động hoặc TURN relay.
- Lượt solve, replay và cài đặt lưu local trên từng trình duyệt. Hãy xuất backup JSON trước khi xóa cache / dữ liệu trang.
- Online Arena hiện là đấu giao lưu: hai trình duyệt tự khai báo kết quả, chưa có anti-cheat hoặc xác thực máy chủ. Không dùng timer / replay Smart Cube này như hệ thống đo thời gian WCA chính thức.
