import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import {
  normalizeSmartMove, isSolvedFacelets, normalizeMoveHistory,
  analyzeMoveHistory, createReplayRecord, encodeSignalDescription,
  decodeSignalDescription
} from '../src/smart-cube-core.js';

const read = relative => readFile(new URL(`../${relative}`, import.meta.url), 'utf8');

test('V14 Smart Cube normalizes valid face moves and whole-cube rotations only', () => {
  assert.equal(normalizeSmartMove('R'), 'R');
  assert.equal(normalizeSmartMove("U’"), "U'");
  assert.equal(normalizeSmartMove({ notation: 'F2' }), 'F2');
  assert.equal(normalizeSmartMove('x'), 'x');
  assert.equal(normalizeSmartMove('Rw'), null);
  assert.equal(normalizeSmartMove('R U'), null);
  assert.equal(normalizeSmartMove('Q'), null);
});

test('V14 solved facelet detection supports both 3x3 and 2x2 sticker strings', () => {
  const solved3 = 'U'.repeat(9) + 'R'.repeat(9) + 'F'.repeat(9) + 'D'.repeat(9) + 'L'.repeat(9) + 'B'.repeat(9);
  const solved2 = 'U'.repeat(4) + 'R'.repeat(4) + 'F'.repeat(4) + 'D'.repeat(4) + 'L'.repeat(4) + 'B'.repeat(4);
  assert.equal(isSolvedFacelets(solved3), true);
  assert.equal(isSolvedFacelets(solved2), true);
  assert.equal(isSolvedFacelets(solved3.slice(1) + 'R'), false);
  assert.equal(isSolvedFacelets('U'.repeat(53)), false);
});

test('V14 move history filters malformed entries and retains time order', () => {
  const moves = normalizeMoveHistory([{ move: 'R', t: 300 }, { move: 'U', t: 100 }, { move: 'Bad', t: 200 }, { move: 'F2', t: 500 }]);
  assert.deepEqual(moves, [{ move: 'U', t: 100 }, { move: 'R', t: 300 }, { move: 'F2', t: 500 }]);
});

test('V14 replay analysis calculates TPS, face counts and pauses from real timestamps', () => {
  const result = analyzeMoveHistory([
    { move: 'U', t: 100 }, { move: 'R', t: 200 },
    { move: 'F', t: 1400 }, { move: "U'", t: 1500 }, { move: 'x', t: 1600 }
  ], 2000);
  assert.equal(result.moveCount, 5);
  assert.equal(result.tps, 2.5);
  assert.equal(result.pauseCount, 1);
  assert.equal(result.largestPauseMs, 1200);
  assert.equal(result.faces.U, 2);
  assert.equal(result.faces.R, 1);
  assert.equal(result.faces.rotations, 1);
});

test('V14 replay records reject missing turns and preserve scramble / device metadata', () => {
  assert.throws(() => createReplayRecord({ rawMs: 15000, moves: [] }), /ít nhất một move/i);
  const record = createReplayRecord({
    id: 'smart-test', puzzle: '3x3', cubeName: 'GAN Test', brand: 'GAN',
    serial: 'serial-1', scramble: 'R U R\'', rawMs: 15000,
    moves: [{ move: 'R', t: 10 }, { move: 'U', t: 20 }]
  });
  assert.equal(record.id, 'smart-test');
  assert.equal(record.serial, 'serial-1');
  assert.equal(record.moves.length, 2);
  assert.equal(record.stats.tps, 2 / 15);
});

test('V14 WebRTC signaling code validates offers, answers and payload size', () => {
  const offer = { type: 'offer', sdp: 'v=0\r\no=- 1 2 IN IP4 127.0.0.1\r\n' };
  const code = encodeSignalDescription(offer);
  assert.deepEqual(decodeSignalDescription(code, 'offer'), offer);
  assert.throws(() => decodeSignalDescription(code, 'answer'), /mã trả lời/i);
  assert.throws(() => decodeSignalDescription('{bad json}'), /JSON/i);
  assert.throws(() => encodeSignalDescription({ type: 'offer', sdp: 'bad' }), /không hợp lệ/i);
});

test('V14 UI is wired into primary navigation, data persistence, replay visualizer and peer arena', async () => {
  const html = await read('index.html');
  const app = await read('src/app.js');
  const module = await read('src/smart-cube.js');
  assert.ok(html.includes('data-page="smartcube"'));
  assert.ok(html.includes('id="page-smartcube"'));
  assert.ok(html.includes('sc-create-invite'));
  assert.ok(html.includes('sc-connect-p1'));
  assert.ok(app.includes("import { initSmartCubeFeatures, refreshSmartCubePage } from './smart-cube.js'"));
  assert.ok(app.includes('data.smartCube.replays'));
  assert.ok(app.includes('loadVisualizerSequence(sequence'));
  assert.ok(module.includes('smartcube-web-bluetooth@4.1.0'));
  assert.ok(module.includes('connectSmartCube()'));
  assert.ok(module.includes('connectGanTimer()'));
  assert.ok(module.includes('RTCPeerConnection'));
  assert.ok(module.includes('createReplayRecord'));
});

test('V14 service worker caches Smart Cube modules with a fresh cache key', async () => {
  const worker = await read('sw.js');
  assert.ok(worker.includes('rubik-universe-v14-0'));
  assert.ok(worker.includes("'./src/smart-cube.js'"));
  assert.ok(worker.includes("'./src/smart-cube-core.js'"));
});


test('V14 auto-solve requires a physical FACELETS snapshot, not reconstructed move state', async () => {
  const source = await readFile(new URL('../src/smart-cube.js', import.meta.url), 'utf8');
  assert.match(source, /event\.source === 'device' && isSolvedFacelets\(event\.facelets\)/);
  assert.match(source, /physical device snapshot/i);
});
