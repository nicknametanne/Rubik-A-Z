import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { CFOP_CASES } from '../src/cfop-data.js';
import { isValidNotation } from '../src/core.js';
import { renderCfopCaseDiagram } from '../src/cfop-visuals.js';
import {
  METHOD_LIBRARIES, ALL_METHOD_CASES, BEGINNER_CASES, ROUX_CMLL_CASES,
  ROUX_LSE_CASES, TWO_LOOK_OLL_CASES, TWO_LOOK_PLL_CASES, TWO_LOOK_CASES,
  ZZ_CASES, PETRUS_CASES
} from '../src/methods-data.js';

const read = relative => readFile(new URL(`../${relative}`, import.meta.url), 'utf8');

test('V11 standard method libraries contain the expected complete two-step sets', () => {
  assert.equal(BEGINNER_CASES.length, 8);
  assert.equal(ROUX_CMLL_CASES.length, 42);
  assert.equal(ROUX_LSE_CASES.length, 15);
  assert.equal(METHOD_LIBRARIES.roux.cases.length, 57);
  assert.equal(ZZ_CASES.length, 28);
  assert.equal(PETRUS_CASES.length, 28);
  assert.equal(TWO_LOOK_OLL_CASES.length, 10);
  assert.equal(TWO_LOOK_PLL_CASES.length, 6);
  assert.equal(TWO_LOOK_CASES.length, 16);
  assert.equal(METHOD_LIBRARIES.zz.cases.length, 28);
  assert.equal(METHOD_LIBRARIES.petrus.cases.length, 28);
});

test('Every standard case has a unique ID, full valid notation and learning metadata', () => {
  const all = [...ALL_METHOD_CASES, ...TWO_LOOK_CASES];
  assert.equal(new Set(all.map(item => item.id)).size, all.length);
  for (const item of all) {
    assert.ok(item.name, `${item.id} needs a name`);
    assert.ok(item.moves, `${item.id} needs a formula`);
    assert.ok(isValidNotation(item.moves), `${item.id} has invalid notation: ${item.moves}`);
    assert.ok(item.recognition, `${item.id} needs recognition guidance`);
    assert.ok(item.grip, `${item.id} needs grip guidance`);
    assert.ok(item.tips, `${item.id} needs execution tips`);
    assert.ok(item.mistakes, `${item.id} needs common-mistake guidance`);
    assert.ok(item.source, `${item.id} needs a source reference`);
  }
});

test('Every algorithm case produces a valid SVG case illustration without fallback', () => {
  const all = [...CFOP_CASES, ...ALL_METHOD_CASES, ...TWO_LOOK_CASES];
  const diagrams = all.map(item => renderCfopCaseDiagram(item));
  assert.equal(diagrams.length, 119 + ALL_METHOD_CASES.length + 16);
  assert.ok(diagrams.every(markup => markup.includes('<svg')));
  assert.ok(diagrams.every(markup => !markup.includes('case-diagram-fallback')));
  const lse = ALL_METHOD_CASES.filter(item => item.type === 'LSE').map(item => renderCfopCaseDiagram(item));
  for (const label of ['UL', 'UR', 'UF', 'UB', 'DF', 'DB']) assert.ok(lse.every(markup => markup.includes(`>${label}<`)), `LSE diagram misses ${label}`);
});

test('Method roadmaps describe intuitive stages and list advantages, limits and learning tips', () => {
  for (const [id, method] of Object.entries(METHOD_LIBRARIES)) {
    assert.ok(method.description, `${id} description`);
    assert.ok(method.stages.length >= 4, `${id} roadmap`);
    assert.ok(method.pros.length >= 2, `${id} advantages`);
    assert.ok(method.cons.length >= 2, `${id} limitations`);
    assert.ok(method.learningTips.length >= 3, `${id} learning tips`);
    assert.ok(method.sources.length > 0, `${id} sources`);
    assert.ok(method.stages.every(stage => stage.name && stage.description && stage.recognition && stage.grip && stage.tips));
  }
  assert.ok(METHOD_LIBRARIES.roux.stages.some(stage => stage.id === 'fb' && stage.kind === 'intuitive'));
  assert.ok(METHOD_LIBRARIES.zz.stages.some(stage => stage.id === 'eo' && stage.kind === 'intuitive'));
  assert.ok(METHOD_LIBRARIES.petrus.stages.some(stage => stage.id === '222' && stage.kind === 'intuitive'));
});

test('2-Look OLL/PLL is nested in CFOP library and exposed in Trainer separately', async () => {
  const html = await read('index.html');
  const app = await read('src/app.js');
  const cfop = await read('src/cfop-data.js');
  const cfopStart = html.indexOf('id="case-library"');
  const cfopEnd = html.indexOf('id="method-library"');
  const cfopSection = html.slice(cfopStart, cfopEnd);
  assert.ok(cfopSection.includes('id="two-look-library"'));
  assert.ok(html.includes('data-library-mode="beginner"'));
  assert.ok(html.includes('data-library-mode="roux"'));
  assert.ok(html.includes('data-library-mode="zz"'));
  assert.ok(html.includes('data-library-mode="petrus"'));
  assert.ok(app.includes('data-method-progress-filter'));
  assert.ok(app.includes('activeMethodProgressFilter'));
  assert.equal((html.match(/<option value="2LOOK">/g) || []).length, 1);
  assert.ok(app.includes("else if (type === '2LOOK') selected = TWO_LOOK_CASES"));
  assert.ok(app.includes("selectedType === '2LOOK' ? TWO_LOOK_CASES"));
  assert.ok(!cfop.includes('twoLook: number >= 21'));
  assert.ok(!cfop.includes("twoLook: ['Ua', 'Ub', 'H', 'Z', 'T', 'Y'].includes(name)"));
});

test('V11 caches method data for offline use and announces V11 metadata', async () => {
  const sw = await read('sw.js');
  const manifest = JSON.parse(await read('manifest.webmanifest'));
  const pkg = JSON.parse(await read('package.json'));
  assert.ok(sw.includes('rubik-universe-v14-0'));
  assert.ok(sw.includes("'./src/methods-data.js'"));
  assert.equal(manifest.description.includes('V14'), true);
  assert.equal(pkg.version, '14.0.0');
});
