# Rubik Universe V14 — V13 + Smart Cube Arena

Rubik Universe là workspace speedcubing chạy bằng HTML/CSS/JavaScript ES Modules thuần. Không cần framework hoặc bước build. Bản V14 giữ toàn bộ tính năng V13 và bổ sung Smart Cube Arena V14.1–V14.6. Dữ liệu local cũ tiếp tục dùng khóa `rubik-universe-v1`; không có thao tác xóa hay đổi khóa khi nâng cấp.


## V14 — Smart Cube Arena (V14.1 → V14.6)

### V14.1 — Bluetooth Core
- Kết nối / ngắt kết nối hai Smart Cube độc lập bằng Web Bluetooth; xin quyền thiết bị theo hộp thoại của trình duyệt.
- Nhận sự kiện MOVE, FACELETS, BATTERY, GYRO; lưu tên thiết bị, hãng và serial nếu driver cung cấp.
- Driver `smartcube-web-bluetooth@4.1.0` được tải động từ esm.sh, không nhúng mã nguồn hoặc firmware của cube vào dự án.

### V14.2 — Smart Timer
- Timer tự bắt đầu ở move đầu tiên sau khi người dùng bấm Sẵn sàng; dừng khi driver gửi FACELETS trạng thái solved hoặc người dùng dừng thủ công.
- Hỗ trợ GAN Smart Timer / GAN Halo Smart Timer qua Bluetooth; ưu tiên `recordedTime.asTimestamp` từ thiết bị, chỉ dự phòng đồng hồ trình duyệt khi thiếu trường đó.
- Solve được ghi vào session hiện tại cùng puzzle, scramble, thiết bị và ghi chú nguồn Smart Cube.

### V14.3 — Multi-brand
- Driver upstream ghi nhận GAN Gen1–Gen4 2×2/3×3, MoYu AI 2023, MHC, WRM WCU_MY3, WeiPo V5 AI 2×2, QiYi Smart Cube, X-Man Tornado V4, Giiker/Xiaomi và GoCube/Rubik Connected.
- Tương thích phụ thuộc đúng model, firmware, quảng bá Bluetooth và khả năng của trình duyệt. Không thể suy ra mọi cube của cùng thương hiệu đều có Smart Bluetooth.

### V14.4 — Local Battle
- Kết nối hai cube cùng một máy, dùng chung scramble 2×2 / 3×3, chạy timer riêng, theo dõi move, trạng thái và thời gian của từng người.
- Kết quả Local Battle chỉ công nhận người thắng khi cả hai cube xác minh trạng thái solved bằng FACELETS; nếu phải dừng thủ công thì vẫn lưu thời gian nhưng không tuyên bố kết quả thắng/thua. Mỗi solve lưu độc lập.

### V14.5 — Online Arena
- Kênh dữ liệu WebRTC P2P truyền READY / START / MOVE / SOLVED / SCRAMBLE và bảng điểm đối thủ.
- Tạo mã Offer, người chơi còn lại tạo Answer, sau đó trao đổi mã qua kênh riêng và xác nhận Answer. Không cần server tài khoản trong bản này.
- Dùng STUN công cộng để thử kết nối; một số NAT / firewall cần TURN server riêng. Không có matchmaking tự động, phòng công khai hay hệ thống chống gian lận.

### V14.6 — Replay & Analysis
- Lưu tối đa 100 Smart Cube replay local với scramble, thiết bị, serial (nếu có), move, timestamp, thời gian và session solve ID.
- Timeline, TPS trung bình, số move, khoảng pause ≥ 0.9 giây, pause dài nhất và tần suất từng mặt; xuất replay JSON.
- Replay 3×3 mở trong Rubik 3D Visualizer; 2×2 có timeline / thống kê nhưng chưa dựng lại bằng mô hình 2×2 riêng.

### Giới hạn cần biết
- Web Bluetooth yêu cầu HTTPS hoặc localhost, quyền truy cập do người dùng cấp và trình duyệt hỗ trợ. Chrome / Edge desktop là lựa chọn phù hợp; Firefox / Safari không được hỗ trợ phổ quát.
- Để bảo đảm user activation, driver được preload khi mở ứng dụng và nút kết nối chỉ hoạt động sau khi driver sẵn sàng. Kết nối Bluetooth thực tế vẫn cần cube ở gần và chưa bị ứng dụng khác giữ kết nối.
- Move timestamp trong Smart Cube hiện được ghi theo lúc trình duyệt nhận thông báo BLE. Độ trễ / clock skew phụ thuộc firmware; số liệu replay thích hợp cho luyện tập, không được gắn nhãn thành tích WCA chính thức.
- Một số cube 2×2 dùng U/R/F axis aliases cho các mặt đối diện; timeline thể hiện notation do driver phát. Kiểm tra trạng thái FACELETS vật lý vẫn được ưu tiên cho auto-finish.
- Online P2P cần trao đổi mã thủ công và mạng cho phép ICE; không có server signaling / TURN tích hợp sẵn.
- Smart Cube module cần Internet lần đầu để tải driver ESM từ CDN; website core còn lại vẫn hoạt động riêng.

## Điểm mới của V12 + V13

### V12 — phân tích dữ liệu luyện tập
- Bộ lọc Statistics theo session, puzzle và khoảng ngày; xuất CSV dùng cùng bộ lọc.
- Best Ao100, Current Ao50 và tổng hợp xu hướng theo tuần/tháng.
- Giữ nguyên dữ liệu solve/session và cách lưu cục bộ.

### V13 — Rubik 3D và mô phỏng case
- Mô hình 3×3 dựng từ 26 cubie hiển thị riêng, mỗi cubie có đủ sáu mặt với hướng sticker tương ứng.
- Nút **3D** trong thư viện mở thẳng trạng thái case được dựng bằng công thức nghịch đảo; không hiển thị danh sách move làm màn hình mở đầu.
- Thông tin nhận diện, hướng cầm, tips và công thức được hiển thị cùng trạng thái case.
- Nút **Phát công thức từ trạng thái case** chuyển sang chế độ sequence, xoay từng lớp cubie bằng CSS animation rồi đồng bộ với cube engine.
- Hỗ trợ kéo/ vuốt để đổi góc nhìn, zoom, đặt lại góc nhìn và tự co giãn kích thước theo vùng hiển thị.
- Sửa flattening của CSS 3D, hướng mặt U/D và góc animation khi quy đổi từ tọa độ cube sang tọa độ màn hình.

## Các chức năng tiếp tục được giữ
- Timer, Inspection, +2/DNF, Session Manager và lịch sử solve.
- Scramble Center cho 11 loại puzzle; scramble practice được phân biệt với scramble random-state chính thức.
- Statistics, biểu đồ, Solver 3×3 và kiểm chứng lời giải.
- CFOP 119 case; khu 2-Look OLL/PLL riêng trong CFOP; công thức cá nhân.
- Beginner, Roux, ZZ và Petrus; Algorithm Trainer, Academy và lặp lại ngắt quãng.
- Thư viện kiến thức, tìm kiếm, Settings, backup/restore, PWA và offline cache.

## Cách hoạt động của 3D

Mô hình sử dụng `src/cube.js` làm nguồn sự thật cho vị trí sticker, hướng sticker và các move. `src/cube3d.js` nhóm 54 sticker thành 26 cubie, dựng sáu mặt cho mỗi cubie và nhóm đúng lớp đang chuyển động. Animation là lớp hiển thị trước khi trạng thái move được commit bằng cube engine; vì vậy trạng thái sau animation và trạng thái thuật toán dùng cùng một phép xoay. Bộ chuyển động hỗ trợ face turns, wide turns, slice turns, whole-cube rotations và các lớp `2R` / `3Rw` trong phạm vi mô hình 3×3.

Khi mở một case, trạng thái được tái tạo bằng inverse formula từ cube đã giải. Đây là trạng thái minh họa theo chính công thức lưu trong case; nếu công thức tùy chỉnh bị sửa sai, hình 3D cũng sẽ thể hiện trạng thái theo công thức mới đó.

## Giữ dữ liệu & tương thích

- LocalStorage key vẫn là `rubik-universe-v1`; không đổi khóa lưu dữ liệu.
- Migration hiện tại giữ session, solve, thuật toán cá nhân, tiến độ case, mục tiêu luyện tập và bản nháp Solver cũ.
- Cache Service Worker được nâng lên `rubik-universe-v14-0`, precache thêm `src/smart-cube.js` và `src/smart-cube-core.js`.
- Dữ liệu solve/session/thuật toán vẫn lưu trên trình duyệt hiện tại; không có đồng bộ cloud. Hãy xuất JSON backup trước khi cập nhật.

## Chạy local trên Windows

1. Giải nén `Rubik-Universe-V14.zip`.
2. Mở Terminal trong thư mục có `index.html`.
3. Chạy `py -m http.server 8080`.
4. Mở `http://localhost:8080`.

Không mở bằng `file://`; ứng dụng dùng ES Modules, Worker và Service Worker.

## Kiểm thử

Yêu cầu Node.js 18+; chạy:

```bash
npm test
```

Bộ test bao gồm tính đúng đắn move engine, 26 cubie, lớp xoay, hướng mặt U/D, preview case từ inverse formula, thống kê, dữ liệu cũ, thuật toán, scramble, PWA và workflow. Ở lần đóng gói V14, `npm test` đạt **73/73**. Các bài test chạy bằng Node.js; chưa hoàn tất E2E trên trình duyệt thực và chưa kiểm thử Bluetooth với phần cứng thật. Việc hỗ trợ một dòng cube theo tài liệu upstream không thay thế bước thử trực tiếp đúng model / firmware.

## Cập nhật GitHub Pages

Xem `HUONG-DAN-GITHUB-V14.md`. Không cần repository mới: upload nội dung của `Rubik-Universe-V14-GitHub-Upload-Kit.zip` vào thư mục gốc repository, ghi đè các tệp cũ tương ứng và commit. Workflow `.github/workflows/deploy-pages.yml` sẽ ưu tiên `Rubik-Universe-V14.zip` nếu có trong thư mục gốc.

## Nguồn và giấy phép

Các nguồn thuật toán phương pháp nằm trong `src/methods-data.js`. Solver dùng cube.js 1.3.2; thông tin giấy phép được ghi ở `THIRD-PARTY-LICENSES.md`.
