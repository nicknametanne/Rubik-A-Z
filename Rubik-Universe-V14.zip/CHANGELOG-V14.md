# Changelog V14 — Smart Cube Arena

## V14.1 — Bluetooth Core
- Thêm trang Smart Cube Arena vào thanh điều hướng và tìm kiếm toàn cục.
- Tích hợp `smartcube-web-bluetooth@4.1.0` bằng ESM CDN; kết nối / ngắt kết nối hai cube độc lập.
- Tiếp nhận MOVE, FACELETS, BATTERY và GYRO; yêu cầu battery / facelets khi thiết bị hỗ trợ.

## V14.2 — Smart Timer
- Bắt đầu timer ở move đầu tiên sau thao tác Ready.
- Tự hoàn thành khi facelets được báo về trạng thái solved; có tùy chọn dừng thủ công.
- Tích hợp GAN Smart Timer và GAN Halo Smart Timer, ưu tiên recordedTime từ timer.
- Ghi solve vào session dữ liệu hiện tại, phân biệt nguồn Smart Cube và thiết bị.

## V14.3 — Multi-brand
- Chuẩn hóa event từ các giao thức mà driver upstream hỗ trợ: GAN, MoYu, QiYi/X-Man, Giiker/Xiaomi và GoCube/Rubik Connected.
- Có lưu ý tương thích theo model / firmware thay vì tuyên bố mọi sản phẩm cùng hãng đều dùng được.

## V14.4 — Local Battle
- Hỗ trợ hai cube đấu trên cùng một máy với scramble 2×2 / 3×3 dùng chung.
- Theo dõi thời gian, số move, trạng thái; chỉ công nhận kết quả thắng/thua khi cả hai được xác minh solved qua FACELETS có `source: "device"`; FACELETS tự dựng từ move không đủ làm bằng chứng vật lý.

## V14.5 — Online Arena
- Thêm WebRTC DataChannel P2P, trao đổi mã Offer / Answer, truyền scramble, move count, timer và trạng thái solve.
- Dùng STUN để thiết lập kết nối trực tiếp; không tích hợp signaling server hoặc TURN relay.

## V14.6 — Replay & Analysis
- Lưu replay vào LocalStorage, tối đa 100 lượt; hỗ trợ xuất JSON.
- Timeline, TPS, move count, pause, pause lớn nhất, phân bố mặt xoay.
- Replay 3×3 tích hợp Visualizer hiện hữu; 2×2 hỗ trợ timeline và thống kê.

## Tương thích và giới hạn
- Web Bluetooth yêu cầu HTTPS / localhost và browser hỗ trợ; Chrome / Edge được khuyến nghị.
- Move timestamp là thời điểm trình duyệt nhận thông báo BLE; dữ liệu dùng để luyện tập, không phải kết quả WCA chính thức.
- Một số mạng NAT / firewall không cho P2P kết nối nếu thiếu TURN server. Mã phòng phải được trao đổi thủ công.
- Driver ESM tải từ CDN nên cần Internet lần đầu mở Smart Cube Arena.
