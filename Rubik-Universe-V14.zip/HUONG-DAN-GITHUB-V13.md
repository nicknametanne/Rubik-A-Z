# Cập nhật Rubik Universe V13 (gộp V12 + V13) lên GitHub Pages

## Gói này gồm gì?

V13 là bản hợp nhất phần V12 (Statistics nâng cao) và V13 (3D cube engine nâng cấp). Nó được phát triển trên nền V11 và giữ lại các trang/luồng cũ: Timer, Scramble Center, Solver, Sessions, Statistics, CFOP, Beginner, Roux, ZZ, Petrus, Trainer, Academy, Knowledge Base, Settings và LocalStorage.

Điểm nâng cấp 3D:
- Nút 3D trong thư viện hiển thị **trạng thái case** ngay khi mở.
- Trạng thái case được tái tạo bằng công thức nghịch đảo từ cube đã giải.
- Không hiển thị danh sách bước xoay ban đầu. Người dùng bấm **Phát công thức từ trạng thái case** mới chuyển sang chế độ sequence.
- 3D sử dụng 26 cubie, sticker sáu hướng, kéo/ vuốt đổi góc nhìn, zoom và animation từng lớp.
- Sửa lỗi làm phẳng preserve-3d, đảo hướng sticker U/D và quy đổi góc xoay CSS theo hệ tọa độ màn hình.

V12 Statistics:
- Lọc theo session, puzzle và khoảng ngày.
- Bộ lọc được áp dụng đồng thời cho biểu đồ / bảng / CSV.
- Bổ sung các chỉ số Ao50/Ao100 và xu hướng theo tuần/tháng.

## Trước khi cập nhật

1. Mở website hiện tại → **Cài đặt** → xuất bản sao lưu JSON.
2. Đảm bảo repository đang dùng GitHub Actions ở **Settings → Pages → Build and deployment → Source**.
3. Không tạo repository mới; tiếp tục sử dụng `Rubik-A-Z`.

## Cập nhật repository

1. Tải và giải nén `Rubik-Universe-V13-GitHub-Upload-Kit.zip`.
2. Trên GitHub, mở `.github/workflows/deploy-pages.yml` trong repository, chọn **Edit**.
3. Thay toàn bộ nội dung bằng file `.github/workflows/deploy-pages.yml` trong gói V13, rồi commit workflow trước.
4. Trở lại tab **Code** → **Add file** → **Upload files**.
5. Tải `Rubik-Universe-V13.zip` (khuyên dùng, gọn hơn) hoặc `Rubik-Universe-V13-GitHub-Upload-Kit.zip` lên **thư mục gốc repository** (không giải nén ZIP vào thư mục con), rồi commit. Upload Kit cũng có bản source ở thư mục gốc bên trong ZIP nên workflow có thể triển khai trực tiếp. Nếu tải cả hai ZIP, workflow sẽ ưu tiên `Rubik-Universe-V13.zip`.
6. Vào **Actions**, mở workflow `Publish Rubik Universe to GitHub Pages` và chờ trạng thái thành công.
7. Mở URL Pages cũ và nhấn `Ctrl + Shift + R` để bỏ cache trang cũ.

Nếu workflow đang hoạt động thì không cần cấu hình Pages lại. Workflow V13 ưu tiên `Rubik-Universe-V13.zip`, sau đó mới dùng các gói cũ V11/V9/V8/V6–V7/V5.5 để làm phương án dự phòng.

## Kiểm tra sau triển khai

- Vào Thư viện thuật toán, nhấn **3D** tại một case OLL/PLL/F2L hoặc một case của Beginner/Roux/ZZ/Petrus.
- Trang 3D phải mở ở trạng thái case; phần điều khiển move không hiện ở chế độ này.
- Kéo mô hình để đổi góc, thử thanh zoom và nút đặt lại góc nhìn.
- Bấm **Phát công thức từ trạng thái case** để chạy sequence, kiểm tra từng move và nút tạm dừng.
- Mở Statistics, thử lọc theo puzzle/ngày và xuất CSV.
- Kiểm tra Timer, Session, Solver và tiến độ Trainer cũ.

## Chạy test trước khi push (tùy chọn)

Cần Node.js 18+:

```bash
npm test
```

Bản đóng gói này có 64 test tự động đạt. Việc này không thay thế kiểm thử thao tác trực tiếp trên Chrome/Edge sau deploy.

## Dữ liệu cũ

V13 giữ LocalStorage key `rubik-universe-v1` và không cố ý xóa session, solve, công thức cá nhân, tiến độ học hoặc cài đặt. Dữ liệu nằm theo từng trình duyệt/thiết bị; GitHub Pages không tự đồng bộ giữa các thiết bị. Luôn giữ file JSON backup cho tới khi xác nhận dữ liệu sau nâng cấp đã đúng.
