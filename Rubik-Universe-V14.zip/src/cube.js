const FACE_COLORS = { U: '#f5f3ea', R: '#e34f4f', F: '#32aa70', D: '#f0d23c', L: '#ff963f', B: '#3978df' };
const FACE_ORDER = ['U', 'R', 'F', 'D', 'L', 'B'];

function faceletPosition(face, row, col) {
  switch (face) {
    case 'U': return { position: [col - 1, 1, row - 1], normal: [0, 1, 0] };
    case 'R': return { position: [1, 1 - row, 1 - col], normal: [1, 0, 0] };
    case 'F': return { position: [col - 1, 1 - row, 1], normal: [0, 0, 1] };
    case 'D': return { position: [col - 1, -1, 1 - row], normal: [0, -1, 0] };
    case 'L': return { position: [-1, 1 - row, col - 1], normal: [-1, 0, 0] };
    case 'B': return { position: [1 - col, 1 - row, -1], normal: [0, 0, -1] };
    default: throw new Error(`Unknown face: ${face}`);
  }
}

function faceletIndex(position, normal) {
  const [x, y, z] = position;
  const [nx, ny, nz] = normal;
  if (ny === 1) return ['U', z + 1, x + 1];
  if (nx === 1) return ['R', 1 - y, 1 - z];
  if (nz === 1) return ['F', 1 - y, x + 1];
  if (ny === -1) return ['D', 1 - z, x + 1];
  if (nx === -1) return ['L', 1 - y, z + 1];
  return ['B', 1 - y, 1 - x];
}

export function createSolvedCube() {
  const stickers = [];
  for (const face of FACE_ORDER) {
    for (let row = 0; row < 3; row += 1) {
      for (let col = 0; col < 3; col += 1) {
        const { position, normal } = faceletPosition(face, row, col);
        stickers.push({ position, normal, color: face });
      }
    }
  }
  return stickers;
}

function rotateVector([x, y, z], axis, quarterTurns) {
  let vector = [x, y, z];
  const steps = ((quarterTurns % 4) + 4) % 4;
  for (let step = 0; step < steps; step += 1) {
    if (axis === 'x') vector = [vector[0], -vector[2], vector[1]];
    else if (axis === 'y') vector = [vector[2], vector[1], -vector[0]];
    else vector = [-vector[1], vector[0], vector[2]];
  }
  return vector;
}

export function describeCubeMove(token) {
  const match = /^(\d+)?(Rw|Lw|Uw|Dw|Fw|Bw|[RLUDFBrludfbMESxyz])(2|')?$/.exec(token);
  if (!match) throw new Error(`Unsupported move: ${token}`);
  const [, depthText = '', name, suffix = ''] = match;
  const face = name.replace(/w$/, '').toUpperCase();
  const wide = name.endsWith('w') || /^[rludfb]$/.test(name);
  const definitions = {
    R: ['x', [1], -1], L: ['x', [-1], 1],
    U: ['y', [1], -1], D: ['y', [-1], 1],
    F: ['z', [1], -1], B: ['z', [-1], 1],
    M: ['x', [0], 1], E: ['y', [0], 1], S: ['z', [0], -1],
    X: ['x', [-1, 0, 1], -1], Y: ['y', [-1, 0, 1], -1], Z: ['z', [-1, 0, 1], -1]
  };
  const [axis, baseLayers, direction] = definitions[face];
  let layers = [...baseLayers];
  if (wide) {
    const depth = depthText ? Number(depthText) : 2;
    if (!Number.isInteger(depth) || depth < 2 || depth > 3) throw new Error(`Wide-turn depth is outside the 3×3 model: ${token}`);
    const outward = {
      R: [1, 0, -1], L: [-1, 0, 1], U: [1, 0, -1],
      D: [-1, 0, 1], F: [1, 0, -1], B: [-1, 0, 1]
    }[face];
    layers = outward.slice(0, depth);
  } else if (depthText && /^[RLUDFB]$/.test(name)) {
    const depth = Number(depthText);
    if (!Number.isInteger(depth) || depth < 2 || depth > 3) throw new Error(`Layer number is outside the 3×3 model: ${token}`);
    const inward = {
      R: [1, 0, -1], L: [-1, 0, 1], U: [1, 0, -1],
      D: [-1, 0, 1], F: [1, 0, -1], B: [-1, 0, 1]
    }[face];
    layers = [inward[depth - 1]];
  } else if (depthText) {
    throw new Error(`Numeric prefix is not valid for this move: ${token}`);
  }
  if (suffix === "'") return { axis, layers, turns: -direction };
  if (suffix === '2') return { axis, layers, turns: direction * 2 };
  return { axis, layers, turns: direction };
}

export function parseCubeMoves(sequence) {
  const tokens = String(sequence ?? '').trim().split(/\s+/).filter(Boolean);
  if (!tokens.length) return [];
  for (const token of tokens) describeCubeMove(token);
  return tokens;
}

export function applyCubeMove(cube, token) {
  const { axis, layers, turns } = describeCubeMove(token);
  const axisIndex = { x: 0, y: 1, z: 2 }[axis];
  return cube.map(sticker => {
    if (!layers.includes(sticker.position[axisIndex])) return sticker;
    return {
      ...sticker,
      position: rotateVector(sticker.position, axis, turns),
      normal: rotateVector(sticker.normal, axis, turns)
    };
  });
}

export function applyCubeMoves(cube, sequence) {
  return parseCubeMoves(sequence).reduce((state, token) => applyCubeMove(state, token), cube.map(sticker => ({
    position: [...sticker.position], normal: [...sticker.normal], color: sticker.color
  })));
}

export function invertCubeMoves(sequence) {
  return parseCubeMoves(sequence).reverse().map(token => {
    if (token.endsWith('2')) return token;
    return token.endsWith("'") ? token.slice(0, -1) : `${token}'`;
  });
}

export function cubeFaceGrids(cube) {
  const grids = Object.fromEntries(FACE_ORDER.map(face => [face, Array(9).fill(null)]));
  for (const sticker of cube) {
    const [face, row, col] = faceletIndex(sticker.position, sticker.normal);
    grids[face][row * 3 + col] = FACE_COLORS[sticker.color];
  }
  return grids;
}

export function isCubeSolved(cube) {
  return FACE_ORDER.every(face => cube.filter(sticker => faceletIndex(sticker.position, sticker.normal)[0] === face)
    .every(sticker => sticker.color === face));
}


// Converts a standard URFDLB facelet string into the V3 sticker geometry.
export function createCubeFromFaceletString(facelets) {
  const value = String(facelets ?? '').trim();
  if (!/^[URFDLB]{54}$/.test(value)) throw new Error('Facelet string must contain 54 URFDLB stickers.');
  return createSolvedCube().map((sticker, index) => ({ ...sticker, color: value[index] }));
}

// Returns the cube in the standard URFDLB facelet order used by solver engines.
export function cubeToFaceletString(cube) {
  const faceIndex = Object.fromEntries(FACE_ORDER.map((face, index) => [face, index]));
  const result = Array(54).fill('');
  for (const sticker of cube) {
    const [face, row, col] = faceletIndex(sticker.position, sticker.normal);
    result[faceIndex[face] * 9 + row * 3 + col] = sticker.color;
  }
  if (result.some(value => !value)) throw new Error('Cube geometry is incomplete.');
  return result.join('');
}
