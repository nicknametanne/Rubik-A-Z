import { effectiveTime } from './core.js';

export function filterStatsSolves(solves, sessions, filters = {}) {
  const source = Array.isArray(solves) ? solves : [];
  const sessionList = Array.isArray(sessions) ? sessions : [];
  const sessionId = filters.sessionId || 'current';
  const activeSessionId = filters.activeSessionId || sessionList[0]?.id;
  const puzzle = filters.puzzle || 'all';
  const from = filters.from ? new Date(`${filters.from}T00:00:00`) : null;
  const to = filters.to ? new Date(`${filters.to}T23:59:59.999`) : null;
  const allowed = sessionId === 'all'
    ? source
    : source.filter(solve => solve.sessionId === activeSessionId);
  const sessionPuzzles = new Map(sessionList.map(session => [session.id, session.puzzle || '3x3']));
  return allowed.filter(solve => {
    const solvePuzzle = solve.puzzle || sessionPuzzles.get(solve.sessionId) || '3x3';
    if (puzzle !== 'all' && solvePuzzle !== puzzle) return false;
    const date = new Date(solve.createdAt);
    if (Number.isNaN(date.getTime())) return false;
    return (!from || date >= from) && (!to || date <= to);
  }).slice().sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
}

function startOfWeek(date) {
  const start = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const day = (start.getDay() + 6) % 7;
  start.setDate(start.getDate() - day);
  start.setHours(0, 0, 0, 0);
  return start;
}

export function groupSolveAverages(solves, period = 'week', limit = 12) {
  if (!['week', 'month'].includes(period)) throw new RangeError('Period must be week or month.');
  const groups = new Map();
  for (const solve of Array.isArray(solves) ? solves : []) {
    const date = new Date(solve.createdAt);
    if (Number.isNaN(date.getTime())) continue;
    let key;
    let label;
    if (period === 'week') {
      const start = startOfWeek(date);
      key = `${start.getFullYear()}-${String(start.getMonth() + 1).padStart(2, '0')}-${String(start.getDate()).padStart(2, '0')}`;
      label = `${String(start.getDate()).padStart(2, '0')}/${String(start.getMonth() + 1).padStart(2, '0')}`;
    } else {
      key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      label = `${String(date.getMonth() + 1).padStart(2, '0')}/${String(date.getFullYear()).slice(-2)}`;
    }
    if (!groups.has(key)) groups.set(key, { key, label, values: [], solves: 0, dnfs: 0 });
    const group = groups.get(key);
    group.solves += 1;
    const time = effectiveTime(solve);
    if (Number.isFinite(time)) group.values.push(time);
    else group.dnfs += 1;
  }
  return [...groups.values()].sort((a, b) => a.key.localeCompare(b.key)).slice(-Math.max(1, limit)).map(group => ({
    ...group,
    averageMs: group.values.length ? group.values.reduce((sum, value) => sum + value, 0) / group.values.length : null
  }));
}
