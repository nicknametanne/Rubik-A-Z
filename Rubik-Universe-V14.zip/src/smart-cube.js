import {
  analyzeMoveHistory, createReplayRecord, decodeSignalDescription,
  encodeSignalDescription, isSolvedFacelets, normalizeSmartMove
} from './smart-cube-core.js';

const SMART_CUBE_CDN = 'https://esm.sh/smartcube-web-bluetooth@4.1.0?bundle';
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const slots = {
  p1: createSlot('p1', 'Người chơi 1'),
  p2: createSlot('p2', 'Người chơi 2')
};
let activeTab = 'devices';
let currentScramble = '';
let currentPuzzle = '3x3';
let rtc = { pc: null, channel: null, role: null };
let remotePlayer = { status: 'Chưa kết nối', moves: 0, elapsedMs: 0, finished: false };
let smartTimer = { connection: null, subscription: null, startAt: 0, state: 'disconnected' };
let tickFrame = 0;
let libraryModule = null;
let libraryError = null;
let initialized = false;

function createSlot(id, label) {
  return {
    id, label, connection: null, subscription: null, device: null,
    name: 'Chưa kết nối', brand: 'Unknown', serial: '', battery: null,
    capabilities: {}, facelets: '', gyro: null, state: 'disconnected',
    startAt: 0, moves: [], lastMoveAt: 0, lastFaceletsAt: 0
  };
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
}

function formatTime(ms) {
  if (!Number.isFinite(ms) || ms < 0) return '—';
  return (ms / 1000).toFixed(2);
}

function tell(message, kind = 'success') {
  if (typeof window.rubikUniverseToast === 'function') window.rubikUniverseToast(message, kind);
  else console[kind === 'error' ? 'error' : 'info'](message);
}

function setText(id, value) {
  const node = document.getElementById(id);
  if (node) node.textContent = String(value ?? '');
}

function getLibrary() {
  if (libraryModule) return Promise.resolve(libraryModule);
  if (libraryError) return Promise.reject(libraryError);
  return import(SMART_CUBE_CDN).then(module => {
    if (typeof module.connectSmartCube !== 'function') throw new Error('Thư viện chưa cung cấp connectSmartCube().');
    libraryModule = module;
    setText('sc-library-state', 'Driver đa hãng đã sẵn sàng');
    $('#sc-library-dot')?.classList.add('is-online');
    const retry = $('#sc-retry-driver'); if (retry) retry.hidden = true;
    ['sc-connect-p1', 'sc-connect-p2', 'sc-connect-gan-timer'].forEach(id => {
      const button = document.getElementById(id);
      if (button) button.disabled = false;
    });
    return module;
  }).catch(error => {
    libraryError = error;
    setText('sc-library-state', 'Không tải được driver Bluetooth');
    const retry = $('#sc-retry-driver'); if (retry) retry.hidden = false;
    setText('sc-library-help', `Không tải được thư viện Smart Cube: ${error.message}. Kiểm tra Internet rồi tải lại trang.`);
    tell('Không tải được driver Smart Cube từ CDN. Kiểm tra kết nối Internet.', 'error');
    throw error;
  });
}

function brandFromName(name) {
  const value = String(name || '').toLowerCase();
  if (/gan|monster.?go/.test(value)) return 'GAN';
  if (/moyu|wei.?long|weipo|wcu/.test(value)) return 'MoYu';
  if (/qiyi|x.?man|tornado/.test(value)) return 'QiYi / X-Man';
  if (/giiker|mi.?smart|hi-/.test(value)) return 'Giiker / Xiaomi';
  if (/gocube|rubik/.test(value)) return 'GoCube / Rubik';
  return 'Smart Cube';
}

function slotStatus(slot) {
  return ({ disconnected: 'Chưa kết nối', connected: 'Đã kết nối', armed: 'Sẵn sàng · chờ xoay', running: 'Đang giải', solved: 'Đã hoàn thành', stopped: 'Đã dừng thủ công' })[slot.state] || 'Không rõ trạng thái';
}

function renderSlot(slot) {
  const prefix = `sc-${slot.id}`;
  setText(`${prefix}-name`, slot.name);
  setText(`${prefix}-brand`, slot.brand);
  setText(`${prefix}-status`, slotStatus(slot));
  setText(`${prefix}-finishmode`, slot.capabilities?.facelets ? 'Tự kết thúc khi FACELETS từ phần cứng xác nhận solved' : 'Cần dừng thủ công nếu thiếu FACELETS phần cứng');
  setText(`${prefix}-battery`, slot.battery == null ? '—' : `${slot.battery}%`);
  setText(`${prefix}-moves`, String(slot.moves.length));
  setText(`${prefix}-time`, slot.state === 'running' ? formatTime(performance.now() - slot.startAt) : slot.state === 'solved' ? formatTime(slot.lastSolveMs || 0) : '0.00');
  const dot = document.getElementById(`${prefix}-dot`);
  if (dot) dot.className = `sc-status-dot ${slot.connection ? 'is-online' : ''} ${slot.state === 'running' ? 'is-running' : ''}`;
  const connect = document.getElementById(`sc-connect-${slot.id}`);
  const disconnect = document.getElementById(`sc-disconnect-${slot.id}`);
  const arm = document.getElementById(`sc-arm-${slot.id}`);
  const stop = document.getElementById(`sc-stop-${slot.id}`);
  if (connect) connect.hidden = Boolean(slot.connection);
  if (disconnect) disconnect.hidden = !slot.connection;
  if (arm) { arm.disabled = !slot.connection || ['armed', 'running'].includes(slot.state); arm.textContent = slot.state === 'solved' ? 'Giải tiếp' : 'Sẵn sàng giải'; }
  if (stop) stop.disabled = slot.state !== 'running';
  setText(`sc-local-${slot.id}-state`, slotStatus(slot));
  setText(`sc-local-${slot.id}-moves`, String(slot.moves.length));
  if (slot.state === 'running') setText(`sc-local-${slot.id}-time`, `${formatTime(performance.now() - slot.startAt)}s`);
  else if (slot.state === 'solved') setText(`sc-local-${slot.id}-time`, `${formatTime(slot.lastSolveMs || 0)}s`);
}

function renderCompatibility() {
  const supported = Boolean(navigator.bluetooth) && window.isSecureContext;
  setText('sc-browser-state', supported ? 'Trình duyệt có Web Bluetooth' : 'Web Bluetooth chưa khả dụng');
  setText('sc-browser-help', !window.isSecureContext
    ? 'Mở website bằng HTTPS hoặc localhost. Trang file:// không thể xin quyền Bluetooth.'
    : !navigator.bluetooth
      ? 'Dùng Chrome hoặc Edge trên máy tính, hoặc Chrome trên Android. Firefox và Safari hiện không phù hợp.'
      : 'Bật Bluetooth của thiết bị, đánh thức cube bằng một vài lần xoay và đóng app khác đang giữ kết nối cube.');
}

function renderReplayList() {
  const list = $('#sc-replay-list');
  if (!list) return;
  const records = (options.getReplays?.() || []).slice().sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
  if (!records.length) {
    list.innerHTML = '<div class="empty-state compact"><strong>Chưa có Smart Cube solve</strong><p>Kết nối cube, giải xong một lượt để lưu replay và phân tích.</p></div>';
    return;
  }
  list.innerHTML = records.map(record => {
    const moves = Array.isArray(record.moves) ? record.moves.length : 0;
    return `<article class="sc-replay-item"><div><strong>${escapeHtml(formatTime(Number(record.rawMs))) }s</strong><span>${escapeHtml(record.cubeName || 'Smart Cube')} · ${moves} moves · ${escapeHtml(record.puzzle || '3x3')}</span><small>${escapeHtml(new Date(record.createdAt).toLocaleString('vi-VN'))}</small></div><div class="sc-replay-actions"><button class="secondary-button small-button" data-sc-replay-detail="${escapeHtml(record.id)}">Phân tích</button><button class="primary-button small-button" data-sc-replay-play="${escapeHtml(record.id)}">Replay 3D</button></div></article>`;
  }).join('');
}

let options = {};

function setTab(tab) {
  activeTab = tab;
  $$('[data-sc-tab]').forEach(button => button.classList.toggle('active', button.dataset.scTab === tab));
  $$('.sc-tab-panel').forEach(panel => panel.classList.toggle('active', panel.dataset.scPanel === tab));
  if (tab === 'replay') renderReplayList();
  if (tab === 'devices') renderCompatibility();
}

function connectionDevice(connection) {
  return connection?.device || connection?.bluetoothDevice || connection?.cube?.device || null;
}

async function connectSlot(slotId) {
  const slot = slots[slotId];
  if (!slot || slot.connection) return;
  if (!window.isSecureContext || !navigator.bluetooth) {
    tell('Bluetooth cần HTTPS và trình duyệt hỗ trợ Web Bluetooth (Chrome/Edge phù hợp).', 'error');
    renderCompatibility();
    return;
  }
  const button = document.getElementById(`sc-connect-${slotId}`);
  if (button) { button.disabled = true; button.textContent = 'Đang mở Bluetooth…'; }
  try {
    const module = await getLibrary();
    if (navigator.userActivation && !navigator.userActivation.isActive) {
      tell('Hãy nhấn Kết nối thêm lần nữa để mở hộp thoại chọn thiết bị Bluetooth.', 'error');
      return;
    }
    const connection = await module.connectSmartCube();
    if (!connection?.events$?.subscribe) throw new Error('Thiết bị được chọn nhưng driver không phát sự kiện.');
    slot.connection = connection;
    slot.device = connectionDevice(connection);
    slot.name = slot.device?.name || 'Smart Cube đã kết nối';
    slot.brand = brandFromName(slot.device?.name);
    slot.capabilities = connection.capabilities || {};
    slot.state = 'connected';
    slot.subscription = connection.events$.subscribe({
      next: event => handleCubeEvent(slot, event),
      error: error => { tell(`Smart Cube mất luồng dữ liệu: ${error?.message || 'lỗi không xác định'}`, 'error'); disconnectSlot(slotId); }
    });
    slot.device?.addEventListener?.('gattserverdisconnected', () => disconnectSlot(slotId));
    renderSlot(slot);
    if (slot.capabilities.battery) Promise.resolve(connection.sendCommand?.({ type: 'REQUEST_BATTERY' })).catch(() => {});
    if (slot.capabilities.facelets) Promise.resolve(connection.sendCommand?.({ type: 'REQUEST_FACELETS' })).catch(() => {});
    tell(`${slot.label} đã kết nối Smart Cube.`);
  } catch (error) {
    const reason = error?.name === 'NotFoundError' ? 'Bạn đã đóng hộp thoại hoặc không chọn thiết bị.' : error?.message || String(error);
    tell(`Không thể kết nối ${slot.label}: ${reason}`, 'error');
  } finally {
    if (button) { button.disabled = false; button.textContent = 'Kết nối cube'; }
  }
}

function disconnectSlot(slotId) {
  const slot = slots[slotId];
  if (!slot) return;
  try { slot.subscription?.unsubscribe?.(); } catch { /* no-op */ }
  try { slot.connection?.disconnect?.(); } catch { /* device GATT fallback below */ }
  try { if (slot.device?.gatt?.connected) slot.device.gatt.disconnect(); } catch { /* disconnected already */ }
  slot.connection = null;
  slot.subscription = null;
  slot.device = null;
  slot.name = 'Chưa kết nối';
  slot.brand = 'Unknown';
  slot.battery = null;
  slot.serial = '';
  slot.facelets = '';
  slot.state = 'disconnected';
  slot.moves = [];
  renderSlot(slot);
  tell(`${slot.label} đã ngắt kết nối.`);
}

function readMove(event) {
  const direct = normalizeSmartMove(event?.move);
  if (direct) return direct;
  const face = String(event?.face || '').toUpperCase();
  const direction = event?.direction;
  if (!'URFDLB'.includes(face)) return null;
  if (direction === -1 || direction === "'" || /counter|anti|ccw/i.test(String(direction))) return `${face}'`;
  if (direction === 1 || direction === 0 || direction === '+' || /clockwise|cw/i.test(String(direction))) return face;
  return null;
}

function publishOnline(message) {
  if (rtc.channel?.readyState !== 'open') return false;
  try { rtc.channel.send(JSON.stringify({ ...message, v: 1, at: Date.now() })); return true; }
  catch (error) { tell(`Không gửi được dữ liệu trận đấu: ${error.message}`, 'error'); return false; }
}

function handleCubeEvent(slot, event) {
  if (!event || typeof event !== 'object') return;
  if (event.type === 'BATTERY') {
    const level = Number(event.batteryLevel);
    if (Number.isFinite(level)) slot.battery = Math.max(0, Math.min(100, Math.round(level)));
    renderSlot(slot);
    return;
  }
  if (event.type === 'GYRO') {
    slot.gyro = Array.isArray(event.quaternion) ? event.quaternion.slice(0, 4) : event.quaternion || null;
    const gyro = $('#sc-gyro-state');
    if (gyro && slot.id === 'p1') gyro.textContent = slot.gyro ? 'Đã nhận dữ liệu gyro' : 'Thiết bị không gửi gyro';
    return;
  }
  if (event.type === 'FACELETS') {
    slot.facelets = event.facelets;
    if (event.serial != null) slot.serial = String(event.serial);
    if (event.source === 'device') slot.faceletsVerifiedAt = performance.now();
    slot.lastFaceletsAt = performance.now();
    // Only trust a physical device snapshot for automatic solve validation.
    // Some drivers can emit FACELETS reconstructed from move history; those
    // states are useful for display but may be wrong for axis-alias protocols.
    if (slot.state === 'running' && slot.moves.length > 0 && event.source === 'device' && isSolvedFacelets(event.facelets)) finishSlot(slot, 'facelets');
    return;
  }
  if (event.type === 'MOVE') {
    const move = readMove(event);
    if (!move) return;
    if (slot.state === 'armed') {
      slot.state = 'running';
      slot.startAt = performance.now();
      slot.moves = [];
      slot.lastSolveMs = 0;
      if (slot.id === 'p1') {
        publishOnline({ type: 'START' });
        setText('sc-online-local-status', 'Đang giải');
      }
    }
    if (slot.state !== 'running') return;
    const elapsed = Math.max(0, performance.now() - slot.startAt);
    slot.moves.push({ move, t: Math.round(elapsed * 10) / 10 });
    slot.lastMoveAt = performance.now();
    renderSlot(slot);
    setText(`sc-${slot.id}-lastmove`, move);
    setText(`sc-local-${slot.id}-time`, `${formatTime(elapsed)}s`);
    setText(`sc-local-${slot.id}-moves`, String(slot.moves.length));
    setText(`sc-local-${slot.id}-state`, 'Đang giải');
    ensureTimerTick();
    if (slot.id === 'p1') {
      publishOnline({ type: 'MOVE', move, count: slot.moves.length, elapsedMs: Math.round(elapsed) });
      setText('sc-online-local-moves', String(slot.moves.length));
    }
  }
  if (event.type === 'DISCONNECT' || event.type === 'DISCONNECTED') disconnectSlot(slot.id);
}

function armSlot(slotId) {
  const slot = slots[slotId];
  if (!slot?.connection) return tell('Hãy kết nối Smart Cube trước.', 'error');
  if (slot.state === 'running') return tell('Lượt giải đang chạy.', 'error');
  const anotherAttemptActive = Object.values(slots).some(item => item.state === 'armed' || item.state === 'running');
  if (!anotherAttemptActive) {
    Object.values(slots).forEach(item => {
      item.moves = []; item.startAt = 0; item.lastSolveMs = 0; item.lastFinishVerified = false;
      item.state = item.connection ? 'connected' : 'disconnected';
      renderSlot(item);
      setText(`sc-local-${item.id}-time`, '0.00s');
      setText(`sc-local-${item.id}-moves`, '0');
    });
    renderLocalBattleResult();
  }
  slot.moves = [];
  slot.startAt = 0;
  slot.lastSolveMs = 0;
  slot.lastFinishVerified = false;
  slot.state = 'armed';
  renderSlot(slot);
  setText(`sc-local-${slot.id}-state`, 'Ready');
  setText(`sc-local-${slot.id}-moves`, '0');
  setText(`sc-local-${slot.id}-time`, '0.00s');
  if (slot.id === 'p1') {
    publishOnline({ type: 'READY' });
    setText('sc-online-local-moves', '0');
    setText('sc-online-local-time', '0.00s');
    setText('sc-online-local-status', 'Ready');
  }
  tell(`${slot.label} đã sẵn sàng. Xoay move đầu tiên để bắt đầu timer.`);
}

function stopSlot(slotId) {
  const slot = slots[slotId];
  if (!slot || slot.state !== 'running') return;
  finishSlot(slot, 'manual');
}

function finishSlot(slot, reason) {
  if (slot.state !== 'running') return;
  const rawMs = Math.max(0, performance.now() - slot.startAt);
  slot.state = 'solved';
  slot.lastSolveMs = rawMs;
  slot.lastFinishVerified = reason === 'facelets';
  const record = createReplayRecord({
    puzzle: currentPuzzle,
    cubeName: slot.name,
    brand: slot.brand,
    serial: slot.serial,
    scramble: currentScramble,
    rawMs,
    moves: slot.moves,
    createdAt: new Date().toISOString()
  });
  const solveId = options.onSolve?.({ ...record, player: slot.id, finishReason: reason }) || '';
  const savedReplay = { ...record, solveId, player: slot.id, finishReason: reason };
  if (record.moves.length) options.onSaveReplay?.(savedReplay);
  renderSlot(slot);
  setText(`sc-local-${slot.id}-state`, reason === 'manual' ? 'Dừng thủ công' : 'Đã hoàn thành');
  setText(`sc-local-${slot.id}-time`, `${formatTime(rawMs)}s`);
  setText(`sc-local-${slot.id}-moves`, String(slot.moves.length));
  renderReplayList();
  if (slot.id === 'p1') {
    publishOnline({ type: 'SOLVED', rawMs: Math.round(rawMs), moves: slot.moves.length, verified: slot.lastFinishVerified });
    setText('sc-online-local-time', `${formatTime(rawMs)}s`);
    setText('sc-online-local-status', 'Solved');
  }
  renderLocalBattleResult();
  renderOnlineResult();
  tell(`${slot.label} hoàn thành: ${formatTime(rawMs)}s · ${slot.moves.length} moves${reason === 'manual' ? ' · đã dừng thủ công' : ''}.`);
}

function renderOnlineResult() {
  const local = slots.p1;
  if (!local || local.state !== 'solved' || !remotePlayer.finished) return;
  const localMs = Number(local.lastSolveMs) || 0;
  const remoteMs = Number(remotePlayer.elapsedMs) || 0;
  if (!localMs || !remoteMs) return;
  if (!local.lastFinishVerified || !remotePlayer.verified) {
    setText('sc-online-connection', `P2P · Đã dừng hai lượt nhưng chưa xác minh trạng thái solved · ${formatTime(localMs)}s vs ${formatTime(remoteMs)}s`);
    return;
  }
  const result = Math.abs(localMs - remoteMs) < 1 ? 'Hòa' : localMs < remoteMs ? 'Bạn thắng' : 'Đối thủ thắng';
  setText('sc-online-connection', `P2P · ${result} · ${formatTime(localMs)}s vs ${formatTime(remoteMs)}s`);
}

function renderLocalBattleResult() {
  const a = slots.p1;
  const b = slots.p2;
  const result = $('#sc-local-result');
  if (!result) return;
  if (a.state === 'solved' && b.state === 'solved') {
    const t1 = Number(a.lastSolveMs) || Infinity;
    const t2 = Number(b.lastSolveMs) || Infinity;
    if (!a.lastFinishVerified || !b.lastFinishVerified) {
      result.textContent = `Đã có thời gian của cả hai, nhưng ít nhất một cube chưa xác minh solved qua FACELETS · ${formatTime(t1)}s vs ${formatTime(t2)}s`;
      result.classList.remove('is-result');
      return;
    }
    const message = Math.abs(t1 - t2) < 1 ? 'Hòa' : t1 < t2 ? 'Người chơi 1 chiến thắng' : 'Người chơi 2 chiến thắng';
    result.textContent = `${message} · ${formatTime(t1)}s vs ${formatTime(t2)}s`;
    result.classList.add('is-result');
  } else {
    result.textContent = 'Kết quả sẽ xuất hiện khi cả hai người chơi hoàn thành.';
    result.classList.remove('is-result');
  }
}

function timerTick() {
  const running = Object.values(slots).some(slot => slot.state === 'running') || smartTimer.state === 'running' || remotePlayer.status === 'Đang giải';
  if (!running) { tickFrame = 0; return; }
  Object.values(slots).forEach(slot => {
    if (slot.state === 'running') {
      const elapsed = performance.now() - slot.startAt;
      setText(`sc-${slot.id}-time`, formatTime(elapsed));
      setText(`sc-local-${slot.id}-time`, `${formatTime(elapsed)}s`);
      if (slot.id === 'p1') setText('sc-online-local-time', `${formatTime(elapsed)}s`);
    }
  });
  if (smartTimer.state === 'running') {
    const elapsed = performance.now() - smartTimer.startAt;
    setText('sc-gan-timer-time', formatTime(elapsed));
  }
  if (remotePlayer.status === 'Đang giải' && remotePlayer.lastUpdateAt) {
    const live = remotePlayer.elapsedMs + (performance.now() - remotePlayer.lastUpdateAt);
    setText('sc-online-remote-time', `${formatTime(live)}s`);
  }
  tickFrame = requestAnimationFrame(timerTick);
}

function ensureTimerTick() {
  if (!tickFrame) tickFrame = requestAnimationFrame(timerTick);
}

async function generateScramble() {
  const puzzle = $('#sc-puzzle-select')?.value || '3x3';
  const button = $('#sc-generate-scramble');
  button.disabled = true;
  button.textContent = 'Đang tạo…';
  try {
    if (typeof options.generateScramble !== 'function') throw new Error('Scramble generator chưa được khởi tạo.');
    const result = await options.generateScramble(puzzle);
    currentPuzzle = puzzle;
    currentScramble = String(result || '').trim();
    if (!currentScramble) throw new Error('Không nhận được scramble.');
    $('#sc-scramble-text').textContent = currentScramble;
    $('#sc-puzzle-label').textContent = puzzle;
    $('#sc-scramble-kind').textContent = 'cubing.js · random-state (2×2 / 3×3)';
    publishOnline({ type: 'SCRAMBLE', puzzle, scramble: currentScramble });
    tell(`Đã tạo scramble ${puzzle}. Hãy tự scramble hai cube giống nhau.`);
  } catch (error) {
    tell(`Không tạo được scramble: ${error.message}`, 'error');
  } finally {
    button.disabled = false;
    button.textContent = '↻ Scramble mới';
  }
}

async function copyText(text, target) {
  try {
    await navigator.clipboard.writeText(text);
    tell('Đã sao chép.');
  } catch {
    if (target) { target.focus(); target.select(); tell('Đã chọn văn bản. Nhấn Ctrl+C để sao chép.'); }
    else tell('Trình duyệt không cho phép sao chép tự động.', 'error');
  }
}

function renderReplayDetail(id) {
  const record = (options.getReplays?.() || []).find(item => item.id === id);
  const target = $('#sc-replay-detail');
  if (!target || !record) return;
  const stats = analyzeMoveHistory(record.moves, Number(record.rawMs));
  const rows = stats.moves.slice(0, 100).map((entry, index) => {
    const previous = index ? stats.moves[index - 1].t : 0;
    const gap = index ? entry.t - previous : entry.t;
    return `<div class="sc-move-row"><span>${index + 1}</span><strong>${escapeHtml(entry.move)}</strong><small>${(entry.t / 1000).toFixed(2)}s</small><small class="${gap >= 900 ? 'is-pause' : ''}">${index ? `${Math.round(gap)}ms` : 'start'}</small></div>`;
  }).join('');
  target.innerHTML = `<div class="sc-analysis-head"><div><div class="eyebrow">SOLVE ANALYSIS</div><h3>${escapeHtml(record.cubeName || 'Smart Cube')} · ${formatTime(record.rawMs)}s</h3><p>${escapeHtml(record.scramble || 'Không lưu scramble')} </p></div><button class="text-button" data-sc-replay-close>Đóng</button></div><div class="sc-analysis-metrics"><article><small>Moves</small><strong>${stats.moveCount}</strong></article><article><small>TPS trung bình</small><strong>${stats.tps.toFixed(2)}</strong></article><article><small>Pause ≥ 0.9s</small><strong>${stats.pauseCount}</strong></article><article><small>Pause dài nhất</small><strong>${(stats.largestPauseMs / 1000).toFixed(2)}s</strong></article><article><small>Rotation x/y/z</small><strong>${stats.faces.rotations}</strong></article></div><div class="sc-face-counts">${Object.entries(stats.faces).filter(([face]) => face !== 'rotations').map(([face, count]) => `<span>${face}: <b>${count}</b></span>`).join('')}<span>Rotations: <b>${stats.faces.rotations}</b></span></div><div class="sc-replay-timeline"><div class="sc-replay-timeline-head"><strong>Move timeline</strong><small>Hiển thị tối đa 100 move đầu · khoảng nghỉ được tô màu</small></div>${rows || '<p class="muted">Không có lịch sử move.</p>'}</div><p class="source-note">TPS và pause tính từ timestamp nhận được ở trình duyệt. Đây là phân tích luyện tập, không phải phán quyết WCA; chưa phân loại chính xác Cross / F2L / OLL / PLL.</p><div class="inline-actions"><button class="primary-button" data-sc-replay-play="${escapeHtml(record.id)}">Mở replay 3D</button><button class="secondary-button" data-sc-replay-export="${escapeHtml(record.id)}">Xuất JSON</button></div>`;
  target.classList.remove('hidden');
}

function exportReplay(id) {
  const replay = (options.getReplays?.() || []).find(item => item.id === id);
  if (!replay) return;
  const blob = new Blob([JSON.stringify(replay, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `smart-cube-replay-${id}.json`;
  link.click();
  URL.revokeObjectURL(url);
}

function closeRtc() {
  try { rtc.channel?.close(); } catch { /* no-op */ }
  try { rtc.pc?.close(); } catch { /* no-op */ }
  rtc = { pc: null, channel: null, role: null };
  remotePlayer = { status: 'Chưa kết nối', moves: 0, elapsedMs: 0, finished: false };
  setText('sc-online-connection', 'Chưa kết nối đối thủ');
  setText('sc-online-remote-status', remotePlayer.status);
  setText('sc-online-remote-moves', '0');
  setText('sc-online-remote-time', '0.00s');
}

function attachDataChannel(channel) {
  rtc.channel = channel;
  channel.onopen = () => {
    setText('sc-online-connection', 'Đã kết nối P2P');
    publishOnline({ type: 'HELLO', puzzle: currentPuzzle });
    tell('Kênh thi đấu P2P đã kết nối.');
  };
  channel.onclose = () => setText('sc-online-connection', 'Kênh thi đấu đã đóng');
  channel.onerror = () => setText('sc-online-connection', 'Kênh dữ liệu gặp lỗi');
  channel.onmessage = event => handleOnlineMessage(event.data);
}

function createPeerConnection(role) {
  if (!('RTCPeerConnection' in window)) throw new Error('Trình duyệt không hỗ trợ WebRTC.');
  closeRtc();
  const pc = new RTCPeerConnection({
    iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
  });
  rtc = { pc, channel: null, role };
  pc.onconnectionstatechange = () => {
    setText('sc-online-connection', `P2P: ${pc.connectionState}`);
  };
  pc.oniceconnectionstatechange = () => {
    if (['failed', 'disconnected'].includes(pc.iceConnectionState)) setText('sc-online-connection', `ICE: ${pc.iceConnectionState} · thử tạo mã mới`);
  };
  if (role === 'host') attachDataChannel(pc.createDataChannel('rubik-universe-arena', { ordered: true }));
  else pc.ondatachannel = event => attachDataChannel(event.channel);
  return pc;
}

function waitForIceGathering(pc, timeoutMs = 16000) {
  if (pc.iceGatheringState === 'complete') return Promise.resolve();
  return new Promise(resolve => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      pc.removeEventListener('icegatheringstatechange', check);
      clearTimeout(timeout);
      resolve();
    };
    const check = () => { if (pc.iceGatheringState === 'complete') finish(); };
    const timeout = setTimeout(finish, timeoutMs);
    pc.addEventListener('icegatheringstatechange', check);
  });
}

async function createInviteCode() {
  try {
    const pc = createPeerConnection('host');
    setText('sc-online-connection', 'Đang tạo mã mời…');
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    await waitForIceGathering(pc);
    $('#sc-signal-output').value = encodeSignalDescription(pc.localDescription);
    setText('sc-online-connection', 'Đã tạo mã mời · gửi cho đối thủ');
  } catch (error) { tell(`Không tạo được phòng: ${error.message}`, 'error'); }
}

async function joinFromInvite() {
  try {
    const invite = decodeSignalDescription($('#sc-signal-input').value, 'offer');
    const pc = createPeerConnection('guest');
    await pc.setRemoteDescription(invite);
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    await waitForIceGathering(pc);
    $('#sc-signal-output').value = encodeSignalDescription(pc.localDescription);
    setText('sc-online-connection', 'Đã tạo mã trả lời · gửi lại cho người tạo phòng');
  } catch (error) { tell(`Không tham gia được phòng: ${error.message}`, 'error'); }
}

async function acceptAnswer() {
  try {
    if (!rtc.pc || rtc.role !== 'host') throw new Error('Hãy tạo mã mời trước.');
    const answer = decodeSignalDescription($('#sc-signal-input').value, 'answer');
    await rtc.pc.setRemoteDescription(answer);
    setText('sc-online-connection', 'Đang thương lượng kết nối P2P…');
  } catch (error) { tell(`Không nhận được mã trả lời: ${error.message}`, 'error'); }
}

function handleOnlineMessage(raw) {
  if (typeof raw !== 'string' || raw.length > 5000) return;
  let message;
  try { message = JSON.parse(raw); } catch { return; }
  if (!message || message.v !== 1 || typeof message.type !== 'string') return;
  if (message.type === 'HELLO') {
    remotePlayer.status = 'Đã tham gia';
  } else if (message.type === 'READY') {
    remotePlayer.status = 'Sẵn sàng';
  } else if (message.type === 'START') {
    remotePlayer.status = 'Đang giải';
    remotePlayer.finished = false;
    remotePlayer.verified = false;
    remotePlayer.moves = 0;
    remotePlayer.elapsedMs = 0;
    remotePlayer.lastUpdateAt = performance.now();
    ensureTimerTick();
  } else if (message.type === 'MOVE') {
    remotePlayer.status = 'Đang giải';
    remotePlayer.moves = Math.max(0, Math.min(2000, Number(message.count) || remotePlayer.moves + 1));
    remotePlayer.elapsedMs = Math.max(0, Number(message.elapsedMs) || 0);
    remotePlayer.lastUpdateAt = performance.now();
    ensureTimerTick();
  } else if (message.type === 'SOLVED') {
    remotePlayer.status = 'Đã hoàn thành';
    remotePlayer.moves = Math.max(0, Number(message.moves) || remotePlayer.moves);
    remotePlayer.elapsedMs = Math.max(0, Number(message.rawMs) || remotePlayer.elapsedMs);
    remotePlayer.finished = true;
    remotePlayer.verified = message.verified === true;
    remotePlayer.lastUpdateAt = 0;
  } else if (message.type === 'SCRAMBLE') {
    if (typeof message.scramble === 'string' && message.scramble.length < 1000) {
      currentScramble = message.scramble;
      currentPuzzle = ['2x2', '3x3'].includes(message.puzzle) ? message.puzzle : currentPuzzle;
      $('#sc-scramble-text').textContent = currentScramble;
      $('#sc-puzzle-select').value = currentPuzzle;
      setText('sc-puzzle-label', currentPuzzle);
      tell('Đối thủ đã gửi scramble. Hãy kiểm tra và scramble cube của bạn giống hệt.');
    }
  }
  setText('sc-online-remote-status', remotePlayer.status);
  setText('sc-online-remote-moves', String(remotePlayer.moves));
  setText('sc-online-remote-time', `${formatTime(remotePlayer.elapsedMs)}s`);
  renderOnlineResult();
}

function renderOnlineCompatibility() {
  const ok = 'RTCPeerConnection' in window;
  setText('sc-webrtc-state', ok ? 'WebRTC có sẵn' : 'WebRTC không được hỗ trợ');
}

async function connectGanTimer() {
  if (!window.isSecureContext || !navigator.bluetooth) return tell('GAN Smart Timer cần HTTPS và Web Bluetooth.', 'error');
  if (smartTimer.connection) return;
  try {
    const module = await getLibrary();
    if (navigator.userActivation && !navigator.userActivation.isActive) return tell('Nhấn Kết nối GAN Timer thêm lần nữa để mở Bluetooth.', 'error');
    if (typeof module.connectGanTimer !== 'function') throw new Error('Driver chưa cung cấp connectGanTimer().');
    const connection = await module.connectGanTimer();
    smartTimer.connection = connection;
    smartTimer.state = 'connected';
    smartTimer.subscription = connection.events$?.subscribe(event => {
      const states = module.GanTimerState || {};
      if (event.state === (states.RUNNING ?? 3)) {
        smartTimer.state = 'running';
        smartTimer.startAt = performance.now();
        setText('sc-gan-timer-status', 'Đang chạy');
        ensureTimerTick();
      } else if (event.state === (states.STOPPED ?? 4) && smartTimer.startAt) {
        const elapsedHostMs = Math.max(0, performance.now() - smartTimer.startAt);
        const timerValue = Number(event.recordedTime?.asTimestamp ?? event.recordedTime);
        const rawMs = Number.isFinite(timerValue) && timerValue > 0 ? Math.round(timerValue) : elapsedHostMs;
        smartTimer.state = 'connected';
        smartTimer.startAt = 0;
        const record = { puzzle: currentPuzzle, cubeName: 'GAN Smart Timer', brand: 'GAN', scramble: currentScramble, rawMs, moves: [], createdAt: new Date().toISOString(), player: 'timer' };
        options.onSolve?.(record);
        setText('sc-gan-timer-status', `Đã lưu ${formatTime(rawMs)}s${event.recordedTime ? ' · dữ liệu từ timer' : ' · thời gian trình duyệt'}`);
      } else if (event.state === (states.DISCONNECT ?? 0)) {
        smartTimer.state = 'disconnected';
        smartTimer.connection = null;
        $('#sc-disconnect-gan-timer').hidden = true;
        $('#sc-connect-gan-timer').hidden = false;
        setText('sc-gan-timer-status', 'Đã ngắt kết nối');
      }
    });
    setText('sc-gan-timer-status', 'Đã kết nối');
    $('#sc-disconnect-gan-timer').hidden = false;
    $('#sc-connect-gan-timer').hidden = true;
    tell('Đã kết nối GAN Smart Timer.');
  } catch (error) { tell(`Không kết nối được GAN Timer: ${error.message}`, 'error'); }
}

function disconnectGanTimer() {
  try { smartTimer.subscription?.unsubscribe?.(); } catch { /* no-op */ }
  try { smartTimer.connection?.disconnect?.(); } catch { /* no-op */ }
  smartTimer = { connection: null, subscription: null, startAt: 0, state: 'disconnected' };
  $('#sc-disconnect-gan-timer').hidden = true;
  $('#sc-connect-gan-timer').hidden = false;
  setText('sc-gan-timer-status', 'Chưa kết nối');
}

function bindEvents() {
  const root = $('#page-smartcube');
  root.addEventListener('click', event => {
    const tab = event.target.closest('[data-sc-tab]');
    if (tab) return setTab(tab.dataset.scTab);
    const connect = event.target.closest('[data-sc-connect]');
    if (connect) return connectSlot(connect.dataset.scConnect);
    const disconnect = event.target.closest('[data-sc-disconnect]');
    if (disconnect) return disconnectSlot(disconnect.dataset.scDisconnect);
    const arm = event.target.closest('[data-sc-arm]');
    if (arm) return armSlot(arm.dataset.scArm);
    const stop = event.target.closest('[data-sc-stop]');
    if (stop) return stopSlot(stop.dataset.scStop);
    if (event.target.closest('#sc-generate-scramble')) return generateScramble();
    if (event.target.closest('#sc-copy-scramble')) return copyText(currentScramble, $('#sc-scramble-text'));
    if (event.target.closest('#sc-retry-driver')) { libraryError = null; libraryModule = null; setText('sc-library-state', 'Đang tải lại driver…'); getLibrary().catch(() => {}); return; }
    if (event.target.closest('#sc-connect-gan-timer')) return connectGanTimer();
    if (event.target.closest('#sc-disconnect-gan-timer')) return disconnectGanTimer();
    if (event.target.closest('#sc-create-invite')) return createInviteCode();
    if (event.target.closest('#sc-join-invite')) return joinFromInvite();
    if (event.target.closest('#sc-accept-answer')) return acceptAnswer();
    if (event.target.closest('#sc-copy-signal')) return copyText($('#sc-signal-output').value, $('#sc-signal-output'));
    if (event.target.closest('#sc-copy-scramble-to-peer')) return publishOnline({ type: 'SCRAMBLE', puzzle: currentPuzzle, scramble: currentScramble });
    if (event.target.closest('#sc-local-reset')) {
      if (Object.values(slots).some(slot => slot.state === 'running' || slot.state === 'armed')) {
        tell('Hãy kết thúc hoặc hủy lượt đang hoạt động trước khi đặt lại bảng đấu.', 'error');
        return;
      }
      Object.values(slots).forEach(slot => {
        slot.moves = []; slot.startAt = 0; slot.lastSolveMs = 0; slot.lastFinishVerified = false;
        slot.state = slot.connection ? 'connected' : 'disconnected';
        renderSlot(slot);
        setText(`sc-local-${slot.id}-time`, '0.00s');
        setText(`sc-local-${slot.id}-moves`, '0');
        setText(`sc-local-${slot.id}-state`, 'Chưa sẵn sàng');
      });
      renderLocalBattleResult();
      tell('Đã đặt lại bảng đấu.');
      return;
    }
    if (event.target.closest('#sc-close-peer')) { closeRtc(); return tell('Đã đóng kết nối P2P.'); }
    const detail = event.target.closest('[data-sc-replay-detail]');
    if (detail) return renderReplayDetail(detail.dataset.scReplayDetail);
    const play = event.target.closest('[data-sc-replay-play]');
    if (play) {
      const record = (options.getReplays?.() || []).find(item => item.id === play.dataset.scReplayPlay);
      if (record) options.onReplay?.(record);
      return;
    }
    const exportButton = event.target.closest('[data-sc-replay-export]');
    if (exportButton) return exportReplay(exportButton.dataset.scReplayExport);
    if (event.target.closest('[data-sc-replay-close]')) { $('#sc-replay-detail').classList.add('hidden'); return; }
  });
  $('#sc-puzzle-select')?.addEventListener('change', event => { currentPuzzle = event.target.value; });
  window.addEventListener('beforeunload', () => {
    Object.keys(slots).forEach(disconnectSlot);
    disconnectGanTimer();
    closeRtc();
  }, { once: true });
}

export function refreshSmartCubePage() {
  renderCompatibility();
  renderOnlineCompatibility();
  Object.values(slots).forEach(renderSlot);
  renderReplayList();
}

export function initSmartCubeFeatures(config = {}) {
  if (initialized) return;
  options = config;
  const root = $('#page-smartcube');
  if (!root) return;
  initialized = true;
  bindEvents();
  renderCompatibility();
  renderOnlineCompatibility();
  Object.values(slots).forEach(renderSlot);
  renderReplayList();
  ['sc-connect-p1', 'sc-connect-p2', 'sc-connect-gan-timer'].forEach(id => {
    const button = document.getElementById(id);
    if (button) button.disabled = true;
  });
  setText('sc-library-state', 'Đang tải driver đa hãng…');
  getLibrary().catch(() => {});
  ensureTimerTick();
}
