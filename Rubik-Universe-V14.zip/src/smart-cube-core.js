const FACE_MOVE = /^(?:[URFDLB](?:2|')?|[xyz](?:2|')?)$/;

export function normalizeSmartMove(value) {
  if (typeof value === 'object' && value !== null) {
    value = value.notation ?? value.move ?? value.algorithm ?? '';
  }
  const move = String(value ?? '').trim().replace(/[’`]/g, "'");
  return FACE_MOVE.test(move) ? move : null;
}

export function isSolvedFacelets(value) {
  const facelets = Array.isArray(value) ? value.join('') : String(value ?? '').replace(/\s+/g, '');
  if (facelets.length !== 54 && facelets.length !== 24) return false;
  const faceSize = facelets.length / 6;
  for (let face = 0; face < 6; face += 1) {
    const start = face * faceSize;
    const target = facelets[start + (faceSize === 9 ? 4 : 0)];
    if (!target) return false;
    for (let offset = 0; offset < faceSize; offset += 1) {
      if (facelets[start + offset] !== target) return false;
    }
  }
  return true;
}

export function normalizeMoveHistory(value) {
  if (!Array.isArray(value)) return [];
  return value.slice(0, 400).map((entry, index) => {
    const move = normalizeSmartMove(entry?.move ?? entry);
    const time = Number(entry?.t ?? entry?.atMs ?? index * 100);
    if (!move || !Number.isFinite(time) || time < 0) return null;
    return { move, t: Math.round(time * 10) / 10 };
  }).filter(Boolean).sort((a, b) => a.t - b.t);
}

export function analyzeMoveHistory(history, durationMs = null, pauseThresholdMs = 900) {
  const moves = normalizeMoveHistory(history);
  const duration = Number.isFinite(Number(durationMs)) && Number(durationMs) >= 0
    ? Number(durationMs)
    : (moves.length > 1 ? Math.max(0, moves.at(-1).t - moves[0].t) : 0);
  const gaps = [];
  for (let i = 1; i < moves.length; i += 1) gaps.push(Math.max(0, moves[i].t - moves[i - 1].t));
  const pauses = gaps.filter(gap => gap >= pauseThresholdMs);
  const faces = { U: 0, R: 0, F: 0, D: 0, L: 0, B: 0, rotations: 0 };
  moves.forEach(({ move }) => {
    const face = move[0];
    if (face in faces) faces[face] += 1;
    else if ('xyz'.includes(face)) faces.rotations += 1;
  });
  const largestPauseMs = pauses.length ? Math.max(...pauses) : 0;
  return {
    moveCount: moves.length,
    durationMs: duration,
    tps: duration > 0 ? moves.length / (duration / 1000) : 0,
    pauseCount: pauses.length,
    largestPauseMs,
    averageGapMs: gaps.length ? gaps.reduce((sum, gap) => sum + gap, 0) / gaps.length : 0,
    faces,
    moves
  };
}

export function createReplayRecord(input = {}) {
  const moves = normalizeMoveHistory(input.moves);
  const rawMs = Number(input.rawMs);
  if (!Number.isFinite(rawMs) || rawMs < 0 || !moves.length) {
    throw new TypeError('Replay cần thời gian hợp lệ và ít nhất một move.');
  }
  return {
    id: String(input.id || `smart-${Date.now().toString(36)}`),
    solveId: String(input.solveId || ''),
    puzzle: input.puzzle === '2x2' ? '2x2' : '3x3',
    cubeName: String(input.cubeName || 'Smart Cube').slice(0, 100),
    brand: String(input.brand || 'Unknown').slice(0, 40),
    serial: String(input.serial || '').slice(0, 100),
    scramble: String(input.scramble || '').slice(0, 500),
    rawMs: Math.round(rawMs),
    createdAt: String(input.createdAt || new Date().toISOString()),
    moves,
    stats: analyzeMoveHistory(moves, rawMs)
  };
}

export function encodeSignalDescription(description) {
  if (!description || !['offer', 'answer'].includes(description.type) || typeof description.sdp !== 'string' || !description.sdp.startsWith('v=0')) {
    throw new TypeError('Mã kết nối WebRTC không hợp lệ.');
  }
  const text = JSON.stringify({ v: 1, type: description.type, sdp: description.sdp });
  if (text.length > 120000) throw new RangeError('Mã kết nối quá dài.');
  return text;
}

export function decodeSignalDescription(value, expectedType = null) {
  const text = String(value ?? '').trim();
  if (!text || text.length > 120000) throw new TypeError('Mã kết nối trống hoặc quá dài.');
  let parsed;
  try { parsed = JSON.parse(text); } catch { throw new TypeError('Mã kết nối phải là JSON được sao chép đầy đủ.'); }
  if (parsed?.v !== 1 || !['offer', 'answer'].includes(parsed.type) || typeof parsed.sdp !== 'string' || !parsed.sdp.startsWith('v=0') || parsed.sdp.length > 100000) {
    throw new TypeError('Mã kết nối không đúng định dạng Smart Cube Arena.');
  }
  if (expectedType && parsed.type !== expectedType) throw new TypeError(`Cần mã ${expectedType === 'offer' ? 'mời' : 'trả lời'} để tiếp tục.`);
  return { type: parsed.type, sdp: parsed.sdp };
}
