# Changelog — V12 + V13

## V12 · Statistics and analytics
- Bổ sung bộ lọc Statistics theo session, puzzle và khoảng ngày.
- Thống nhất bộ lọc giữa số liệu, biểu đồ, bảng solve và xuất CSV.
- Bổ sung Best Ao100, Current Ao50 và tổng hợp tuần/tháng.

## V13 · Cubie-level 3D visualizer
- Thay mô hình cube 3D kiểu phẳng bằng 26 cubie riêng, mỗi cubie có sáu mặt và hướng sticker rõ ràng.
- Nút 3D trong thư viện mở trực tiếp trạng thái case; ẩn dãy move ở chế độ nhận diện.
- Dựng trạng thái case bằng công thức nghịch đảo; xác minh 256 công thức đang có có thể đưa cube về trạng thái đã giải khi áp dụng công thức tương ứng.
- Chỉ khi người dùng chủ động bấm “Phát công thức từ trạng thái case” mới chuyển sang trình tự các move.
- Xoay lớp cubie có animation; sau animation, trạng thái được commit bởi cube engine.
- Hỗ trợ camera drag/pointer, zoom responsive, reset góc nhìn và animation vào case.
- Sửa lỗi CSS flattening do `filter` / opacity trên phần tử `preserve-3d`, sửa hướng sticker U/D, và đổi dấu góc hoạt ảnh CSS cho đúng với hệ tọa độ màn hình.
- Bổ sung kiểm thử lớp xoay, hướng sticker, preview case, responsive sizing và giữ preserve-3d.

## Kiểm thử
- `npm test`: 64/64 đạt.
- `node --check` trên mọi module JS và service worker: đạt.
- Chromium headless dựng thử mô hình từ CSS thực tế: 26 cubie và các mặt U/F/R hiển thị đúng; kiểm tra hình ảnh hoạt ảnh lớp R.
- Kiểm tra E2E toàn ứng dụng qua local server chưa thực hiện được vì sandbox chặn Chromium điều hướng tới localhost/file URL.
