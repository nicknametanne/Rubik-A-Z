import {
  createDefaultData, loadData, saveData, generatePracticeScramble, generateCubePracticeScramble,
  getSessionSolves, averageOf, bestAverage, meanOf, effectiveTime, formatTime,
  parseTime, makeId, isValidAlgorithm, inspectionPenalty, isValidNotation, scheduleReview, normalizeReview, migrateData
} from './core.js';
import { CFOP_CASES, F2L_CASES } from './cfop-data.js';
import { createSolvedCube, applyCubeMoves, parseCubeMoves, invertCubeMoves, cubeFaceGrids, createCubeFromFaceletString, cubeToFaceletString, isCubeSolved } from './cube.js';
import { FACE_ORDER, SOLVED_FACELETS, validateFacelets } from './solver.js';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const data = loadData();
const DEFAULT_TRAINING = { targetSeconds: 15, dailyMinutes: 30, weeklySolves: 100, completions: [] };
function normalizeTraining(training) {
  const source = training && typeof training === 'object' ? training : {};
  const normalized = { ...DEFAULT_TRAINING, ...source };
  const targetSeconds = Number(source.targetSeconds);
  const dailyMinutes = Number(source.dailyMinutes);
  const weeklySolves = Number(source.weeklySolves);
  normalized.targetSeconds = Number.isFinite(targetSeconds) && targetSeconds >= 1 && targetSeconds <= 600 ? targetSeconds : DEFAULT_TRAINING.targetSeconds;
  normalized.dailyMinutes = Number.isInteger(dailyMinutes) && dailyMinutes >= 5 && dailyMinutes <= 300 ? dailyMinutes : DEFAULT_TRAINING.dailyMinutes;
  normalized.weeklySolves = Number.isInteger(weeklySolves) && weeklySolves >= 1 && weeklySolves <= 2000 ? weeklySolves : DEFAULT_TRAINING.weeklySolves;
  normalized.completions = (Array.isArray(source.completions) ? source.completions : [])
    .filter(entry => entry && typeof entry.date === 'string')
    .map(entry => ({ date: entry.date, taskIds: Array.isArray(entry.taskIds) ? [...new Set(entry.taskIds.filter(id => typeof id === 'string'))] : [] }));
  return normalized;
}
data.training = normalizeTraining(data.training);
let solverFacelets = validateFacelets(data.solverDraft || SOLVED_FACELETS).valid ? (data.solverDraft || SOLVED_FACELETS) : SOLVED_FACELETS;
let solverWorker = null;
let solverReady = false;
let solverPending = false;
let solverRequestedFacelets = '';
let solverRequestId = 0;
let solverSolution = '';
let activePage = 'home';
let activeAlgorithmFilter = 'ALL';
let activeCaseFilter = 'ALL';
let searchIndex = [];
let currentScramble = generatePracticeScramble();
let scrambleCenterPuzzle = '3x3';
let timerState = 'idle';
let timerFrame = 0;
let startAt = 0;
let inspectionAt = 0;
let currentPenalty = 'none';
let solveSessionId = data.activeSessionId;
let solvePuzzle = '3x3';
let holdTimer = 0;
let holdActive = false;
let trainerQueue = [];
let trainerIndex = 0;
let trainerRevealed = false;
let visualizer = {
  moves: [], baseCube: createSolvedCube(), cube: createSolvedCube(), step: 0,
  label: 'Cube đã giải', interval: 0, rotationX: -24, rotationY: -32
};

function persist() {
  const ok = saveData(data);
  if (!ok) toast('Không thể lưu dữ liệu. Hãy kiểm tra dung lượng trình duyệt.', 'error');
  return ok;
}

function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
}

function activeSession() {
  return data.sessions.find(session => session.id === data.activeSessionId) || data.sessions[0];
}

function sessionSolves(sessionId = data.activeSessionId) {
  return getSessionSolves(data, sessionId);
}

function displayTime(ms) {
  return formatTime(ms, Number(data.settings.timerDecimals) === 3 ? 3 : 2);
}

function getCaseProgress(id) {
  const current = data.caseProgress[id];
  const normalized = normalizeReview(current);
  if (current) return { ...normalized, favorite: Boolean(current.favorite), customMoves: typeof current.customMoves === 'string' ? current.customMoves : '', note: typeof current.note === 'string' ? current.note : '' };
  return { ...normalized, favorite: false, customMoves: '', note: '' };
}

function caseMoves(item) {
  const custom = data.caseProgress[item.id]?.customMoves;
  return typeof custom === 'string' && custom.trim() ? custom.trim() : item.moves;
}

function reviewLabel(status) {
  return ({ new: 'Chưa học', learning: 'Đang học', known: 'Đã thuộc' })[status] || 'Chưa học';
}

function toast(message, kind = 'success') {
  const region = $('#toast-region');
  const node = document.createElement('div');
  node.className = `toast ${kind}`;
  node.innerHTML = `<span>${kind === 'error' ? '!' : '✓'}</span><p>${esc(message)}</p>`;
  region.append(node);
  window.setTimeout(() => node.classList.add('leaving'), 2600);
  window.setTimeout(() => node.remove(), 3000);
}

function openModal(title, body, onSubmit) {
  $('#modal-title').textContent = title;
  $('#modal-body').innerHTML = body;
  $('#modal-backdrop').classList.remove('hidden');
  const form = $('#modal-body form');
  if (form) {
    form.addEventListener('submit', event => {
      event.preventDefault();
      const result = onSubmit?.(new FormData(form));
      if (result !== false) closeModal();
    });
  }
  $('#modal-close').focus();
}

function closeModal() {
  $('#modal-backdrop').classList.add('hidden');
  $('#modal-body').innerHTML = '';
}

function navigate(page) {
  if (!$('#page-' + page)) return;
  activePage = page;
  $$('.page').forEach(node => node.classList.toggle('active', node.id === `page-${page}`));
  $$('.nav-item[data-page]').forEach(node => node.classList.toggle('active', node.dataset.page === page));
  const labels = { home: 'Tổng quan', timer: 'Timer', scrambles: 'Scramble Center', academy: 'CFOP Academy', algorithms: 'Thư viện thuật toán', trainer: 'Algorithm Trainer', solver: '3×3 Solver', training: 'Training Center', visualizer: 'Rubik 3D', stats: 'Thống kê', sessions: 'Sessions', explore: 'Khám phá Rubik', settings: 'Cài đặt' };
  $('#page-crumb').textContent = labels[page] || page;
  $('#sidebar').classList.remove('open');
  if (page === 'home') renderHome();
  if (page === 'timer') renderTimerPage();
  if (page === 'scrambles') renderScrambleCenter();
  if (page === 'academy') renderAcademy();
  if (page === 'algorithms') { renderCaseLibrary(); renderAlgorithms(); }
  if (page === 'trainer') renderTrainer();
  if (page === 'solver') renderSolver();
  if (page === 'training') renderTraining();
  if (page === 'stats') renderStats();
  if (page === 'sessions') renderSessions();
  if (page === 'explore') renderKnowledgeBase();
  if (page === 'visualizer') { populateVisualizerPresets(); renderVisualizer(); } else stopVisualizerPlayback();
  $('#app-content').focus({ preventScroll: true });
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function setTheme(theme) {
  data.settings.theme = theme === 'light' ? 'light' : 'dark';
  document.documentElement.dataset.theme = data.settings.theme;
  $('#theme-toggle').textContent = theme === 'light' ? '☾' : '☼';
  $$('[data-theme-choice]').forEach(button => button.classList.toggle('active', button.dataset.themeChoice === theme));
  persist();
}

function updateSessionLabels() {
  const session = activeSession();
  if (!session) return;
  $('#sidebar-session-name').textContent = session.name;
  $('#home-session-name').textContent = session.name;
  $('#timer-session-label').textContent = session.name;
  $('#home-session-sub').textContent = `${session.puzzle} · Buổi luyện tập đang hoạt động`;
}

function renderHome() {
  updateSessionLabels();
  const solves = sessionSolves();
  const finite = solves.filter(solve => Number.isFinite(effectiveTime(solve)));
  const best = finite.length ? Math.min(...finite.map(effectiveTime)) : null;
  $('#home-best').textContent = displayTime(best);
  $('#home-ao5').textContent = displayTime(bestAverage(solves, 5));
  $('#home-average').textContent = displayTime(meanOf(solves));
  $('#home-count').textContent = String(solves.length);
  const recent = solves.slice(-5).reverse();
  $('#home-recent').innerHTML = recent.length ? recent.map((solve, index) => `
    <div class="recent-row"><span class="recent-number">${solves.length - index}</span><strong>${displayTime(effectiveTime(solve))}</strong><span class="recent-date">${formatDate(solve.createdAt)}</span><span class="recent-tag ${solve.penalty === 'none' ? '' : 'penalty'}">${solve.penalty === 'none' ? 'OK' : esc(solve.penalty)}</span></div>`).join('') : `<div class="empty-state compact"><span class="empty-symbol">◷</span><strong>Chưa có lượt giải</strong><p>Những lượt solve đầu tiên sẽ xuất hiện ở đây.</p></div>`;
}

function formatDate(dateValue) {
  const date = new Date(dateValue);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat('vi-VN', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }).format(date);
}

function currentSolveMetrics() {
  const solves = sessionSolves();
  const finite = solves.map(effectiveTime).filter(Number.isFinite);
  return {
    solves,
    best: finite.length ? Math.min(...finite) : null,
    ao5: averageOf(solves, 5),
    ao12: averageOf(solves, 12)
  };
}

function renderTimerPage() {
  updateSessionLabels();
  $('#inspection-state').textContent = data.settings.inspection ? 'ON' : 'OFF';
  $('#inspection-toggle').classList.toggle('is-off', !data.settings.inspection);
  if ($('#timer-decimals')) $('#timer-decimals').value = String(data.settings.timerDecimals || 2);
  $('#timer-puzzle').value = activeSession().puzzle;
  $('#scramble-text').textContent = currentScramble;
  renderTimerMetrics();
  renderTimerHistory();
  renderSolveTable();
  cancelAnimationFrame(timerFrame);
  updateTimerDisplay();
}

function renderTimerMetrics() {
  const metrics = currentSolveMetrics();
  $('#timer-best').textContent = displayTime(metrics.best);
  $('#timer-ao5').textContent = displayTime(metrics.ao5);
  $('#timer-ao12').textContent = displayTime(metrics.ao12);
  $('#timer-count').textContent = String(metrics.solves.length);
}

function renderTimerHistory() {
  const solves = sessionSolves().slice(-5).reverse();
  $('#timer-history').innerHTML = solves.length ? solves.map((solve, i) => `
    <div class="mini-solve"><span>${sessionSolves().length - i}</span><strong>${displayTime(effectiveTime(solve))}</strong><small>${solve.penalty === 'none' ? 'OK' : esc(solve.penalty)}</small></div>`).join('') : `<div class="empty-state compact"><strong>Chưa có dữ liệu</strong><p>Hãy hoàn thành lượt solve đầu tiên.</p></div>`;
}

function renderSolveTable() {
  const solves = sessionSolves().slice().reverse();
  $('#solve-table').innerHTML = solves.length ? solves.map((solve, index) => `
    <tr><td class="table-index">${solves.length - index}</td><td><strong class="table-time">${displayTime(effectiveTime(solve))}</strong>${solve.penalty === '+2' ? '<small class="inline-penalty">+2</small>' : ''}</td><td class="scramble-cell" title="${esc(solve.scramble)}">${esc(solve.scramble || '—')}</td><td>${formatDate(solve.createdAt)}</td><td class="note-cell">${esc(solve.note || '—')}</td><td><div class="table-actions"><button data-edit-solve="${esc(solve.id)}" title="Sửa">✎</button><button data-delete-solve="${esc(solve.id)}" title="Xóa">×</button></div></td></tr>`).join('') : '<tr><td colspan="6" class="table-empty">Chưa có lượt giải trong session này.</td></tr>';
}

function setTimerState(status, statusText, hint) {
  timerState = status;
  $('#timer-status').textContent = statusText;
  $('#timer-hint').textContent = hint;
  $('#timer-display').classList.remove('is-running', 'is-ready', 'is-inspection');
  if (status === 'running') $('#timer-display').classList.add('is-running');
  if (status === 'ready') $('#timer-display').classList.add('is-ready');
  if (status === 'inspection') $('#timer-display').classList.add('is-inspection');
}

function updateTimerDisplay() {
  if (timerState === 'running') {
    const elapsed = performance.now() - startAt;
    $('#timer-time').textContent = displayTime(elapsed);
    timerFrame = requestAnimationFrame(updateTimerDisplay);
  } else if (timerState === 'inspection') {
    const left = Math.max(0, 15000 - (performance.now() - inspectionAt));
    $('#timer-time').textContent = displayTime(left);
    timerFrame = requestAnimationFrame(updateTimerDisplay);
  }
}

function startInspection() {
  cancelAnimationFrame(timerFrame);
  solveSessionId = data.activeSessionId;
  solvePuzzle = activeSession().puzzle;
  inspectionAt = performance.now();
  currentPenalty = 'none';
  setTimerState('inspection', 'INSPECTION', 'KIỂM TRA RUBIK · GIỮ SPACE ĐỂ SẴN SÀNG');
  $('#timer-time').textContent = '15.00';
  updateTimerDisplay();
}

function getInspectionPenalty() {
  if (!data.settings.inspection) return 'none';
  return inspectionPenalty(performance.now() - inspectionAt);
}

function beginSolve() {
  cancelAnimationFrame(timerFrame);
  if (timerState !== 'inspection' && timerState !== 'ready') {
    solveSessionId = data.activeSessionId;
    solvePuzzle = activeSession().puzzle;
  }
  currentPenalty = timerState === 'inspection' || timerState === 'ready' ? getInspectionPenalty() : 'none';
  startAt = performance.now();
  setTimerState('running', 'SOLVING', 'NHẤN SPACE HOẶC CHẠM ĐỂ DỪNG');
  $('#timer-time').textContent = displayTime(0);
  playBeep(660, 45);
  updateTimerDisplay();
}

function stopSolve() {
  if (timerState !== 'running') return;
  cancelAnimationFrame(timerFrame);
  const rawMs = Math.max(0, performance.now() - startAt);
  const solve = {
    id: makeId('solve'), sessionId: solveSessionId, puzzle: solvePuzzle,
    scramble: currentScramble, rawMs, penalty: currentPenalty, note: '', createdAt: new Date().toISOString()
  };
  data.solves.push(solve);
  currentScramble = generatePracticeScramble();
  $('#scramble-text').textContent = currentScramble;
  persist();
  setTimerState('stopped', 'SOLVE SAVED', 'NHẤN SPACE HOẶC CHẠM ĐỂ GIẢI TIẾP');
  $('#timer-time').textContent = displayTime(effectiveTime(solve));
  playBeep(880, 70);
  renderTimerMetrics();
  renderTimerHistory();
  renderSolveTable();
  renderHome();
  toast(`Đã lưu lượt solve: ${displayTime(effectiveTime(solve))}`);
}

function timerTap() {
  if (timerState === 'running') return stopSolve();
  if (timerState === 'inspection') return beginSolve();
  if (timerState === 'ready') return beginSolve();
  if (data.settings.inspection) startInspection();
  else beginSolve();
}

function handleSpaceDown(event) {
  if (event.code !== 'Space' || event.repeat || isTypingTarget(event.target) || (event.target instanceof HTMLElement && event.target.closest('button') && event.target.id !== 'timer-display')) return;
  if (activePage !== 'timer' && timerState !== 'running') return;
  event.preventDefault();
  if (timerState === 'running') return stopSolve();
  if (activePage !== 'timer') return;
  if (timerState === 'idle' || timerState === 'stopped') {
    if (data.settings.inspection) startInspection();
    else {
      solveSessionId = data.activeSessionId;
      solvePuzzle = activeSession().puzzle;
      setTimerState('ready', 'HOLD TO READY', 'GIỮ SPACE ĐỂ CHUẨN BỊ');
    }
  }
  holdActive = true;
  if (timerState === 'inspection') setTimerState('inspection', 'INSPECTION', 'GIỮ SPACE ĐỂ SẴN SÀNG');
  if (timerState === 'inspection' || timerState === 'ready') {
    holdTimer = window.setTimeout(() => {
      if (!holdActive || !['inspection', 'ready'].includes(timerState)) return;
      setTimerState('ready', 'READY', 'THẢ SPACE ĐỂ BẮT ĐẦU');
      $('#timer-time').textContent = displayTime(0);
      cancelAnimationFrame(timerFrame);
    }, 350);
  }
}

function handleSpaceUp(event) {
  if (event.code !== 'Space' || isTypingTarget(event.target) || (event.target instanceof HTMLElement && event.target.closest('button') && event.target.id !== 'timer-display') || activePage !== 'timer') return;
  event.preventDefault();
  holdActive = false;
  window.clearTimeout(holdTimer);
  if (timerState === 'ready') beginSolve();
}

function isTypingTarget(target) {
  return target instanceof HTMLElement && (target.isContentEditable || ['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName));
}


function playBeep(frequency = 660, duration = 50) {
  if (!data.settings.sound) return;
  try {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return;
    const context = new AudioContextClass();
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    oscillator.frequency.value = frequency;
    gain.gain.setValueAtTime(0.045, context.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, context.currentTime + duration / 1000);
    oscillator.connect(gain); gain.connect(context.destination);
    oscillator.start(); oscillator.stop(context.currentTime + duration / 1000);
    oscillator.onended = () => context.close();
  } catch { /* Audio is optional; timer remains usable without it. */ }
}

function newScramble() {
  if (timerState === 'running') return toast('Hãy dừng timer trước khi tạo scramble mới.', 'error');
  currentScramble = generatePracticeScramble();
  $('#scramble-text').textContent = currentScramble;
  toast('Đã tạo scramble mới.');
}

function addManualSolve() {
  const body = `<form class="modal-form"><label>Thời gian gốc <input name="time" placeholder="Ví dụ: 18.42 hoặc 1:02.35" required autofocus /></label><label>Penalty<select name="penalty"><option value="none">Không có</option><option value="+2">+2 giây</option><option value="DNF">DNF</option></select></label><label>Scramble <textarea name="scramble" rows="2">${esc(currentScramble)}</textarea></label><label>Ghi chú <input name="note" placeholder="Không bắt buộc" /></label><div class="modal-actions"><button type="button" class="secondary-button" data-cancel-modal>Hủy</button><button class="primary-button" type="submit">Lưu lượt giải</button></div></form>`;
  openModal('Nhập lượt solve', body, form => {
    const rawMs = parseTime(form.get('time'));
    if (rawMs === null || rawMs <= 0) { toast('Thời gian không hợp lệ. Ví dụ: 18.42 hoặc 1:02.35.', 'error'); return false; }
    data.solves.push({ id: makeId('solve'), sessionId: data.activeSessionId, puzzle: activeSession().puzzle, rawMs, penalty: form.get('penalty'), scramble: String(form.get('scramble')).trim(), note: String(form.get('note')).trim(), createdAt: new Date().toISOString() });
    persist(); renderTimerPage(); renderHome(); toast('Đã thêm lượt solve thủ công.');
  });
}

function editSolve(id) {
  const solve = data.solves.find(item => item.id === id);
  if (!solve) return;
  const body = `<form class="modal-form"><label>Thời gian gốc (giây) <input name="time" value="${(solve.rawMs / 1000).toFixed(2)}" required /></label><label>Penalty<select name="penalty"><option value="none" ${solve.penalty === 'none' ? 'selected' : ''}>Không có</option><option value="+2" ${solve.penalty === '+2' ? 'selected' : ''}>+2 giây</option><option value="DNF" ${solve.penalty === 'DNF' ? 'selected' : ''}>DNF</option></select></label><label>Ghi chú <input name="note" value="${esc(solve.note || '')}" /></label><div class="modal-actions"><button type="button" class="secondary-button" data-cancel-modal>Hủy</button><button class="primary-button" type="submit">Lưu thay đổi</button></div></form>`;
  openModal('Chỉnh sửa lượt solve', body, form => {
    const rawMs = parseTime(form.get('time'));
    if (rawMs === null || rawMs <= 0) { toast('Thời gian không hợp lệ.', 'error'); return false; }
    solve.rawMs = rawMs; solve.penalty = form.get('penalty'); solve.note = String(form.get('note')).trim();
    persist(); renderTimerPage(); renderStats(); renderHome(); toast('Đã cập nhật lượt solve.');
  });
}

function deleteSolve(id) {
  const solve = data.solves.find(item => item.id === id);
  if (!solve || !confirm(`Xóa lượt ${displayTime(effectiveTime(solve))}? Thao tác này không thể hoàn tác.`)) return;
  data.solves = data.solves.filter(item => item.id !== id);
  persist(); renderTimerPage(); renderStats(); renderHome(); toast('Đã xóa lượt solve.');
}

function renderAlgorithms() {
  const query = $('#algorithm-search').value.trim().toLowerCase();
  const algorithms = data.algorithms.filter(alg => (activeAlgorithmFilter === 'ALL' || alg.type === activeAlgorithmFilter) && `${alg.name} ${alg.moves} ${alg.notes || ''}`.toLowerCase().includes(query));
  $('#alg-count-all').textContent = String(data.algorithms.length);
  $('#algorithm-grid').innerHTML = algorithms.length ? algorithms.map(alg => `
    <article class="algorithm-card"><div class="algorithm-card-top"><span class="alg-type ${alg.type.toLowerCase()}">${alg.type}</span><div class="alg-card-actions"><button data-favorite-alg="${esc(alg.id)}" title="Yêu thích">${alg.favorite ? '★' : '☆'}</button><button data-edit-alg="${esc(alg.id)}" title="Sửa">✎</button><button data-delete-alg="${esc(alg.id)}" title="Xóa">×</button></div></div><h3>${esc(alg.name)}</h3><div class="algorithm-formula">${esc(alg.moves)}</div><p>${esc(alg.notes || 'Chưa có ghi chú.')}</p><div class="algorithm-card-bottom"><span class="mastery ${alg.mastered ? 'done' : ''}">${alg.mastered ? '✓ Đã thuộc' : '○ Đang học'}</span><button class="text-button" data-train-alg="${esc(alg.id)}">Luyện tập →</button></div></article>`).join('') : `<div class="empty-state full-span"><span class="empty-symbol">▦</span><strong>${data.algorithms.length ? 'Không tìm thấy công thức' : 'Thư viện đang trống'}</strong><p>${data.algorithms.length ? 'Thử thay đổi từ khóa hoặc bộ lọc.' : 'Thêm công thức đầu tiên để bắt đầu xây dựng bộ sưu tập của bạn.'}</p>${data.algorithms.length ? '' : '<button class="primary-button" id="empty-add-alg">＋ Thêm công thức</button>'}</div>`;
}

function isValidMoves(moves) {
  const tokens = moves.trim().split(/\s+/).filter(Boolean);
  if (!tokens.length) return false;
  return isValidNotation(moves);
}

function addAlgorithm(existing = null) {
  const alg = existing || { name: '', type: 'OLL', moves: '', notes: '', favorite: false, mastered: false };
  const body = `<form class="modal-form"><label>Tên trường hợp <input name="name" value="${esc(alg.name)}" placeholder="Ví dụ: T-perm" required /></label><label>Nhóm<select name="type">${['OLL', 'PLL', 'F2L', 'OTHER'].map(type => `<option value="${type}" ${alg.type === type ? 'selected' : ''}>${type}</option>`).join('')}</select></label><label>Công thức <textarea name="moves" rows="3" placeholder="R U R' U'..." required>${esc(alg.moves)}</textarea><small class="field-hint">Nhập ký hiệu cơ bản, phân tách các move bằng dấu cách. Ví dụ: R U R' U'.</small></label><label>Ghi chú <textarea name="notes" rows="2" placeholder="Mẹo nhận diện, hướng cầm...">${esc(alg.notes || '')}</textarea></label><div class="modal-actions"><button type="button" class="secondary-button" data-cancel-modal>Hủy</button><button class="primary-button" type="submit">${existing ? 'Lưu thay đổi' : 'Thêm vào thư viện'}</button></div></form>`;
  openModal(existing ? 'Chỉnh sửa công thức' : 'Thêm công thức', body, form => {
    const name = String(form.get('name')).trim();
    const moves = String(form.get('moves')).trim();
    if (!name || !isValidMoves(moves)) { toast('Tên hoặc định dạng công thức chưa hợp lệ. Kiểm tra ký hiệu và dấu cách.', 'error'); return false; }
    const values = { name, type: form.get('type'), moves, notes: String(form.get('notes')).trim() };
    if (existing) Object.assign(existing, values);
    else data.algorithms.push({ id: makeId('alg'), ...values, favorite: false, mastered: false, createdAt: new Date().toISOString() });
    persist(); renderAlgorithms(); renderTrainer(); toast(existing ? 'Đã cập nhật công thức.' : 'Đã thêm công thức.');
  });
}

function editCaseAlgorithm(id) {
  const item = CFOP_CASES.find(entry => entry.id === id);
  if (!item) return;
  const progress = getCaseProgress(id);
  const body = `<form class="modal-form"><label>Case <input value="${esc(item.name)}" disabled /></label><label>Công thức của bạn <textarea name="moves" rows="3" placeholder="${esc(item.moves)}">${esc(progress.customMoves || item.moves)}</textarea><small class="field-hint">Để trống để dùng lại công thức tham chiếu. Ký hiệu được kiểm tra trước khi lưu.</small></label><label>Ghi chú nhận diện <textarea name="note" rows="2" placeholder="Hướng cầm, mẹo nhận diện...">${esc(progress.note)}</textarea></label><div class="modal-actions"><button type="button" class="secondary-button" data-cancel-modal>Hủy</button><button class="primary-button" type="submit">Lưu tùy chỉnh</button></div></form>`;
  openModal(`Tùy chỉnh ${item.name}`, body, form => {
    const moves = String(form.get('moves')).trim();
    if (moves && !isValidNotation(moves)) { toast('Công thức có ký hiệu không hợp lệ.', 'error'); return false; }
    data.caseProgress[id] = { ...progress, customMoves: moves && moves !== item.moves ? moves : '', note: String(form.get('note')).trim() };
    persist(); renderCaseLibrary(); toast('Đã lưu tùy chỉnh case.');
  });
}

function buildTrainerQueue() {
  const type = $('#trainer-type').value;
  const now = Date.now();
  const cases = CFOP_CASES.filter(item => type === 'ALL' || item.type === type).map(item => {
    const review = getCaseProgress(item.id);
    return { key: item.id, kind: 'case', item, type: item.type, name: item.name, moves: caseMoves(item), review };
  });
  const custom = data.algorithms.filter(alg => type === 'ALL' || type === 'CUSTOM' || alg.type === type).map(alg => ({
    key: `CUSTOM-${alg.id}`, kind: 'custom', item: alg, type: alg.type, name: alg.name, moves: alg.moves,
    review: normalizeReview(alg.review, alg.mastered)
  }));
  let queue;
  if (type === 'ALL') queue = [...cases, ...custom];
  else if (['F2L', 'OLL', 'PLL'].includes(type)) queue = [...cases, ...custom.filter(entry => entry.type === type)];
  else queue = custom;
  if ($('#trainer-due-only').checked) queue = queue.filter(entry => entry.review.status === 'new' || entry.review.dueAt <= now);
  return queue.sort((a, b) => a.review.dueAt - b.review.dueAt || a.name.localeCompare(b.name));
}

function renderTrainer() {
  trainerQueue = buildTrainerQueue();
  trainerIndex = Math.min(trainerIndex, Math.max(0, trainerQueue.length - 1));
  showTrainerCard();
}

function showTrainerCard() {
  const current = trainerQueue[trainerIndex];
  trainerRevealed = false;
  const selectedType = $('#trainer-type').value;
  const allCases = CFOP_CASES.filter(item => selectedType === 'ALL' || item.type === selectedType);
  const known = allCases.filter(item => getCaseProgress(item.id).status === 'known').length;
  const total = allCases.length;
  const groupLabel = total ? `${known} / ${total} case ${selectedType === 'ALL' ? 'CFOP' : selectedType} đã thuộc` : `${data.algorithms.filter(alg => selectedType === 'CUSTOM' || selectedType === 'ALL' || alg.type === selectedType).length} công thức cá nhân`;
  $('#trainer-progress-label').textContent = groupLabel;
  $('#trainer-progress-count').textContent = trainerQueue.length ? `${trainerIndex + 1} / ${trainerQueue.length}` : '0 / 0';
  $('#trainer-progress-bar').style.width = total ? `${(known / total) * 100}%` : '0%';
  $('#trainer-category').textContent = current?.type || selectedType;
  $('#trainer-name').textContent = current?.name || 'Không có case đến hạn';
  $('#trainer-prompt').textContent = current ? `${current.kind === 'case' ? 'Nhận diện case chuẩn.' : 'Công thức cá nhân.'} Tự nhớ công thức trước khi mở đáp án. Trạng thái: ${reviewLabel(current.review.status)}.` : 'Không có mục nào cần ôn theo bộ lọc hiện tại. Hãy tắt “Chỉ đến hạn” để xem toàn bộ thư viện.';
  $('#trainer-formula').textContent = current?.moves || '';
  $('#trainer-formula').classList.add('hidden');
  $('#reveal-formula').disabled = !current;
  $$('[data-trainer-rating]').forEach(button => { button.disabled = !current; });
  $('#flashcard').classList.remove('revealed');
  $('#reveal-formula').innerHTML = 'Hiện công thức <span>↓</span>';
}

function trainerNext(rating) {
  const current = trainerQueue[trainerIndex];
  if (!current) return;
  const updated = scheduleReview(current.review, rating);
  if (current.kind === 'case') {
    data.caseProgress[current.item.id] = { ...getCaseProgress(current.item.id), ...updated };
  } else {
    current.item.review = updated;
    current.item.mastered = updated.status === 'known';
    current.item.lastReviewedAt = new Date(updated.lastReviewedAt).toISOString();
  }
  persist();
  renderCaseLibrary();
  renderTrainer();
  if (!trainerQueue.length) toast('Đã ôn xong các mục đến hạn.');
}

function trainCase(id) {
  const item = CFOP_CASES.find(entry => entry.id === id);
  const custom = data.algorithms.find(entry => `CUSTOM-${entry.id}` === id);
  const selected = item || custom;
  if (!selected) return;
  $('#trainer-type').value = item ? item.type : (custom.type === 'F2L' || custom.type === 'OTHER' ? custom.type : 'CUSTOM');
  $('#trainer-due-only').checked = false;
  navigate('trainer');
  const key = item ? item.id : `CUSTOM-${custom.id}`;
  const index = trainerQueue.findIndex(entry => entry.key === key);
  if (index >= 0) trainerIndex = index;
  showTrainerCard();
}

function stickerDirectionLabel(direction) {
  return ({ front: 'trước', back: 'sau', left: 'trái', right: 'phải', up: 'trên', down: 'dưới' })[direction] || '—';
}

function renderCaseLibrary() {
  const query = $('#case-search').value.trim().toLowerCase();
  const now = Date.now();
  const progresses = CFOP_CASES.map(item => ({ item, progress: getCaseProgress(item.id) }));
  const knownCount = type => progresses.filter(row => row.item.type === type && row.progress.status === 'known').length;
  const dueCount = progresses.filter(row => row.progress.status === 'new' || row.progress.dueAt <= now).length;
  $('#f2l-mastered-count').textContent = `${knownCount('F2L')} / 41`;
  $('#oll-mastered-count').textContent = `${knownCount('OLL')} / 57`;
  $('#pll-mastered-count').textContent = `${knownCount('PLL')} / 21`;
  $('#case-due-count').textContent = String(dueCount);
  const filtered = progresses.filter(({ item, progress }) => {
    if (['F2L', 'OLL', 'PLL'].includes(activeCaseFilter) && item.type !== activeCaseFilter) return false;
    if (activeCaseFilter === 'DUE' && !(progress.status === 'new' || progress.dueAt <= now)) return false;
    if (activeCaseFilter === 'FAVORITE' && !progress.favorite) return false;
    return `${item.name} ${item.type} ${item.moves} ${item.family || ''} ${item.whiteSticker || ''}`.toLowerCase().includes(query);
  });
  $('#case-grid').innerHTML = filtered.map(({ item, progress }) => `
    <article class="case-card ${progress.status === 'known' ? 'is-known' : ''}">
      <div class="case-card-head"><span class="alg-type ${item.type.toLowerCase()}">${item.type}</span><button class="case-favorite ${progress.favorite ? 'active' : ''}" data-case-favorite="${item.id}" title="Yêu thích" aria-label="Yêu thích">${progress.favorite ? '★' : '☆'}</button></div>
      <div class="case-card-title"><strong>${esc(item.name)}</strong>${item.twoLook ? '<span class="case-chip">2-look</span>' : ''}</div>
      ${item.family ? `<div class="case-family">${esc(item.family)} · Sticker trắng: ${esc(stickerDirectionLabel(item.whiteSticker))}</div>` : ''}
      <div class="case-formula" title="${esc(caseMoves(item))}">${esc(caseMoves(item))}</div>
      <div class="case-card-foot"><span class="mastery ${progress.status === 'known' ? 'done' : ''}">${reviewLabel(progress.status)}</span><div class="case-card-actions"><button data-copy-case="${item.id}" title="Sao chép">Copy</button><button data-edit-case="${item.id}" title="Tùy chỉnh công thức">Sửa</button><button data-train-case="${item.id}" title="Luyện tập">Luyện</button><button data-visualize-case="${item.id}" title="Xem mô phỏng 3D">3D</button></div></div>
    </article>`).join('') || '<div class="empty-state full-span"><strong>Không có case phù hợp</strong><p>Thử đổi bộ lọc hoặc từ khóa tìm kiếm.</p></div>';
}

function stopVisualizerPlayback() {
  if (visualizer.interval) window.clearInterval(visualizer.interval);
  visualizer.interval = 0;
  const playButton = $('#viz-play');
  if (playButton) playButton.textContent = '▶ Phát';
}

function populateVisualizerPresets() {
  const select = $('#viz-preset');
  if (select.dataset.ready === 'true') return;
  const groups = [
    ['F2L', F2L_CASES],
    ['OLL', CFOP_CASES.filter(item => item.type === 'OLL')],
    ['PLL', CFOP_CASES.filter(item => item.type === 'PLL')]
  ];
  select.innerHTML = '<option value="">Chọn F2L / OLL / PLL...</option>' + groups.map(([name, items]) =>
    `<optgroup label="${name}">${items.map(item => `<option value="${item.id}">${item.name} · ${item.moves.split(/\s+/).length} move</option>`).join('')}</optgroup>`
  ).join('');
  select.dataset.ready = 'true';
}

function renderVisualizer() {
  const grids = cubeFaceGrids(visualizer.cube);
  $$('[data-cube-face]').forEach(faceNode => {
    const face = faceNode.dataset.cubeFace;
    faceNode.innerHTML = grids[face].map(color => `<i class="viz-sticker" style="--sticker-color:${color}"></i>`).join('');
  });
  $('#viz-cube').style.transform = `rotateX(${visualizer.rotationX}deg) rotateY(${visualizer.rotationY}deg)`;
  const total = visualizer.moves.length;
  const current = visualizer.step ? visualizer.moves[visualizer.step - 1] : '—';
  $('#viz-current-move').textContent = current;
  $('#viz-step-count').textContent = `${visualizer.step} / ${total} move`;
  $('#viz-progress').max = String(total);
  $('#viz-progress').value = String(visualizer.step);
  $('#viz-progress-label').textContent = `${total ? Math.round((visualizer.step / total) * 100) : 0}%`;
  $('#viz-state-label').textContent = visualizer.label;
  $('#viz-previous').disabled = visualizer.step === 0;
  $('#viz-next').disabled = visualizer.step >= total;
  $('#viz-move-list').innerHTML = total ? visualizer.moves.map((move, index) => `<button class="viz-move ${index < visualizer.step ? 'is-done' : ''} ${index === visualizer.step - 1 ? 'is-current' : ''}" data-viz-jump="${index + 1}" title="Đến move ${index + 1}">${move}</button>`).join('') : '<span class="muted small-note">Nhập thuật toán hoặc chọn công thức để bắt đầu.</span>';
}

function setVisualizerStep(step) {
  stopVisualizerPlayback();
  visualizer.step = Math.max(0, Math.min(visualizer.moves.length, Number(step) || 0));
  visualizer.cube = applyCubeMoves(visualizer.baseCube, visualizer.moves.slice(0, visualizer.step).join(' '));
  renderVisualizer();
}

function loadVisualizerSequence(sequence, { reverseStart = false, label = 'Thuật toán tùy chỉnh', baseCube = null } = {}) {
  let tokens;
  try { tokens = parseCubeMoves(sequence); }
  catch (error) { toast(`Ký hiệu chưa hỗ trợ: ${error.message}`, 'error'); return false; }
  if (!tokens.length) { toast('Hãy nhập ít nhất một move hợp lệ.', 'error'); return false; }
  stopVisualizerPlayback();
  visualizer.moves = tokens;
  visualizer.baseCube = baseCube ? baseCube.map(sticker => ({ position: [...sticker.position], normal: [...sticker.normal], color: sticker.color })) : (reverseStart
    ? applyCubeMoves(createSolvedCube(), invertCubeMoves(tokens).join(' '))
    : createSolvedCube());
  visualizer.cube = visualizer.baseCube;
  visualizer.step = 0;
  visualizer.label = label;
  $('#viz-sequence').value = tokens.join(' ');
  $('#viz-state-help').textContent = reverseStart
    ? 'Trạng thái ban đầu được dựng từ chuỗi nghịch đảo; phát công thức để quay về cube đã giải.'
    : 'Đang phát từ cube đã giải. Kéo chuột hoặc vuốt để đổi góc nhìn.';
  renderVisualizer();
  return true;
}

function jumpVisualizerToAlgorithm(id) {
  const item = CFOP_CASES.find(entry => entry.id === id);
  if (!item) return;
  navigate('visualizer');
  $('#viz-preset').value = item.id;
  loadVisualizerSequence(caseMoves(item), { reverseStart: true, label: `${item.name} · ${item.type}` });
}

function toggleVisualizerPlayback() {
  if (visualizer.interval) return stopVisualizerPlayback();
  if (!visualizer.moves.length) return toast('Hãy tải một thuật toán trước.', 'error');
  if (visualizer.step >= visualizer.moves.length) setVisualizerStep(0);
  $('#viz-play').textContent = 'Ⅱ Tạm dừng';
  const delay = Number($('#viz-speed').value) || 520;
  visualizer.interval = window.setInterval(() => {
    if (visualizer.step >= visualizer.moves.length) return stopVisualizerPlayback();
    visualizer.step += 1;
    visualizer.cube = applyCubeMoves(visualizer.cube, visualizer.moves[visualizer.step - 1]);
    renderVisualizer();
    if (visualizer.step >= visualizer.moves.length) stopVisualizerPlayback();
  }, delay);
}

function localDateKey(value = new Date()) {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function countRecentSolves(solves, days = 7) {
  const cutoff = Date.now() - days * 86400000;
  return solves.filter(solve => new Date(solve.createdAt).getTime() >= cutoff).length;
}

function activityStreak(solves) {
  const activeDates = new Set(solves.map(solve => localDateKey(solve.createdAt)).filter(Boolean));
  const cursor = new Date();
  if (!activeDates.has(localDateKey(cursor))) cursor.setDate(cursor.getDate() - 1);
  let streak = 0;
  while (activeDates.has(localDateKey(cursor))) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}

function getTodayCompletion() {
  const today = localDateKey();
  return data.training.completions.find(entry => entry.date === today) || { date: today, taskIds: [] };
}

const TRAINING_TASKS = [
  { id: 'cross', title: 'Cross efficiency', tag: 'CROSS', detail: 'Luyện 5 lần Cross chậm; ưu tiên nhìn trước và giảm move thừa.', minutes: 8, page: 'timer' },
  { id: 'f2l', title: 'F2L lookahead', tag: 'F2L', detail: 'Luyện 10 cặp ở tốc độ vừa; tập trung giảm khoảng dừng giữa hai cặp.', minutes: 10, page: 'algorithms' },
  { id: 'last-layer', title: 'OLL / PLL recognition', tag: 'LAST LAYER', detail: 'Ôn 10 case đến hạn, nhận diện trước khi mở công thức.', minutes: 7, page: 'trainer' },
  { id: 'full-solves', title: 'Full solves', tag: 'FULL SOLVE', detail: 'Thực hiện 5 lượt solve có kiểm soát; ghi chú giai đoạn bị chậm.', minutes: 5, page: 'timer' }
];

function renderTraining() {
  const solves = data.solves;
  const today = getTodayCompletion();
  const completed = new Set(today.taskIds);
  const weekCount = countRecentSolves(solves, 7);
  const streak = activityStreak(solves);
  $('#training-week-solves').textContent = `${weekCount} / ${data.training.weeklySolves}`;
  $('#training-daily-progress').textContent = `${completed.size} / ${TRAINING_TASKS.length}`;
  $('#training-streak').textContent = `${streak} ngày`;
  $('#training-date-label').textContent = new Intl.DateTimeFormat('vi-VN', { weekday: 'long', day: '2-digit', month: '2-digit' }).format(new Date());
  $('#training-task-list').innerHTML = TRAINING_TASKS.map(task => {
    const duration = Math.max(1, Math.round(task.minutes * data.training.dailyMinutes / 30));
    return `
    <article class="training-task ${completed.has(task.id) ? 'is-complete' : ''}">
      <button class="training-check" data-training-task="${task.id}" aria-label="${completed.has(task.id) ? 'Bỏ hoàn thành' : 'Đánh dấu hoàn thành'}" aria-pressed="${completed.has(task.id)}">${completed.has(task.id) ? '✓' : ''}</button>
      <div class="training-task-copy"><div><span class="training-task-tag">${task.tag}</span><small>${duration} phút</small></div><h4>${task.title}</h4><p>${task.detail}</p></div>
      <button class="text-button training-task-link" data-go="${task.page}">Mở bài →</button>
    </article>`;
  }).join('');
  const percentage = Math.round(completed.size / TRAINING_TASKS.length * 100);
  $('#training-progress-bar').style.width = `${percentage}%`;
  $('#training-progress-label').textContent = `${percentage}% hoàn thành`;
  $('#training-target-time').value = String(data.training.targetSeconds);
  $('#training-daily-minutes').value = String(data.training.dailyMinutes);
  $('#training-weekly-goal').value = String(data.training.weeklySolves);
  const bestSingle = solves.map(effectiveTime).filter(Number.isFinite).reduce((best, value) => Math.min(best, value), Infinity);
  $('#training-goal-summary').textContent = Number.isFinite(bestSingle)
    ? `Mục tiêu single: ${data.training.targetSeconds}s · PB hiện tại: ${displayTime(bestSingle)}.`
    : `Mục tiêu single: ${data.training.targetSeconds}s · Chưa có solve được lưu để so sánh.`;
}

function renderSolver() {
  const colors = { U: '#f5f3ea', R: '#e34f4f', F: '#32aa70', D: '#f0d23c', L: '#ff963f', B: '#3978df' };
  const faces = [...FACE_ORDER];
  $('#solver-net').innerHTML = faces.map(face => {
    const faceIndex = FACE_ORDER.indexOf(face);
    const tiles = Array.from({ length: 9 }, (_, index) => {
      const globalIndex = faceIndex * 9 + index;
      const color = solverFacelets[globalIndex];
      const fixed = index === 4;
      return `<button class="solver-sticker ${fixed ? 'is-center' : ''}" data-solver-sticker="${globalIndex}" style="--sticker:${colors[color]}" aria-label="Mặt ${face}, ô ${index + 1}: ${color}" ${fixed ? 'disabled' : ''}><span>${color}</span></button>`;
    }).join('');
    return `<div class="solver-net-face" data-net-face="${face}"><div class="solver-face-title">${face}</div><div class="solver-face-grid">${tiles}</div></div>`;
  }).join('');
  const validation = validateFacelets(solverFacelets);
  $('#solver-validation').textContent = validation.valid ? '✓ Trạng thái hợp lệ: đủ 54 ô, đúng tâm, đúng viên góc/cạnh và parity.' : `! ${validation.error}`;
  $('#solver-validation').classList.toggle('is-valid', validation.valid);
  $('#solver-validation').classList.toggle('is-invalid', !validation.valid);
  $('#solver-solve').disabled = !validation.valid || solverPending;
  if (solverSolution) $('#solver-result').classList.remove('hidden');
}

function setSolverStatus(title, detail, progress = 0, isError = false) {
  $('#solver-status-title').textContent = title;
  $('#solver-status-detail').textContent = detail;
  $('#solver-status-bar').style.width = `${Math.max(0, Math.min(100, progress))}%`;
  $('#solver-status-bar').classList.toggle('is-error', isError);
}

function ensureSolverWorker() {
  if (solverWorker) return;
  try {
    solverWorker = new Worker(new URL('./solver-worker.js', import.meta.url));
    solverWorker.onmessage = event => {
      const message = event.data || {};
      if (message.type === 'ready') {
        solverReady = true;
        setSolverStatus('Solver đã sẵn sàng', 'Bảng tra cứu Kociemba đã được tạo. Dữ liệu được xử lý trong trình duyệt.', 100);
        if (solverPending && solverRequestedFacelets) solverWorker.postMessage({ type: 'solve', facelets: solverRequestedFacelets, requestId: solverRequestId });
        return;
      }
      if (message.type === 'solution') {
        if (message.requestId !== solverRequestId) return;
        solverPending = false;
        solverSolution = message.solution || '';
        $('#solver-result').classList.remove('hidden');
        $('#solver-move-count').textContent = String(message.moves);
        $('#solver-algorithm').textContent = solverSolution || 'Cube đã được giải.';
        $('#solver-solve').disabled = false;
        setSolverStatus('Đã tìm thấy lời giải', `Đã xác minh bằng cách áp dụng ngược lại lên trạng thái nhập. ${message.moves} move.`, 100);
        toast('Đã giải và xác minh trạng thái Rubik.');
        return;
      }
      if (message.type === 'solve-error' || message.type === 'error') {
        if (message.requestId !== undefined && message.requestId !== solverRequestId) return;
        solverPending = false;
        $('#solver-solve').disabled = false;
        setSolverStatus('Không thể giải cube', message.message || 'Solver gặp lỗi.', 0, true);
        if (message.type === 'error') { solverWorker?.terminate(); solverWorker = null; solverReady = false; }
        toast(message.message || 'Solver gặp lỗi.', 'error');
      }
    };
    solverWorker.onerror = () => {
      solverPending = false;
      $('#solver-solve').disabled = false;
      setSolverStatus('Không tải được solver', 'Hãy kiểm tra kết nối Internet/CDN rồi thử lại.', 0, true);
      solverWorker?.terminate(); solverWorker = null; solverReady = false;
    };
  } catch (error) {
    solverPending = false;
    $('#solver-solve').disabled = false;
    setSolverStatus('Trình duyệt không hỗ trợ Web Worker', 'Hãy dùng trình duyệt hiện đại và mở website qua máy chủ HTTP.', 0, true);
  }
}

function requestCubeSolution() {
  const validation = validateFacelets(solverFacelets);
  if (!validation.valid) return toast(validation.error, 'error');
  if (solverPending) return;
  solverSolution = '';
  $('#solver-result').classList.add('hidden');
  solverPending = true;
  solverRequestId += 1;
  solverRequestedFacelets = solverFacelets;
  $('#solver-solve').disabled = true;
  setSolverStatus(solverReady ? 'Đang tìm lời giải...' : 'Đang khởi tạo solver...', solverReady ? 'Đang tìm chuỗi move và xác minh trạng thái đích.' : 'Lần đầu cần tải solver và tạo bảng tra cứu. Việc này diễn ra trong nền.', 35);
  ensureSolverWorker();
  if (solverReady) solverWorker.postMessage({ type: 'solve', facelets: solverRequestedFacelets, requestId: solverRequestId });
}

function updateSolverFacelets(next) {
  solverRequestId += 1;
  solverPending = false;
  solverFacelets = next;
  data.solverDraft = next;
  solverSolution = '';
  $('#solver-result').classList.add('hidden');
  persist();
  renderSolver();
  setSolverStatus('Trạng thái đã thay đổi', 'Hãy chạy Solver để tìm lời giải cho màu hiện tại.', 0);
}

function renderScrambleCenter() {
  const history = data.scrambleHistory || [];
  const filter = $('#scramble-history-filter')?.value || 'all';
  const rows = history.filter(item => filter === 'all' || item.puzzle === filter).slice().reverse();
  $('#scramble-history').innerHTML = rows.length ? rows.map(item => `<article class="scramble-history-row"><div><strong>${esc(item.puzzle)} · ${formatDate(item.createdAt)}</strong><p>${esc(item.scramble)}</p><small>${item.source === 'batch' ? 'Tạo theo lô' : 'Tạo mới'}${item.isWca ? ' · WCA' : ' · Luyện tập'}</small></div><div class="inline-actions"><button class="secondary-button small-button" data-copy-history="${esc(item.id)}">Copy</button><button class="text-button" data-use-history="${esc(item.id)}">Dùng</button></div></article>`).join('') : '<div class="empty-state compact"><strong>Chưa có scramble đã lưu</strong><p>Scramble bạn tạo sẽ xuất hiện ở đây.</p></div>';
  $('#scramble-history-count').textContent = String(history.length);
}

function createCenterScramble(size) {
  return generateCubePracticeScramble(Number(size));
}

function saveCenterScramble(scramble, puzzle, source = 'single') {
  const entry = { id: makeId('scramble'), puzzle, scramble, source, isWca: false, createdAt: new Date().toISOString() };
  data.scrambleHistory = [...(data.scrambleHistory || []), entry].slice(-200);
  return entry;
}

function generateCenterScrambles() {
  const puzzle = $('#scramble-puzzle').value;
  const amount = Math.max(1, Math.min(20, Number($('#scramble-amount').value) || 1));
  const generated = Array.from({ length: amount }, () => createCenterScramble(puzzle));
  generated.forEach(scramble => saveCenterScramble(scramble, `${puzzle}x${puzzle}`, amount > 1 ? 'batch' : 'single'));
  persist();
  $('#scramble-current').textContent = generated[0];
  $('#scramble-batch').innerHTML = generated.map((scramble, index) => `<div class="scramble-batch-item"><span>${index + 1}</span><code>${esc(scramble)}</code><button class="secondary-button small-button" data-copy-batch="${index}">Copy</button></div>`).join('');
  $('#scramble-batch').dataset.items = JSON.stringify(generated);
  renderScrambleCenter();
  toast(amount === 1 ? 'Đã tạo scramble luyện tập.' : `Đã tạo ${amount} scramble.`);
}

function renderAcademy() {
  const lessons = [
    { id: 'cross-plan', stage: 'CROSS', title: 'Lập kế hoạch Cross trong Inspection', level: 'Cơ bản → trung cấp', body: 'Quan sát vị trí 4 cạnh có màu trắng, xác định cạnh cần đưa về mặt D và lập chuỗi giải trước khi bắt đầu. Ưu tiên hoàn thành Cross ở mặt D, tránh phải lật cube sau khi bắt đầu.', drill: 'Tạo Cross bằng tối đa 8 move; sau mỗi lần giải, ghi lại số move và số lần xoay cả cube.' },
    { id: 'f2l-pairs', stage: 'F2L', title: 'Ghép corner–edge thành một pair', level: 'Cơ bản', body: 'Tìm một góc tầng đầu và cạnh tầng giữa có chung hai màu bên. Đưa chúng lên tầng U, ghép thành pair rồi đưa pair vào slot phù hợp. Trước khi xoay, xác định vị trí đích.', drill: 'Luyện từng slot riêng; tập trung vào ghép pair ổn định thay vì tăng TPS.' },
    { id: 'f2l-lookahead', stage: 'F2L', title: 'Lookahead và giảm pause', level: 'Trung cấp', body: 'Trong lúc tay thực hiện pair hiện tại, mắt bắt đầu tìm corner và edge của pair tiếp theo. Giảm tốc độ xoay một chút nếu cần để duy trì quan sát liên tục.', drill: 'Thực hiện 5 solve ở tốc độ chậm có kiểm soát. Ghi nhận thời điểm dừng giữa các pair và giảm dần số pause.' },
    { id: 'f2l-rotation', stage: 'F2L', title: 'Giảm rotation', level: 'Trung cấp', body: 'Quan sát slot từ nhiều góc trước khi quyết định xoay cube. Tập nhận diện trường hợp có thể xử lý bằng U, U\' hoặc move ở mặt trước/phải mà không đổi hướng cầm.', drill: 'Chọn 10 case F2L; thử tìm cách giải không rotation và so sánh số move.' },
    { id: 'oll-recognition', stage: 'OLL', title: 'Nhận diện OLL theo pattern', level: 'Trung cấp', body: 'Nhìn pattern của 9 sticker tầng U thay vì cố đọc từng sticker rời. Chia nhóm theo hình dạng như dot, line, L-shape và các pattern có sẵn cạnh/góc định hướng.', drill: 'Mở thư viện OLL, che công thức, gọi tên case trước khi xem đáp án.' },
    { id: 'pll-recognition', stage: 'PLL', title: 'Nhận diện PLL bằng block và headlights', level: 'Trung cấp', body: 'Tìm block màu đã hoàn chỉnh, headlights và vị trí các cạnh/góc. Xoay U để đưa case về góc nhìn quen thuộc trước khi thực hiện thuật toán.', drill: 'Luyện nhận diện PLL riêng, không cần giải toàn bộ cube ở mỗi lần ôn.' },
    { id: 'two-look', stage: '2-LOOK', title: '2-Look OLL và 2-Look PLL', level: 'Nền tảng', body: '2-Look OLL định hướng tầng cuối qua hai bước: định hướng cạnh rồi định hướng góc. 2-Look PLL hoán vị tầng cuối qua hai bước: hoán vị góc rồi hoán vị cạnh.', drill: 'Học nhóm công thức ít trước, luyện nhận diện chính xác rồi mới tăng tốc.' }
  ];
  const completed = new Set(data.academyProgress?.completed || []);
  $('#academy-completion').textContent = `${completed.size}/${lessons.length}`;
  $('#academy-lessons').innerHTML = lessons.map(lesson => `<article class="panel academy-lesson ${completed.has(lesson.id) ? 'is-complete' : ''}"><div class="academy-lesson-top"><span class="alg-type ${lesson.stage.toLowerCase().replace('-', '')}">${lesson.stage}</span><small>${lesson.level}</small></div><h3>${lesson.title}</h3><p>${lesson.body}</p><div class="academy-drill"><strong>Bài tập</strong><span>${lesson.drill}</span></div><button class="secondary-button small-button" data-academy-complete="${lesson.id}">${completed.has(lesson.id) ? '✓ Đã hoàn thành' : 'Đánh dấu hoàn thành'}</button></article>`).join('');
}

function renderStats() {
  const all = $('#stats-session-filter').value === 'all';
  const from = $('#stats-date-from')?.value ? new Date(`${$('#stats-date-from').value}T00:00:00`) : null;
  const to = $('#stats-date-to')?.value ? new Date(`${$('#stats-date-to').value}T23:59:59.999`) : null;
  const baseSolves = all ? data.solves : sessionSolves();
  const solves = baseSolves.filter(solve => { const date = new Date(solve.createdAt); return (!from || date >= from) && (!to || date <= to); }).slice().sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
  const finite = solves.map(effectiveTime).filter(Number.isFinite);
  const best = finite.length ? Math.min(...finite) : null;
  $('#stats-best').textContent = displayTime(best);
  $('#stats-best-ao5').textContent = displayTime(bestAverage(solves, 5));
  $('#stats-best-ao12').textContent = displayTime(bestAverage(solves, 12));
  $('#stats-ao50').textContent = displayTime(bestAverage(solves, 50));
  $('#stats-mean3').textContent = displayTime(solves.length >= 3 ? meanOf(solves.slice(-3)) : null);
  $('#stats-mean').textContent = displayTime(meanOf(solves));
  const dnf = solves.filter(solve => solve.penalty === 'DNF').length;
  const plus2 = solves.filter(solve => solve.penalty === '+2').length;
  $('#stats-count').textContent = String(solves.length);
  $('#stats-total-time').textContent = formatDuration(solves.reduce((sum, solve) => sum + (Number.isFinite(solve.rawMs) ? solve.rawMs : 0), 0));
  $('#stats-dnf').textContent = String(dnf);
  $('#stats-plus2').textContent = String(plus2);
  $('#stats-dnf-rate').textContent = solves.length ? `${Math.round(dnf / solves.length * 100)}%` : '0%';
  $('#stats-ao100').textContent = displayTime(averageOf(solves, 100));
  const recentTimes = solves.slice(-100).map(effectiveTime).filter(Number.isFinite);
  const average = recentTimes.length ? recentTimes.reduce((sum, value) => sum + value, 0) / recentTimes.length : null;
  const deviation = average === null ? null : Math.sqrt(recentTimes.reduce((sum, value) => sum + ((value - average) ** 2), 0) / recentTimes.length);
  $('#stats-stability').textContent = deviation === null ? '—' : `± ${(deviation / 1000).toFixed(2)}s`;
  $('#stats-week-solves').textContent = String(countRecentSolves(solves, 7));
  $('#stats-streak').textContent = `${activityStreak(solves)} ngày`;
  renderChart(solves);
  renderDailyChart(solves);
  renderDistributionChart(solves);
  renderSessionComparison();
  $('#stats-table').innerHTML = solves.length ? solves.slice().reverse().map(solve => {
    const session = data.sessions.find(item => item.id === solve.sessionId);
    return `<tr><td>${esc(session?.name || 'Session đã xóa')}</td><td><strong class="table-time">${displayTime(effectiveTime(solve))}</strong></td><td>${formatDate(solve.createdAt)}</td><td class="scramble-cell" title="${esc(solve.scramble)}">${esc(solve.scramble || '—')}</td></tr>`;
  }).join('') : '<tr><td colspan="4" class="table-empty">Chưa có dữ liệu.</td></tr>';
}

function formatDuration(ms) {
  const seconds = Math.floor(ms / 1000);
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  return hours ? `${hours}h ${minutes}m` : `${minutes}m`;
}

function renderChart(solves) {
  const chart = $('#solve-chart');
  const values = solves.slice(-24).map(effectiveTime).filter(Number.isFinite);
  if (!values.length) { chart.innerHTML = '<div class="chart-empty">Biểu đồ sẽ xuất hiện khi có ít nhất một lượt solve hợp lệ.</div>'; return; }
  const max = Math.max(...values) * 1.12 || 1;
  chart.innerHTML = `<div class="chart-bars">${values.map((value, index) => `<div class="chart-bar-wrap" title="${displayTime(value)}"><div class="chart-bar" style="height:${Math.max(5, value / max * 100)}%"></div><small>${index + 1}</small></div>`).join('')}</div><div class="chart-axis"><span>${displayTime(Math.max(...values))}</span><span>${displayTime(Math.min(...values))}</span></div>`;
}

function renderDailyChart(solves) {
  const chart = $('#stats-daily-chart');
  const groups = new Map();
  solves.forEach(solve => {
    const value = effectiveTime(solve); if (!Number.isFinite(value)) return;
    const date = new Date(solve.createdAt); if (Number.isNaN(date.getTime())) return;
    const key = `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
    const group = groups.get(key) || []; group.push(value); groups.set(key, group);
  });
  const values = [...groups.entries()].slice(-14);
  if (!values.length) { chart.innerHTML = '<div class="chart-empty">Cần có solve hợp lệ để hiển thị tiến bộ theo ngày.</div>'; return; }
  const max = Math.max(...values.map(([,times]) => times.reduce((a,b)=>a+b,0)/times.length)) || 1;
  chart.innerHTML = `<div class="chart-bars">${values.map(([date,times]) => { const avg=times.reduce((a,b)=>a+b,0)/times.length; return `<div class="chart-bar-wrap" title="${date}: ${displayTime(avg)} · ${times.length} solve"><div class="chart-bar" style="height:${Math.max(5,avg/max*100)}%"></div><small>${date.slice(5)}</small></div>`; }).join('')}</div><div class="chart-axis"><span>${displayTime(max)}</span><span>Trung bình/ngày</span></div>`;
}

function renderDistributionChart(solves) {
  const chart = $('#stats-distribution-chart');
  const values = solves.map(effectiveTime).filter(Number.isFinite);
  if (!values.length) { chart.innerHTML = '<div class="chart-empty">Chưa có solve hợp lệ để phân bố thời gian.</div>'; return; }
  const min = Math.min(...values), max = Math.max(...values);
  const bucketCount = Math.min(6, Math.max(3, Math.ceil(Math.sqrt(values.length))));
  const width = Math.max(1, (max - min + 1) / bucketCount);
  const buckets = Array.from({length:bucketCount},(_,i)=>({from:min+i*width,to:min+(i+1)*width,count:0}));
  values.forEach(value => { const index = Math.min(bucketCount-1, Math.floor((value-min)/width)); buckets[index].count += 1; });
  const top = Math.max(...buckets.map(bucket=>bucket.count),1);
  chart.innerHTML = `<div class="chart-bars">${buckets.map(bucket=>`<div class="chart-bar-wrap" title="${displayTime(bucket.from)}–${displayTime(bucket.to)}: ${bucket.count} solve"><div class="chart-bar" style="height:${Math.max(4,bucket.count/top*100)}%"></div><small>${bucket.count}</small></div>`).join('')}</div><div class="chart-axis"><span>${displayTime(min)}</span><span>${displayTime(max)}</span></div>`;
}

function renderSessionComparison() {
  const rows = data.sessions.map(session => { const solves=sessionSolves(session.id); const finite=solves.map(effectiveTime).filter(Number.isFinite); return {session,solves,best:finite.length?Math.min(...finite):null,mean:meanOf(solves),ao5:averageOf(solves,5)}; });
  $('#stats-session-comparison').innerHTML = rows.length ? rows.map(row=>`<tr><td>${esc(row.session.name)}</td><td>${row.solves.length}</td><td>${displayTime(row.best)}</td><td>${displayTime(row.mean)}</td><td>${displayTime(row.ao5)}</td></tr>`).join('') : '<tr><td colspan="5" class="table-empty">Chưa có session.</td></tr>';
}

function renderSessions() {
  $('#session-grid').innerHTML = data.sessions.map(session => {
    const solves = sessionSolves(session.id);
    const finite = solves.map(effectiveTime).filter(Number.isFinite);
    const best = finite.length ? Math.min(...finite) : null;
    return `<article class="session-card ${session.id === data.activeSessionId ? 'selected' : ''}"><div class="session-card-head"><span class="session-puzzle">${esc(session.puzzle)}</span><button class="icon-button tiny" data-session-menu="${esc(session.id)}">···</button></div><h3>${esc(session.name)}</h3><p>${solves.length} lượt solve · Tạo ${formatDate(session.createdAt)}</p><div class="session-card-stats"><div><small>BEST SINGLE</small><strong>${displayTime(best)}</strong></div><div><small>AVERAGE</small><strong>${displayTime(meanOf(solves))}</strong></div></div><div class="session-card-bottom">${session.id === data.activeSessionId ? '<span class="active-label"><i></i> Đang hoạt động</span>' : `<button class="text-button" data-activate-session="${esc(session.id)}">Chuyển sang session →</button>`}</div></article>`;
  }).join('');
}

function createSession() {
  const body = `<form class="modal-form"><label>Tên session <input name="name" placeholder="Ví dụ: 3x3 F2L, luyện sub-20..." required /></label><label>Loại Rubik<select name="puzzle"><option value="3x3">3×3 Cube (đang hỗ trợ)</option></select></label><div class="modal-actions"><button type="button" class="secondary-button" data-cancel-modal>Hủy</button><button class="primary-button" type="submit">Tạo session</button></div></form>`;
  openModal('Tạo session mới', body, form => {
    const name = String(form.get('name')).trim();
    if (!name) { toast('Hãy nhập tên session.', 'error'); return false; }
    const session = { id: makeId('session'), name, puzzle: form.get('puzzle'), createdAt: new Date().toISOString() };
    data.sessions.push(session); data.activeSessionId = session.id;
    persist(); updateSessionLabels(); renderSessions(); renderTimerPage(); renderHome(); toast('Đã tạo và chuyển sang session mới.');
  });
}

function sessionMenu(id) {
  const session = data.sessions.find(item => item.id === id);
  if (!session) return;
  const body = `<div class="session-menu-actions"><button class="secondary-button" id="rename-session">✎ Đổi tên session</button><button class="danger-button" id="delete-session">× Xóa session</button></div>`;
  openModal(session.name, body);
  $('#rename-session').addEventListener('click', () => {
    closeModal();
    const renameBody = `<form class="modal-form"><label>Tên mới <input name="name" value="${esc(session.name)}" required /></label><div class="modal-actions"><button type="button" class="secondary-button" data-cancel-modal>Hủy</button><button class="primary-button" type="submit">Lưu</button></div></form>`;
    openModal('Đổi tên session', renameBody, form => {
      const name = String(form.get('name')).trim(); if (!name) return false;
      session.name = name; persist(); renderSessions(); updateSessionLabels(); renderTimerPage(); renderHome(); toast('Đã đổi tên session.');
    });
  });
  $('#delete-session').addEventListener('click', () => {
    closeModal();
    if (data.sessions.length <= 1) return toast('Cần giữ lại ít nhất một session.', 'error');
    if (session.id === solveSessionId && !['idle', 'stopped'].includes(timerState)) return toast('Hãy dừng timer trước khi xóa session đang được sử dụng.', 'error');
    if (!confirm(`Xóa session “${session.name}” cùng toàn bộ lượt solve bên trong?`)) return;
    data.sessions = data.sessions.filter(item => item.id !== id);
    data.solves = data.solves.filter(solve => solve.sessionId !== id);
    if (data.activeSessionId === id) data.activeSessionId = data.sessions[0].id;
    persist(); renderSessions(); renderTimerPage(); renderHome(); renderStats(); toast('Đã xóa session và dữ liệu liên quan.');
  });
}

function exportSolvesCsv() {
  const all = $('#stats-session-filter').value === 'all';
  const solves = (all ? data.solves : sessionSolves()).slice().sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
  const headers = ['Session', 'Puzzle', 'Raw time ms', 'Penalty', 'Effective time ms', 'Scramble', 'Note', 'Date ISO'];
  const rows = solves.map(solve => {
    const session = data.sessions.find(item => item.id === solve.sessionId);
    return [session?.name || 'Session deleted', solve.puzzle || '3x3', solve.rawMs, solve.penalty, Number.isFinite(effectiveTime(solve)) ? effectiveTime(solve) : 'DNF', solve.scramble || '', solve.note || '', solve.createdAt];
  });
  const escapeCsv = value => `"${String(value ?? '').replace(/"/g, '""')}"`;
  const csv = [headers, ...rows].map(row => row.map(escapeCsv).join(',')).join('\r\n');
  const blob = new Blob(['\uFEFF', csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a'); link.href = url; link.download = `rubik-solves-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.append(link); link.click(); link.remove(); URL.revokeObjectURL(url);
  toast(`Đã xuất ${solves.length} lượt solve ra CSV.`);
}

function exportData() {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a'); link.href = url; link.download = `rubik-universe-backup-${new Date().toISOString().slice(0, 10)}.json`;
  document.body.append(link); link.click(); link.remove(); URL.revokeObjectURL(url);
  toast('Đã xuất bản sao lưu JSON.');
}

async function importData(file) {
  if (!file) return;
  try {
    const parsed = JSON.parse(await file.text());
    const restored = migrateData(parsed);
    if (!restored) throw new Error('invalid');
    if (!confirm(`Nhập bản sao lưu gồm ${restored.sessions.length} session, ${restored.solves.length} lượt solve và ${restored.algorithms.length} công thức cá nhân? Dữ liệu hiện tại sẽ được thay thế.`)) return;
    cancelAnimationFrame(timerFrame); window.clearTimeout(holdTimer); holdActive = false;
    setTimerState('idle', 'READY TO SOLVE', 'NHẤN SPACE HOẶC CHẠM ĐỂ BẮT ĐẦU'); $('#timer-time').textContent = displayTime(0);
    Object.keys(data).forEach(key => delete data[key]);
    Object.assign(data, restored);
    data.training = normalizeTraining(data.training);
    solverFacelets = validateFacelets(data.solverDraft || SOLVED_FACELETS).valid ? (data.solverDraft || SOLVED_FACELETS) : SOLVED_FACELETS;
    solverSolution = '';
    persist(); setTheme(data.settings.theme); syncSettings(); renderAll(); toast('Đã nhập bản sao lưu cũ.');
  } catch {
    toast('Không thể nhập file. Hãy chọn bản sao lưu Rubik Universe hợp lệ.', 'error');
  } finally { $('#import-data').value = ''; }
}

function syncSettings() {
  const reduceMotion = localStorage.getItem('rubik-reduce-motion') === 'true';
  document.documentElement.classList.toggle('reduce-motion', reduceMotion);
  if ($('#settings-motion')) { $('#settings-motion').classList.toggle('active', reduceMotion); $('#settings-motion').setAttribute('aria-checked', String(reduceMotion)); }
  $('#settings-inspection').classList.toggle('active', data.settings.inspection);
  $('#settings-inspection').setAttribute('aria-checked', String(data.settings.inspection));
  $('#settings-sound').classList.toggle('active', data.settings.sound);
  $('#settings-sound').setAttribute('aria-checked', String(data.settings.sound));
  $('#inspection-state').textContent = data.settings.inspection ? 'ON' : 'OFF';
  $('#inspection-toggle').classList.toggle('is-off', !data.settings.inspection);
  if ($('#timer-decimals')) $('#timer-decimals').value = String(data.settings.timerDecimals || 2);
}

function searchGlobal(query) {
  const results = searchIndex.filter(item => `${item.title} ${item.description}`.toLowerCase().includes(query.toLowerCase())).slice(0, 8);
  const algResults = data.algorithms.filter(alg => `${alg.name} ${alg.type} ${alg.moves}`.toLowerCase().includes(query.toLowerCase())).slice(0, 4).map(alg => ({ title: alg.name, description: `${alg.type} · Công thức cá nhân`, page: 'algorithms', caseId: `CUSTOM-${alg.id}` }));
  const caseResults = CFOP_CASES.filter(item => `${item.name} ${item.type} ${item.moves}`.toLowerCase().includes(query.toLowerCase())).slice(0, 6).map(item => ({ title: item.name, description: `${item.type} · Case CFOP chuẩn`, page: 'algorithms', caseId: item.id }));
  return [...results, ...caseResults, ...algResults].slice(0, 10);
}

function renderSearchResults(query) {
  const box = $('#search-results');
  if (!query.trim()) { box.classList.add('hidden'); return; }
  const results = searchGlobal(query.trim());
  box.innerHTML = results.length ? results.map((item, index) => `<button class="search-result" data-search-page="${item.page}" ${item.caseId ? `data-search-case="${esc(item.caseId)}"` : ''} ${item.knowledgeId ? `data-search-knowledge="${esc(item.knowledgeId)}"` : ''}><span>${esc(item.title)}</span><small>${esc(item.description)}</small><kbd>${index + 1}</kbd></button>`).join('') : '<div class="search-no-results">Không tìm thấy kết quả phù hợp.</div>';
  box.classList.remove('hidden');
}

searchIndex = [
  { title: 'Tổng quan', description: 'Dashboard và thành tích', page: 'home' },
  { title: 'Rubik Timer', description: 'Bấm giờ, inspection và penalty', page: 'timer' },
  { title: 'Scramble Center', description: 'Tạo scramble 2×2 đến 7×7 và xem lịch sử', page: 'scrambles' },
  { title: 'CFOP Academy', description: 'Lộ trình Cross, F2L lookahead, OLL và PLL', page: 'academy' },
  { title: 'Thư viện thuật toán', description: 'OLL, PLL, F2L và công thức cá nhân', page: 'algorithms' },
  { title: 'Algorithm Trainer', description: 'Luyện ghi nhớ công thức F2L, OLL, PLL', page: 'trainer' },
  { title: '3×3 Solver', description: 'Nhập 54 sticker, kiểm tra và tìm lời giải', page: 'solver' },
  { title: 'Training Center', description: 'Kế hoạch luyện tập và tiến độ hằng ngày', page: 'training' },
  { title: 'Rubik 3D Visualizer', description: 'Mô phỏng cube theo từng move, phát lại công thức', page: 'visualizer' },
  { title: 'Thống kê', description: 'Single, Ao5, Ao12 và biểu đồ', page: 'stats' },
  { title: 'Sessions', description: 'Quản lý buổi luyện tập', page: 'sessions' },
  { title: 'Ký hiệu Rubik', description: 'R, L, U, D, F, B và dấu prime', page: 'explore' },
  ...KNOWLEDGE_ARTICLES.map(item => ({ title: item.title, description: item.summary, page: 'explore', knowledgeId: item.id })),
  { title: 'CFOP', description: 'Cross, F2L, OLL, PLL', page: 'explore' },
  { title: 'Cài đặt', description: 'Giao diện, inspection và sao lưu', page: 'settings' }
];

function renderAll() {
  renderKnowledgeBase(); renderHome(); renderTimerPage(); renderScrambleCenter(); renderAcademy(); renderCaseLibrary(); renderAlgorithms(); renderTrainer(); renderSolver(); renderTraining(); renderVisualizer(); renderStats(); renderSessions(); syncSettings();
}


// V5.4 — curated knowledge base. Articles are local content, searchable and filterable.
const KNOWLEDGE_ARTICLES = [
  {id:'cube-basics',category:'basics',tag:'CƠ BẢN',title:'Rubik 3×3 gồm những bộ phận nào?',summary:'Phân biệt viên tâm, cạnh, góc và hiểu vì sao tâm xác định màu của mỗi mặt.',body:'<p>Rubik 3×3 có 6 viên tâm, 12 viên cạnh và 8 viên góc. Trên cube tiêu chuẩn, các viên tâm giữ vị trí tương đối với nhau; chúng xác định màu quy ước của từng mặt.</p><ul><li><b>Tâm:</b> một màu, nằm giữa mỗi mặt.</li><li><b>Cạnh:</b> hai màu, nằm giữa hai góc.</li><li><b>Góc:</b> ba màu, nằm tại giao điểm của ba mặt.</li></ul><p>Khi giải, ta đưa từng viên về đúng vị trí và đúng hướng, không chỉ tạo ra các mặt đơn sắc một cách ngẫu nhiên.</p>'},
  {id:'notation',category:'basics',tag:'KÝ HIỆU',title:'Ký hiệu xoay cơ bản (Singmaster)',summary:'R, L, U, D, F, B; dấu prime, số 2 và quy tắc nhìn theo mặt đang xoay.',body:'<p>Ký hiệu được hiểu khi nhìn thẳng vào mặt đang được xoay:</p><ul><li><b>R / L:</b> Right / Left — mặt phải / trái.</li><li><b>U / D:</b> Up / Down — mặt trên / dưới.</li><li><b>F / B:</b> Front / Back — mặt trước / sau.</li><li><b>′:</b> xoay 90° ngược chiều kim đồng hồ.</li><li><b>2:</b> xoay 180°; ví dụ U2.</li></ul><p>R′ là phép xoay ngược chiều so với R khi nhìn trực diện vào mặt R. Luôn giữ quy ước góc nhìn nhất quán.</p>'},
  {id:'wide-slice',category:'basics',tag:'KÝ HIỆU NÂNG CAO',title:'Wide moves, slice moves và rotation',summary:'Phân biệt Rw, M/E/S và x/y/z để đọc công thức nâng cao.',body:'<ul><li><b>Rw:</b> xoay đồng thời hai lớp bên phải.</li><li><b>M:</b> lớp giữa theo hướng L; <b>E:</b> lớp giữa theo hướng D; <b>S:</b> lớp giữa theo hướng F.</li><li><b>x/y/z:</b> xoay toàn bộ khối theo trục tương ứng với R/U/F.</li></ul><p>Quy ước dấu và hướng cần theo cùng hệ notation của thư viện công thức bạn đang dùng. Với cube NxN, ký hiệu lớp rộng có thể có thêm số chỉ độ sâu.</p>'},
  {id:'cfop',category:'methods',tag:'PHƯƠNG PHÁP',title:'CFOP: Cross → F2L → OLL → PLL',summary:'Tổng quan bốn giai đoạn và cách học theo thứ tự từ nền tảng đến nâng cao.',body:'<ol><li><b>Cross:</b> giải bốn cạnh màu đáy quanh tâm đáy.</li><li><b>F2L:</b> ghép từng cặp góc–cạnh và đưa vào slot.</li><li><b>OLL:</b> định hướng toàn bộ lớp cuối.</li><li><b>PLL:</b> hoán vị các viên lớp cuối để hoàn tất cube.</li></ol><p>Nên ưu tiên nghiệm ổn định, ít dừng và ít xoay cube trước khi cố tăng TPS. 2-Look OLL/PLL là lộ trình trung gian hữu ích trước khi học full OLL/PLL.</p>'},
  {id:'beginner',category:'methods',tag:'PHƯƠNG PHÁP',title:'Phương pháp Beginner từng tầng',summary:'Cách tiếp cận dễ học cho người mới, tập trung hoàn thành từng tầng.',body:'<p>Phương pháp Beginner thường chia thành: dấu cộng tầng đầu, hoàn thành góc tầng đầu, giải cạnh tầng giữa, tạo dấu cộng tầng cuối, định hướng góc và hoán vị các viên cuối.</p><p>Ưu điểm là dễ hiểu và ít công thức. Khi đã giải ổn định, có thể chuyển sang CFOP hoặc phương pháp khác để giảm số bước và cải thiện khả năng quan sát.</p>'},
  {id:'roux',category:'methods',tag:'PHƯƠNG PHÁP',title:'Roux là gì?',summary:'Xây hai block 1×2×3, giải bốn cạnh còn lại và hoàn thiện góc bằng CMLL.',body:'<p>Roux là phương pháp giải 3×3 theo hướng blockbuilding. Người giải tạo hai block 1×2×3 ở hai bên, giải bốn cạnh còn lại (LSE) và dùng CMLL để định hướng/hoán vị các góc.</p><p>Roux có ít phụ thuộc vào xoay toàn khối trong nhiều tình huống, nhưng đòi hỏi tư duy blockbuilding và làm quen với M-slice.</p>'},
  {id:'zz',category:'methods',tag:'PHƯƠNG PHÁP',title:'ZZ method: EO trước',summary:'Định hướng cạnh sớm để giảm regrip và khai thác các bước giải tiếp theo.',body:'<p>ZZ bắt đầu bằng bước EO (Edge Orientation), sau đó xây block và hoàn thiện cube. Mục tiêu là đưa các cạnh về hướng thuận lợi sớm để giảm nhu cầu xoay cổ tay và xoay toàn khối trong các bước sau.</p><p>ZZ có nhiều biến thể; lộ trình học cụ thể tùy phiên bản, vì vậy không nên trộn công thức từ các biến thể khác nhau mà không kiểm tra.</p>'},
  {id:'cross-planning',category:'speedcubing',tag:'LUYỆN TẬP',title:'Lập kế hoạch Cross trong inspection',summary:'Quan sát bốn cạnh đáy, xác định vị trí đích và mô phỏng chuỗi move trước khi bấm giờ.',body:'<p>Trong inspection, xác định màu đáy, tìm bốn cạnh Cross và quan sát vị trí hiện tại của chúng. Lập kế hoạch theo từng cặp hoặc theo chuỗi hoàn chỉnh nếu có thể.</p><ul><li>Ưu tiên ít move nhưng vẫn giữ hướng nhìn dễ theo dõi.</li><li>Quan sát cả cạnh cần di chuyển và các viên có thể bị ảnh hưởng.</li><li>Sau solve, xem lại Cross có bị thêm move hoặc regrip không.</li></ul><p>Đừng đánh đổi độ chính xác chỉ để ép số move thấp.</p>'},
  {id:'f2l',category:'speedcubing',tag:'CFOP',title:'F2L: ghép góc và cạnh',summary:'Nhận diện cặp corner–edge, ghép pair và đưa vào đúng slot.',body:'<p>F2L giải đồng thời một góc tầng đầu và cạnh tầng hai có chung màu mặt trước/bên, sau đó đưa cặp vào slot. Thay vì giải toàn bộ góc trước rồi mới giải cạnh, F2L giảm thao tác lặp lại.</p><ul><li>Nhận diện vị trí và hướng của góc, cạnh.</li><li>Tạo pair ở tầng trên hoặc tách cặp nếu đang ghép sai.</li><li>Đưa pair vào slot đúng mà hạn chế phá các slot đã giải.</li></ul><p>Hãy học intuitive F2L trước khi phụ thuộc vào việc ghi nhớ hàng loạt công thức.</p>'},
  {id:'lookahead',category:'speedcubing',tag:'KỸ THUẬT',title:'Lookahead: nhìn trước khi tay xoay',summary:'Dùng thời gian thực hiện pair hiện tại để tìm cặp tiếp theo.',body:'<p>Lookahead là khả năng quan sát và nhận diện bước kế tiếp trong khi đang thực hiện bước hiện tại. Mục tiêu không phải nhìn thật nhanh mà là giảm khoảng dừng giữa các bước.</p><ul><li>Luyện chậm với nhịp xoay đều.</li><li>Khi thực hiện một pair, chủ động tìm góc hoặc cạnh của pair tiếp theo.</li><li>Giảm tốc nếu tay xoay nhanh hơn khả năng nhận diện.</li></ul>'},
  {id:'rotations',category:'speedcubing',tag:'KỸ THUẬT',title:'Giảm rotation và regrip',summary:'Chọn góc nhìn và cách đưa pair vào slot để tránh xoay cube không cần thiết.',body:'<p>Rotation là xoay toàn bộ cube (x/y/z); regrip là đổi cách cầm. Một số rotation là cần thiết, nhưng xoay liên tục có thể làm mất định hướng và gây dừng.</p><p>Thử giải F2L từ nhiều góc, dùng back slot khi phù hợp và giữ cube ở hướng giúp quan sát cặp tiếp theo. Không nên cấm tuyệt đối rotation; hãy giảm những lần không đem lại lợi ích.</p>'},
  {id:'oll-pll',category:'speedcubing',tag:'TẦNG CUỐI',title:'Phân biệt OLL và PLL',summary:'OLL thay đổi hướng sticker lớp cuối; PLL thay đổi vị trí các viên đã đúng hướng.',body:'<p><b>OLL</b> (Orientation of the Last Layer) đưa toàn bộ sticker mặt trên về đúng hướng. <b>PLL</b> (Permutation of the Last Layer) hoán vị các viên ở lớp cuối sau khi chúng đã được định hướng.</p><p>2-Look OLL thường chia thành định hướng cạnh rồi định hướng góc. 2-Look PLL thường hoán vị góc trước rồi hoán vị cạnh. Đây là cách học theo hai bước, không phải một bộ case riêng thay thế full OLL/PLL.</p>'},
  {id:'tps',category:'speedcubing',tag:'HIỆU SUẤT',title:'TPS không phải tất cả',summary:'Hiểu turns per second và mối quan hệ giữa tốc độ, pauses, accuracy.',body:'<p>TPS là số lượt xoay mỗi giây trong một khoảng đo. TPS cao không tự động đồng nghĩa solve nhanh hơn: thời gian dừng, nhận diện sai, rotation và lockup đều ảnh hưởng tổng thời gian.</p><p>Hãy ưu tiên turning accuracy và nhịp ổn định. Nếu tăng tốc làm phát sinh nhiều pause hoặc lỗi, hãy giảm tốc và cải thiện lookahead.</p>'},
  {id:'inspection',category:'speedcubing',tag:'LUẬT & THÓI QUEN',title:'Inspection và quy tắc thi đấu',summary:'Khoảng quan sát trước solve và cách chuẩn bị cube có kiểm soát.',body:'<p>Trong thi đấu WCA, inspection tiêu chuẩn có giới hạn thời gian và các mốc phạt được quy định trong Regulations. Quy định có thể được cập nhật, vì vậy hãy đọc văn bản WCA hiện hành trước khi dự giải.</p><p>Trong luyện tập cá nhân, có thể dùng inspection 15 giây để xây thói quen quan sát, nhưng không nên xem timer của ứng dụng là nguồn pháp lý thay thế Regulations.</p>'},
  {id:'hardware',category:'hardware',tag:'CẤU TẠO',title:'Magnet system và Ball Core',summary:'Nam châm hỗ trợ căn chỉnh; Ball Core là thiết kế lõi kết nối các góc.',body:'<p>Nam châm trong speedcube thường tạo lực hút/căn chỉnh giữa các lớp hoặc giữa các viên. Ball Core là một dạng cấu trúc lõi có các điểm liên kết với cụm góc, tùy thiết kế từng mẫu cube.</p><p>Số lượng, vị trí và lực nam châm khác nhau theo sản phẩm; không thể suy ra cảm giác xoay chỉ từ tên công nghệ. Hãy tham khảo thông số nhà sản xuất cho từng mẫu cụ thể.</p>'},
  {id:'lubrication',category:'hardware',tag:'BẢO DƯỠNG',title:'Vệ sinh và bôi trơn cube',summary:'Giữ cube sạch, dùng lượng lube nhỏ và kiểm tra tương thích vật liệu.',body:'<p>Bụi và cặn có thể làm cảm giác xoay thay đổi. Khi vệ sinh, tháo lắp theo hướng dẫn của nhà sản xuất, lau khô các bề mặt và chỉ dùng chất bôi trơn phù hợp với nhựa của cube.</p><ul><li>Bắt đầu với lượng rất nhỏ.</li><li>Phân biệt lube thiên tốc độ và lube thiên kiểm soát theo thông tin nhà sản xuất.</li><li>Thử từng thay đổi một để biết tác động.</li></ul><p>Không dùng dung môi hoặc hóa chất không rõ tương thích vì có thể làm hỏng nhựa.</p>'},
  {id:'corner-cutting',category:'hardware',tag:'CƠ KHÍ',title:'Corner cutting, tension và compression',summary:'Các yếu tố cơ học ảnh hưởng độ ổn định và khả năng xoay lệch.',body:'<p>Corner cutting mô tả khả năng cube tiếp tục xoay khi hai lớp chưa thẳng hàng hoàn toàn. Tension/compression là cách gọi phổ biến cho điều chỉnh độ căng hoặc độ nén của cơ cấu tùy dòng cube.</p><p>Điều chỉnh quá lỏng có thể làm cube thiếu ổn định; quá chặt có thể tăng lực xoay. Cấu trúc mỗi mẫu khác nhau, nên hãy dùng hướng dẫn của nhà sản xuất thay vì áp một thông số chung.</p>'},
  {id:'puzzles',category:'puzzles',tag:'CÁC LOẠI CUBE',title:'2×2 đến 7×7 khác nhau thế nào?',summary:'So sánh nhóm cube NxN và những đặc điểm thường gặp khi giải.',body:'<p>2×2 chỉ có các viên góc nhìn thấy; 3×3 có góc, cạnh và tâm; cube 4×4 trở lên có nhiều lớp tâm và cạnh ghép, vì vậy xuất hiện các bước reduction và các trường hợp parity đặc trưng.</p><p>Với NxN lớn hơn, số mảnh và độ dài solve tăng. Cách giải cụ thể phụ thuộc kích thước và phương pháp, không nên áp dụng nguyên xi thuật toán 3×3 cho toàn bộ cube.</p>'},
  {id:'pyraminx',category:'puzzles',tag:'BIẾN THỂ',title:'Pyraminx',summary:'Puzzle hình tứ diện với các đỉnh và lớp xoay quanh trục.',body:'<p>Pyraminx là puzzle dạng tứ diện. Các tip ở đỉnh có thể xoay độc lập; phần thân có các lớp xoay quanh trục. Cách giải cơ bản thường bắt đầu bằng việc căn tip, giải một mặt hoặc một block rồi hoàn thiện các cạnh còn lại.</p>'},
  {id:'megaminx',category:'puzzles',tag:'BIẾN THỂ',title:'Megaminx',summary:'Puzzle 12 mặt dạng khối mười hai mặt, có nhiều cạnh và góc hơn 3×3.',body:'<p>Megaminx có 12 mặt ngũ giác, với cấu trúc góc và cạnh tương tự ý tưởng của 3×3 nhưng số lượng mảnh lớn hơn. Nhiều phương pháp giải tận dụng các bước tương tự CFOP theo từng mặt và tầng.</p>'},
  {id:'skewb-square1',category:'puzzles',tag:'BIẾN THỂ',title:'Skewb và Square-1',summary:'Hai puzzle có cơ chế xoay khác 3×3 và yêu cầu cách giải riêng.',body:'<p>Skewb xoay quanh các trục đi qua góc, tạo chuyển động khác với face-turning cube. Square-1 có thể thay đổi hình dạng khi xoay, vì vậy cần xử lý shape trước hoặc trong quá trình giải.</p><p>Thuật toán của hai puzzle này không thể dùng trực tiếp như công thức CFOP 3×3.</p>'},
  {id:'clock-mirror',category:'puzzles',tag:'BIẾN THỂ',title:'Clock và Mirror Cube',summary:'Clock dùng các mặt đồng hồ; Mirror Cube giải theo hình dạng thay vì màu.',body:'<p>Rubik’s Clock sử dụng các mặt đồng hồ và nút ghim để điều chỉnh kim. Mirror Cube có cơ chế gần với 3×3 nhưng các mảnh có kích thước khác nhau; khi giải, người chơi dựa vào hình dạng và độ cao thay vì màu sắc.</p>'}
];

function renderKnowledgeBase() {
  const grid = $('#knowledge-grid');
  if (!grid) return;
  const query = ($('#knowledge-search')?.value || '').trim().toLocaleLowerCase('vi');
  const category = $('#knowledge-category')?.value || 'all';
  const items = KNOWLEDGE_ARTICLES.filter(item => (category === 'all' || item.category === category) && `${item.title} ${item.summary} ${item.tag} ${item.body.replace(/<[^>]+>/g,' ')}`.toLocaleLowerCase('vi').includes(query));
  $('#knowledge-count').textContent = `Hiển thị ${items.length}/${KNOWLEDGE_ARTICLES.length} chủ đề`;
  grid.innerHTML = items.length ? items.map(item => `<button class="panel knowledge-card" data-knowledge-article="${esc(item.id)}"><span class="knowledge-tag">${esc(item.tag)}</span><strong>${esc(item.title)}</strong><p>${esc(item.summary)}</p><span class="knowledge-open">Đọc bài <b>↗</b></span></button>`).join('') : '<div class="panel empty-state full-span"><strong>Không tìm thấy chủ đề</strong><p>Thử từ khóa khác hoặc chọn Tất cả chủ đề.</p></div>';
}

function openKnowledgeArticle(id) {
  const item = KNOWLEDGE_ARTICLES.find(article => article.id === id);
  if (!item) return;
  openModal(item.title, `<div class="knowledge-article"><span class="knowledge-tag">${esc(item.tag)}</span><p class="knowledge-lead">${esc(item.summary)}</p>${item.body}</div><div class="modal-actions"><button class="primary-button" type="button" data-modal-close-article>Đã hiểu</button></div>`);
}

// Navigation and shared controls.
$$('[data-page]').forEach(button => button.addEventListener('click', () => navigate(button.dataset.page)));
document.addEventListener('click', event => {
  const knowledgeArticle = event.target.closest('[data-knowledge-article]'); if (knowledgeArticle) openKnowledgeArticle(knowledgeArticle.dataset.knowledgeArticle);
  if (event.target.closest('[data-modal-close-article]')) closeModal();
  const solverSticker = event.target.closest('[data-solver-sticker]');
  if (solverSticker) {
    const index = Number(solverSticker.dataset.solverSticker);
    const current = solverFacelets[index];
    const nextColor = FACE_ORDER[(FACE_ORDER.indexOf(current) + 1) % FACE_ORDER.length];
    updateSolverFacelets(solverFacelets.slice(0, index) + nextColor + solverFacelets.slice(index + 1));
  }
  const trainingTask = event.target.closest('[data-training-task]');
  if (trainingTask) {
    const today = getTodayCompletion();
    const taskId = trainingTask.dataset.trainingTask;
    const ids = new Set(today.taskIds);
    if (ids.has(taskId)) ids.delete(taskId); else ids.add(taskId);
    const next = { date: today.date, taskIds: [...ids] };
    data.training.completions = data.training.completions.filter(entry => entry.date !== today.date);
    data.training.completions.push(next);
    persist(); renderTraining();
  }
  const go = event.target.closest('[data-go]');
  if (go) navigate(go.dataset.go);
  if (event.target.closest('[data-cancel-modal]')) closeModal();
  if (event.target.closest('#empty-add-alg')) addAlgorithm();
  const academyDone = event.target.closest('[data-academy-complete]'); if (academyDone) { const id = academyDone.dataset.academyComplete; const set = new Set(data.academyProgress?.completed || []); set.has(id) ? set.delete(id) : set.add(id); data.academyProgress = { completed: [...set] }; persist(); renderAcademy(); }
  const historyCopy = event.target.closest('[data-copy-history]'); if (historyCopy) { const item = data.scrambleHistory.find(entry => entry.id === historyCopy.dataset.copyHistory); if (item) navigator.clipboard.writeText(item.scramble).then(() => toast('Đã sao chép scramble.')).catch(() => toast('Không thể sao chép.', 'error')); }
  const historyUse = event.target.closest('[data-use-history]'); if (historyUse) { const item = data.scrambleHistory.find(entry => entry.id === historyUse.dataset.useHistory); if (item && item.puzzle === '3x3') { currentScramble = item.scramble; navigate('timer'); $('#scramble-text').textContent = currentScramble; toast('Đã chuyển scramble sang Timer 3×3.'); } else if (item) { $('#scramble-current').textContent = item.scramble; navigate('scrambles'); toast('Đã nạp lại scramble. Timer hiện chỉ hỗ trợ 3×3.'); } }
  const batchCopy = event.target.closest('[data-copy-batch]'); if (batchCopy) { const items = JSON.parse($('#scramble-batch').dataset.items || '[]'); const item = items[Number(batchCopy.dataset.copyBatch)]; if (item) navigator.clipboard.writeText(item).then(() => toast('Đã sao chép.')).catch(() => toast('Không thể sao chép.', 'error')); }
  const searchPage = event.target.closest('[data-search-page]');
  if (searchPage) { $('#search-results').classList.add('hidden'); $('#global-search').value = ''; if (searchPage.dataset.searchCase) { navigate('algorithms'); trainCase(searchPage.dataset.searchCase); } else { navigate(searchPage.dataset.searchPage); if (searchPage.dataset.searchKnowledge) openKnowledgeArticle(searchPage.dataset.searchKnowledge); } }
  const edit = event.target.closest('[data-edit-solve]'); if (edit) editSolve(edit.dataset.editSolve);
  const remove = event.target.closest('[data-delete-solve]'); if (remove) deleteSolve(remove.dataset.deleteSolve);
  const editAlg = event.target.closest('[data-edit-alg]'); if (editAlg) addAlgorithm(data.algorithms.find(alg => alg.id === editAlg.dataset.editAlg));
  const deleteAlg = event.target.closest('[data-delete-alg]'); if (deleteAlg) {
    const id = deleteAlg.dataset.deleteAlg;
    if (confirm('Xóa công thức này khỏi thư viện?')) { data.algorithms = data.algorithms.filter(alg => alg.id !== id); persist(); renderAlgorithms(); renderTrainer(); toast('Đã xóa công thức.'); }
  }
  const favorite = event.target.closest('[data-favorite-alg]'); if (favorite) {
    const alg = data.algorithms.find(item => item.id === favorite.dataset.favoriteAlg); if (alg) { alg.favorite = !alg.favorite; persist(); renderAlgorithms(); }
  }
  const train = event.target.closest('[data-train-alg]'); if (train) trainCase(`CUSTOM-${train.dataset.trainAlg}`);
  const copyCase = event.target.closest('[data-copy-case]'); if (copyCase) {
    const item = CFOP_CASES.find(entry => entry.id === copyCase.dataset.copyCase);
    if (item) navigator.clipboard?.writeText(caseMoves(item)).then(() => toast(`Đã sao chép ${item.name}.`)).catch(() => toast('Không thể sao chép trong trình duyệt này.', 'error'));
  }
  const favoriteCase = event.target.closest('[data-case-favorite]'); if (favoriteCase) {
    const id = favoriteCase.dataset.caseFavorite; data.caseProgress[id] = { ...getCaseProgress(id), favorite: !getCaseProgress(id).favorite }; persist(); renderCaseLibrary();
  }
  const editCase = event.target.closest('[data-edit-case]'); if (editCase) editCaseAlgorithm(editCase.dataset.editCase);
  const trainBuiltInCase = event.target.closest('[data-train-case]'); if (trainBuiltInCase) trainCase(trainBuiltInCase.dataset.trainCase);
  const visualizeBuiltInCase = event.target.closest('[data-visualize-case]'); if (visualizeBuiltInCase) jumpVisualizerToAlgorithm(visualizeBuiltInCase.dataset.visualizeCase);
  const visualizeMove = event.target.closest('[data-viz-jump]'); if (visualizeMove) setVisualizerStep(visualizeMove.dataset.vizJump);
  const activate = event.target.closest('[data-activate-session]'); if (activate) {
    data.activeSessionId = activate.dataset.activateSession; persist(); updateSessionLabels(); renderSessions(); renderTimerPage(); renderHome(); toast('Đã chuyển session.');
  }
  const menu = event.target.closest('[data-session-menu]'); if (menu) sessionMenu(menu.dataset.sessionMenu);
});

$('#theme-toggle').addEventListener('click', () => setTheme(data.settings.theme === 'dark' ? 'light' : 'dark'));
$('#knowledge-search')?.addEventListener('input', renderKnowledgeBase);
$('#knowledge-category')?.addEventListener('change', renderKnowledgeBase);
$('#settings-motion')?.addEventListener('click', () => { const enabled = !document.documentElement.classList.contains('reduce-motion'); document.documentElement.classList.toggle('reduce-motion', enabled); localStorage.setItem('rubik-reduce-motion', String(enabled)); $('#settings-motion').classList.toggle('active', enabled); $('#settings-motion').setAttribute('aria-checked', String(enabled)); });
$('#mobile-menu').addEventListener('click', () => $('#sidebar').classList.toggle('open'));
$('#quick-session').addEventListener('click', () => navigate('sessions'));
$('#modal-close').addEventListener('click', closeModal);
$('#modal-backdrop').addEventListener('click', event => { if (event.target.id === 'modal-backdrop') closeModal(); });
$('#global-search').addEventListener('input', event => renderSearchResults(event.target.value));
$('#scramble-generate').addEventListener('click', generateCenterScrambles);
$('#scramble-copy-current').addEventListener('click', async () => { try { await navigator.clipboard.writeText($('#scramble-current').textContent); toast('Đã sao chép scramble.'); } catch { toast('Không thể sao chép.', 'error'); } });
$('#scramble-history-filter').addEventListener('change', renderScrambleCenter);
$('#scramble-clear-history').addEventListener('click', () => { if (!data.scrambleHistory?.length) return; if (!confirm('Xóa toàn bộ lịch sử scramble đã lưu?')) return; data.scrambleHistory = []; persist(); renderScrambleCenter(); toast('Đã xóa lịch sử scramble.'); });
$('#stats-session-filter').addEventListener('change', renderStats);
['stats-date-from','stats-date-to'].forEach(id => $(`#${id}`).addEventListener('change', renderStats));
$('#stats-clear-dates').addEventListener('click', () => { $('#stats-date-from').value = ''; $('#stats-date-to').value = ''; renderStats(); });
$('#global-search').addEventListener('keydown', event => { if (event.key === 'Escape') $('#search-results').classList.add('hidden'); if (event.key === 'Enter') $('.search-result')?.click(); });
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && !$('#modal-backdrop').classList.contains('hidden')) closeModal();
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); $('#global-search').focus(); }
});

// Timer controls.
$('#timer-display').addEventListener('click', timerTap);
$('#new-scramble').addEventListener('click', newScramble);
$('#copy-scramble').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText(currentScramble); toast('Đã sao chép scramble.'); }
  catch { toast('Trình duyệt không cho phép sao chép tự động.', 'error'); }
});
$('#inspection-toggle').addEventListener('click', () => {
  data.settings.inspection = !data.settings.inspection; persist(); syncSettings();
  toast(`Inspection ${data.settings.inspection ? 'đã bật' : 'đã tắt'}.`);
});
$('#manual-solve').addEventListener('click', addManualSolve);
$('#add-manual-bottom').addEventListener('click', addManualSolve);
$('#reset-timer').addEventListener('click', () => {
  if (timerState === 'running') return toast('Không thể đặt lại khi timer đang chạy.', 'error');
  cancelAnimationFrame(timerFrame); setTimerState('idle', 'READY TO SOLVE', 'NHẤN SPACE HOẶC CHẠM ĐỂ BẮT ĐẦU'); $('#timer-time').textContent = displayTime(0);
});
$('#timer-puzzle').addEventListener('change', () => { $('#timer-puzzle').value = activeSession().puzzle; toast('Loại cube được quản lý theo session hiện tại.', 'error'); });
document.addEventListener('keydown', handleSpaceDown);
document.addEventListener('keyup', handleSpaceUp);
document.addEventListener('visibilitychange', () => {
  if (!document.hidden && timerState === 'running') { cancelAnimationFrame(timerFrame); updateTimerDisplay(); }
});
document.addEventListener('keydown', event => {
  if (event.key.toLowerCase() === 'n' && activePage === 'timer' && !isTypingTarget(event.target)) { event.preventDefault(); newScramble(); }
  if (event.key === 'Escape' && !$('#modal-backdrop').classList.contains('hidden')) closeModal();
});

// Algorithms and spaced practice.
$('#add-algorithm').addEventListener('click', () => addAlgorithm());
$('#empty-add-alg').addEventListener('click', () => addAlgorithm());
$('#algorithm-search').addEventListener('input', renderAlgorithms);
$('#case-search').addEventListener('input', renderCaseLibrary);
$$('[data-library-mode]').forEach(button => button.addEventListener('click', () => {
  const showCases = button.dataset.libraryMode === 'cases';
  $$('[data-library-mode]').forEach(item => item.classList.toggle('active', item === button));
  $('#case-library').classList.toggle('hidden', !showCases);
  $('#custom-library').classList.toggle('hidden', showCases);
}));
$('#case-filters').addEventListener('click', event => {
  const button = event.target.closest('[data-case-filter]'); if (!button) return;
  activeCaseFilter = button.dataset.caseFilter;
  $$('.filter-tab', $('#case-filters')).forEach(item => item.classList.toggle('active', item === button));
  renderCaseLibrary();
});
$('#algorithm-filters').addEventListener('click', event => {
  const button = event.target.closest('[data-filter]'); if (!button) return;
  activeAlgorithmFilter = button.dataset.filter;
  $$('.filter-tab', $('#algorithm-filters')).forEach(item => item.classList.toggle('active', item === button));
  renderAlgorithms();
});
$('#trainer-type').addEventListener('change', () => { trainerIndex = 0; renderTrainer(); });
$('#trainer-due-only').addEventListener('change', () => { trainerIndex = 0; renderTrainer(); });
$('#reveal-formula').addEventListener('click', () => {
  const alg = trainerQueue[trainerIndex]; if (!alg) return;
  trainerRevealed = !trainerRevealed;
  $('#trainer-formula').classList.toggle('hidden', !trainerRevealed);
  $('#flashcard').classList.toggle('revealed', trainerRevealed);
  $('#reveal-formula').innerHTML = trainerRevealed ? 'Ẩn công thức <span>↑</span>' : 'Hiện công thức <span>↓</span>';
});
$$('[data-trainer-rating]').forEach(button => button.addEventListener('click', () => trainerNext(button.dataset.trainerRating)));
$('#trainer-shuffle').addEventListener('click', () => { trainerQueue.sort(() => Math.random() - 0.5); trainerIndex = 0; showTrainerCard(); });

// Interactive 3D cube visualizer.
$('#viz-preset').addEventListener('change', () => {
  const item = CFOP_CASES.find(entry => entry.id === $('#viz-preset').value);
  if (item) $('#viz-sequence').value = caseMoves(item);
});
$('#viz-load-sequence').addEventListener('click', () => {
  const sequence = $('#viz-sequence').value.trim();
  const item = CFOP_CASES.find(entry => entry.id === $('#viz-preset').value);
  const isSelectedPreset = item && sequence === caseMoves(item);
  loadVisualizerSequence(sequence, {
    reverseStart: Boolean(isSelectedPreset),
    label: isSelectedPreset ? `${item.name} · ${item.type}` : 'Thuật toán tùy chỉnh'
  });
});
$('#viz-random-scramble').addEventListener('click', () => {
  const scramble = generatePracticeScramble(20);
  $('#viz-preset').value = '';
  loadVisualizerSequence(scramble, { label: 'Scramble luyện tập 3×3' });
});
$('#viz-previous').addEventListener('click', () => setVisualizerStep(visualizer.step - 1));
$('#viz-next').addEventListener('click', () => setVisualizerStep(visualizer.step + 1));
$('#viz-play').addEventListener('click', toggleVisualizerPlayback);
$('#viz-reset').addEventListener('click', () => setVisualizerStep(0));
$('#viz-progress').addEventListener('input', event => setVisualizerStep(event.target.value));
$('#viz-speed').addEventListener('change', () => {
  if (visualizer.interval) { stopVisualizerPlayback(); toggleVisualizerPlayback(); }
});
const cubeStage = $('#cube-stage');
let dragState = null;
cubeStage.addEventListener('pointerdown', event => {
  if (event.button !== 0 || event.target.closest('button')) return;
  dragState = { x: event.clientX, y: event.clientY, rotationX: visualizer.rotationX, rotationY: visualizer.rotationY };
  cubeStage.setPointerCapture?.(event.pointerId);
});
cubeStage.addEventListener('pointermove', event => {
  if (!dragState) return;
  visualizer.rotationY = dragState.rotationY + (event.clientX - dragState.x) * 0.7;
  visualizer.rotationX = Math.max(-80, Math.min(80, dragState.rotationX - (event.clientY - dragState.y) * 0.65));
  $('#viz-cube').style.transform = `rotateX(${visualizer.rotationX}deg) rotateY(${visualizer.rotationY}deg)`;
});
['pointerup', 'pointercancel', 'lostpointercapture'].forEach(type => cubeStage.addEventListener(type, () => { dragState = null; }));

// V4 Solver and Training Center.
$('#solver-reset').addEventListener('click', () => updateSolverFacelets(SOLVED_FACELETS));
$('#solver-scramble').addEventListener('click', () => {
  const scramble = generatePracticeScramble(25);
  const state = applyCubeMoves(createSolvedCube(), scramble);
  updateSolverFacelets(cubeToFaceletString(state));
  setSolverStatus('Đã tạo trạng thái thử', `Áp dụng scramble luyện tập: ${scramble}`, 0);
});
$('#solver-solve').addEventListener('click', requestCubeSolution);
$('#solver-copy').addEventListener('click', async () => {
  if (!solverSolution) return;
  try { await navigator.clipboard.writeText(solverSolution); toast('Đã sao chép lời giải.'); }
  catch { toast('Trình duyệt không cho phép sao chép.', 'error'); }
});
$('#solver-visualize').addEventListener('click', () => {
  if (!solverSolution) return;
  try {
    const baseCube = createCubeFromFaceletString(solverFacelets);
    const resultCube = applyCubeMoves(baseCube, solverSolution);
    if (!isCubeSolved(resultCube)) throw new Error('Mô hình 3D không xác minh được chuỗi move này.');
    navigate('visualizer');
    loadVisualizerSequence(solverSolution, { label: 'Lời giải Solver · Kociemba', baseCube });
    $('#viz-state-help').textContent = 'Trạng thái bắt đầu lấy từ 54 sticker bạn nhập; đang phát lời giải đã xác minh.';
  } catch (error) { toast(error.message, 'error'); }
});
$('#training-save-goals').addEventListener('click', () => {
  const targetSeconds = Number($('#training-target-time').value);
  const dailyMinutes = Number($('#training-daily-minutes').value);
  const weeklySolves = Number($('#training-weekly-goal').value);
  if (!Number.isFinite(targetSeconds) || targetSeconds < 1 || targetSeconds > 600 || !Number.isInteger(dailyMinutes) || dailyMinutes < 5 || dailyMinutes > 300 || !Number.isInteger(weeklySolves) || weeklySolves < 1 || weeklySolves > 2000) {
    return toast('Kiểm tra mục tiêu: thời gian 1–600 giây, phút/ngày 5–300, solve/tuần 1–2000.', 'error');
  }
  data.training.targetSeconds = targetSeconds;
  data.training.dailyMinutes = dailyMinutes;
  data.training.weeklySolves = weeklySolves;
  persist(); renderTraining(); toast('Đã lưu mục tiêu luyện tập.');
});

// Stats, sessions, settings and backup.
$('#stats-session-filter').addEventListener('change', renderStats);
$('#export-solves-csv').addEventListener('click', exportSolvesCsv);
$('#create-session').addEventListener('click', createSession);
$('#settings-inspection').addEventListener('click', () => { data.settings.inspection = !data.settings.inspection; persist(); syncSettings(); });
$('#settings-sound').addEventListener('click', () => { data.settings.sound = !data.settings.sound; persist(); syncSettings(); });
$('#timer-decimals').value = String(data.settings.timerDecimals || 2);
$('#timer-decimals').addEventListener('change', () => { data.settings.timerDecimals = Number($('#timer-decimals').value) === 3 ? 3 : 2; persist(); renderTimerPage(); });
$('#theme-options').addEventListener('click', event => { const button = event.target.closest('[data-theme-choice]'); if (button) setTheme(button.dataset.themeChoice); });
$('#export-data').addEventListener('click', exportData);
$('#import-data').addEventListener('change', event => importData(event.target.files?.[0]));
$('#clear-data').addEventListener('click', () => {
  if (!confirm('Xóa toàn bộ session, lượt solve, công thức và cài đặt? Hãy xuất bản sao lưu trước nếu cần.')) return;
  const defaults = createDefaultData();
  Object.keys(data).forEach(key => delete data[key]); Object.assign(data, defaults);
  data.training = { ...DEFAULT_TRAINING }; solverFacelets = SOLVED_FACELETS; solverSolution = '';
  persist(); setTheme('dark'); renderAll(); navigate('home'); toast('Đã xóa toàn bộ dữ liệu.');
});

// Initial state.
document.documentElement.dataset.theme = data.settings.theme;
setTheme(data.settings.theme);
syncSettings();
renderAll();
setTimerState('idle', 'READY TO SOLVE', 'NHẤN SPACE HOẶC CHẠM ĐỂ BẮT ĐẦU');
$('#timer-time').textContent = displayTime(0);
$('#timer-decimals').value = String(data.settings.timerDecimals || 2);
$('#scramble-text').textContent = currentScramble;
