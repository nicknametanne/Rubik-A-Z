# Rubik Universe V5.5

Web app speedcubing cá nhân, viết bằng HTML, CSS và JavaScript modules thuần. Không cần framework, backend hay bước build.

## Chạy trên Windows

1. Giải nén thư mục `rubik-universe`.
2. Mở Terminal/CMD tại thư mục đó.
3. Chạy:

   ```bash
   py -m http.server 8080
   ```

4. Mở `http://localhost:8080` trong Chrome, Edge hoặc Firefox.

Không mở `index.html` trực tiếp bằng `file://` vì trình duyệt có thể chặn JavaScript module và Web Worker.

## Điểm mới trong V5.5

### 4. V5.4 — Knowledge Base

- Mở rộng trang Khám phá thành thư viện kiến thức có tìm kiếm và lọc danh mục.
- Có 22 bài viết ngắn về cấu tạo cube, notation, CFOP, Beginner, Roux, ZZ, Cross planning, F2L, Lookahead, rotation, OLL/PLL, TPS, inspection, cơ chế cube, vệ sinh/bôi trơn và các puzzle phổ biến.
- Mỗi bài mở trong hộp thoại đọc riêng; tìm kiếm toàn cục cũng có thể mở trực tiếp bài phù hợp.
- Nội dung phân biệt rõ kiến thức tổng quan với những tính năng chưa được hỗ trợ (ví dụ scramble WCA random-state).

### 5. V5.5 — UX, accessibility và PWA

- Bổ sung skip-link, focus-visible, hỗ trợ Escape đóng hộp thoại và mục phím tắt trong Cài đặt.
- Tùy chọn Reduce Motion, đồng thời tôn trọng thiết lập giảm chuyển động của hệ điều hành.
- Bổ sung manifest, icon và Service Worker để cache app shell, hỗ trợ mở lại website khi offline sau lần tải đầu.
- Toàn bộ đường dẫn asset dùng relative path để tương thích GitHub Pages project site.
- Không cần backend, framework hoặc bước build.

## Điểm mới trong V5

### 1. Scramble Center

- Sinh chuỗi xoay luyện tập cho cube 2×2 đến 7×7.
- Tạo 1, 5, 10 hoặc 20 scramble mỗi lần.
- Sao chép scramble, xem lịch sử tối đa 200 mục và lọc theo kích thước.
- Các chuỗi này là practice move sequences, **không phải WCA random-state scrambles**. Timer và Solver vẫn hỗ trợ 3×3.

### 2. CFOP Academy

- Bài học có hướng dẫn và bài tập cho Cross planning, F2L pairing, Lookahead, giảm rotation, OLL recognition, PLL recognition và 2-Look.
- Lưu trạng thái hoàn thành cục bộ.
- Liên kết nhanh sang thư viện 119 case CFOP và Algorithm Trainer.

### 3. Advanced Statistics

- Bổ sung Best Ao50 và Mean of 3.
- Lọc thống kê theo khoảng ngày và session.
- Biểu đồ trung bình theo ngày, phân bố thời gian và bảng so sánh session.
- Giữ Ao5, Ao12, Ao100, mean, độ lệch chuẩn, DNF, +2 và streak.

### Điểm mới trong V4 (được giữ lại)

### 1. 3×3 Solver

- Nhập màu của 54 sticker trên lưới 6 mặt; tâm mỗi mặt được khóa theo quy ước URFDLB.
- Kiểm tra số lượng mỗi màu, tâm, tổ hợp góc/cạnh, hướng xoay/lật và parity trước khi gửi trạng thái tới solver.
- Giải trạng thái cube bất kỳ hợp lệ bằng Kociemba two-phase, không chỉ đảo ngược scramble đã lưu.
- Solver chạy trong Web Worker để việc tạo bảng tra cứu không khóa giao diện.
- Xác minh lời giải bằng cách áp dụng lại lên trạng thái đầu vào trước khi hiển thị.
- Có thể sao chép chuỗi move hoặc mở lời giải trên Rubik 3D Visualizer.
- Nút “Tạo trạng thái thử” tạo trạng thái luyện tập từ chuỗi move ngẫu nhiên đơn giản; đây không phải random-state scramble chuẩn WCA.

**Kết nối Internet:** Solver tải `cube.js` và `solve.js` phiên bản `cubejs@1.3.2` từ jsDelivr trong lần khởi chạy đầu. Phần nhập màu, kiểm tra trạng thái, Timer và các tính năng còn lại vẫn chạy cục bộ. Nếu CDN không truy cập được, Solver sẽ báo lỗi và cho phép thử tải lại.

### 2. Training Center

- Checklist hằng ngày gồm Cross, F2L lookahead, OLL/PLL recognition và full solves; thời lượng từng bài tự chia theo số phút/ngày bạn đặt.
- Lưu từng nhiệm vụ hoàn thành theo ngày trong LocalStorage.
- Theo dõi solve trong 7 ngày gần nhất so với mục tiêu tuần, chuỗi ngày có solve và PB so với mục tiêu single.
- Cho phép đặt mục tiêu thời gian, số phút luyện mỗi ngày và số solve mỗi tuần.
- Có lối tắt tới Timer, Algorithm Trainer và Solver.

### 3. Advanced Stats

- Bổ sung Current Ao100.
- Độ lệch chuẩn của tối đa 100 lượt gần nhất để theo dõi độ dao động.
- Số solve trong 7 ngày gần nhất và chuỗi ngày hoạt động.
- Tất cả số liệu được tính từ solve đã lưu; không tự tạo dữ liệu mẫu.

## Các tính năng V3 được giữ lại

- Thư viện CFOP 119 case: 41 F2L, 57 OLL, 21 PLL.
- Rubik 3D Visualizer hỗ trợ face turns, wide turns, slice turns và cube rotations.
- Dashboard, Timer 3×3, inspection, +2, DNF, nhập solve thủ công.
- Sessions, lịch sử solve, thống kê single/Ao5/Ao12/mean và xuất CSV.
- Algorithm Trainer có lặp lại ngắt quãng; thư viện công thức cá nhân.
- Dark/Light mode, cài đặt Timer, xuất/nhập backup JSON.

## Dữ liệu và tương thích

- Giữ nguyên LocalStorage key `rubik-universe-v1` và cấu trúc dữ liệu lõi V2 để giữ session, solve, công thức và tiến độ CFOP cũ.
- V4 thêm `training` và `solverDraft`; V5 thêm `scrambleHistory` và `academyProgress`. Tất cả được lưu trong cùng bản sao lưu JSON. V5 tự migrate dữ liệu V1/V2/V4, giữ nguyên session, solve, thuật toán, tiến độ và cài đặt hiện có.
- Khi mở V4 trên cùng origin (ví dụ vẫn dùng `http://localhost:8080`), dữ liệu trình duyệt cũ được dùng tiếp.
- Khi đổi thiết bị hoặc cổng, hãy xuất backup JSON từ bản hiện tại rồi nhập vào bản mới.
- Không xóa dữ liệu trình duyệt trước khi sao lưu.

## Xuất bản lên GitHub Pages bằng ZIP

Dự án có sẵn workflow tại `.github/workflows/deploy-pages.yml`. Workflow tìm ZIP tên `Rubik-Universe-*.zip` ở thư mục gốc repository, giải nén, kiểm tra `index.html` rồi deploy lên GitHub Pages. Nếu không có ZIP, workflow dùng các file website đã commit trực tiếp.

**Thiết lập lần đầu (bắt buộc một lần):** GitHub không tự chạy workflow nằm bên trong ZIP; file workflow phải được commit riêng trong repository trước khi nó có thể chạy.

1. Tạo một repository GitHub mới, ví dụ `rubik-universe`.
2. Upload file `Rubik-Universe-v5.5.zip` vào thư mục gốc repository và commit.
3. Tạo file `.github/workflows/deploy-pages.yml` trong repository, sao chép nguyên nội dung từ file cùng đường dẫn trong gói ZIP rồi commit. Nếu GitHub không cho tạo thư mục trực tiếp, nhập cả đường dẫn vào ô tên file.
4. Vào **Settings → Pages → Build and deployment → Source**, chọn **GitHub Actions**.
5. Vào tab **Actions**, chờ workflow `Deploy Rubik Universe to GitHub Pages` chạy xong. Website sẽ có địa chỉ dạng `https://TEN-TAI-KHOAN.github.io/TEN-REPOSITORY/`.

Từ lần sau, chỉ cần upload ZIP phiên bản mới cùng tên dạng `Rubik-Universe-v5.6.zip` vào thư mục gốc rồi commit; workflow sẽ tự giải nén và xuất bản lại. ZIP phải chứa thư mục dự án với `index.html` bên trong. Không cần tự giải nén trên GitHub.

**Lưu ý:** GitHub Pages chỉ host frontend tĩnh. Dữ liệu solve vẫn lưu trong LocalStorage của trình duyệt và không tự đồng bộ giữa các thiết bị. Solver cần Internet để tải thư viện Kociemba từ CDN trong lần khởi chạy đầu. Service Worker cần mở website qua HTTPS (GitHub Pages đáp ứng điều kiện này) hoặc localhost.

## Kiểm thử

Yêu cầu Node.js 18+:

```bash
npm test
```

Test bao gồm Ao5/Ao12, penalty, Timer, lưu/đọc và migration V1/V4, notation, lịch ôn tập, 119 case CFOP, engine 3D, chuyển đổi 54 facelet, kiểm tra trạng thái Rubik, scramble luyện tập 2×2–7×7, Knowledge Base, PWA và GitHub Pages workflow.

## Cấu trúc

```text
rubik-universe/
├── index.html
├── styles.css
├── README.md
├── manifest.webmanifest
├── sw.js
├── .nojekyll
├── .github/workflows/deploy-pages.yml
├── icons/icon.svg
├── THIRD-PARTY-LICENSES.md
├── package.json
├── src/
│   ├── app.js
│   ├── core.js
│   ├── cfop-data.js
│   ├── cube.js
│   ├── solver.js
│   └── solver-worker.js
└── tests/
    └── core.test.mjs
```
