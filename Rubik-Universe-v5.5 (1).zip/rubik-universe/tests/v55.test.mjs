import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const read = path => readFile(resolve(root, path), 'utf8');
test('V5.4 knowledge base includes core cubing topics and search controls', async () => {
  const html = await read('index.html'); const app = await read('src/app.js');
  for (const id of ['knowledge-search','knowledge-category','knowledge-grid']) assert.match(html, new RegExp(id));
  for (const topic of ['cross-planning','lookahead','rotations','oll-pll','roux','zz','pyraminx','megaminx']) assert.ok(app.includes(`id:'${topic}'`), `missing article ${topic}`);
  assert.match(app, /function renderKnowledgeBase\(/); assert.match(app, /function openKnowledgeArticle\(/);
  const articleBlock = app.split('const KNOWLEDGE_ARTICLES = [')[1].split('\n];')[0];
  assert.equal([...articleBlock.matchAll(/\{id:'[^']+'/g)].length, 22);
});
test('V5.5 includes manifest, offline shell and reduced-motion support', async () => {
  const html = await read('index.html'); const sw = await read('sw.js'); const css = await read('styles.css');
  assert.match(html, /manifest\.webmanifest/); assert.match(html, /serviceWorker\.register/);
  assert.match(sw, /APP_SHELL/); assert.match(sw, /caches\.match\('\.\/index\.html'\)/);
  assert.match(css, /\.reduce-motion/); assert.match(css, /:focus-visible/);
});
test('GitHub Pages workflow extracts a Rubik Universe ZIP and checks index.html', async () => {
  const workflow = await read('.github/workflows/deploy-pages.yml');
  assert.match(workflow, /Rubik-Universe-\*\.zip/); assert.match(workflow, /unzip -q/);
  assert.match(workflow, /test -f _site\/index\.html/); assert.match(workflow, /actions\/deploy-pages@v4/);
});
test('website assets use relative paths for project subpaths on GitHub Pages', async () => {
  const html = await read('index.html'); const manifest = await read('manifest.webmanifest');
  assert.match(html, /\.\/styles\.css/); assert.match(html, /\.\/src\/app\.js/);
  assert.match(manifest, /"start_url": "\.\/"/); assert.match(manifest, /"scope": "\.\/"/);
});
