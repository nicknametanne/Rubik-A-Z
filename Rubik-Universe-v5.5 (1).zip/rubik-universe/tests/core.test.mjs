import test from 'node:test';
import assert from 'node:assert/strict';
import {
  averageOf, effectiveTime, formatTime, generatePracticeScramble, parseTime,
  inspectionPenalty, createDefaultData, loadData, saveData, STORAGE_KEY, generateCubePracticeScramble,
  migrateData, isValidNotation, scheduleReview
} from '../src/core.js';
import { CFOP_CASES, F2L_CASES, OLL_CASES, PLL_CASES } from '../src/cfop-data.js';
import { createSolvedCube, applyCubeMoves, invertCubeMoves, isCubeSolved, cubeFaceGrids, parseCubeMoves, createCubeFromFaceletString, cubeToFaceletString } from '../src/cube.js';
import { FACE_ORDER, SOLVED_FACELETS, validateFacelets } from '../src/solver.js';

test('Ao5 removes one fastest and one slowest result', () => {
  const solves = [10000, 11000, 12000, 13000, 20000].map((rawMs, i) => ({ rawMs, penalty: 'none', id: String(i) }));
  assert.equal(averageOf(solves, 5), 12000);
});

test('Ao5 handles a single DNF by removing it as the slowest result', () => {
  const solves = [10000, 11000, 12000, 13000, 0].map((rawMs, i) => ({ rawMs, penalty: i === 4 ? 'DNF' : 'none', id: String(i) }));
  assert.equal(averageOf(solves, 5), 12000);
});

test('Ao12 removes fastest and slowest among 12 results', () => {
  const times = [15000, 10000, 11000, 12000, 13000, 14000, 16000, 17000, 18000, 19000, 20000, 30000];
  const solves = times.map((rawMs, i) => ({ rawMs, penalty: 'none', id: String(i) }));
  assert.equal(averageOf(solves, 12), 15500);
});

test('Ao5 returns DNF when more than one DNF remains after trimming', () => {
  const solves = [10000, 11000, 0, 0, 13000].map((rawMs, i) => ({ rawMs, penalty: i === 2 || i === 3 ? 'DNF' : 'none', id: String(i) }));
  assert.equal(averageOf(solves, 5), Infinity);
});

test('penalty and time formatting are applied', () => {
  assert.equal(effectiveTime({ rawMs: 12300, penalty: '+2' }), 14300);
  assert.equal(formatTime(61520), '1:01.52');
  assert.equal(parseTime('1:02.50'), 62500);
  assert.equal(parseTime('12.34'), 12340);
  assert.equal(parseTime('1:75'), null);
});

test('inspection penalty boundaries match the configured WCA thresholds', () => {
  assert.equal(inspectionPenalty(14999), 'none');
  assert.equal(inspectionPenalty(15000), '+2');
  assert.equal(inspectionPenalty(16999), '+2');
  assert.equal(inspectionPenalty(17000), 'DNF');
});

test('practice scramble has valid face notation and no consecutive same face', () => {
  let state = 0;
  const random = () => { state = (state + 1) % 5; return state / 6; };
  const scramble = generatePracticeScramble(25, random);
  const moves = scramble.split(' ');
  assert.equal(moves.length, 25);
  assert.ok(moves.every(move => /^[RLUDFB]2?'?$/.test(move)));
  assert.ok(moves.every((move, i) => i === 0 || move[0] !== moves[i - 1][0]));
});

test('local data can be saved and loaded with a valid active session', () => {
  const storage = {
    value: null,
    getItem(key) { return key === STORAGE_KEY ? this.value : null; },
    setItem(key, value) { if (key === STORAGE_KEY) this.value = value; }
  };
  const data = createDefaultData();
  data.sessions.push({ id: 'session-2', name: 'PLL', puzzle: '3x3', createdAt: new Date().toISOString() });
  data.activeSessionId = 'session-2';
  assert.equal(saveData(data, storage), true);
  const loaded = loadData(storage);
  assert.equal(loaded.activeSessionId, 'session-2');
  assert.equal(loaded.sessions.length, 2);
  assert.equal(loaded.version, 3);
});

test('invalid persisted JSON safely falls back to a fresh V2 workspace', () => {
  const storage = { getItem(key) { return key === STORAGE_KEY ? '{not-json' : null; } };
  const loaded = loadData(storage);
  assert.equal(loaded.version, 3);
  assert.equal(loaded.sessions.length, 1);
  assert.equal(loaded.solves.length, 0);
  assert.deepEqual(loaded.caseProgress, {});
});

test('V1 backup migrates without losing sessions, solves or personal algorithms', () => {
  const legacy = {
    version: 1,
    activeSessionId: 's1',
    settings: { theme: 'light', inspection: false },
    sessions: [{ id: 's1', name: 'Old session', puzzle: '3x3', createdAt: '2026-01-01T00:00:00.000Z' }],
    solves: [{ id: 'solve-1', sessionId: 's1', rawMs: 12345, penalty: '+2', createdAt: '2026-01-02T00:00:00.000Z', scramble: 'R U', note: '' }],
    algorithms: [{ id: 'alg-1', name: 'Sune', type: 'OLL', moves: "R U R' U R U2 R'", favorite: true, mastered: true }]
  };
  const migrated = migrateData(legacy);
  assert.equal(migrated.version, 3);
  assert.equal(migrated.sessions[0].name, 'Old session');
  assert.equal(migrated.solves.length, 1);
  assert.equal(migrated.algorithms.length, 1);
  assert.equal(migrated.settings.timerDecimals, 2);
  assert.equal(migrated.algorithms[0].review.status, 'known');
});

test('notation validator supports face, wide, slice and rotation moves', () => {
  assert.equal(isValidNotation("R U R' U2 Fw r M E' S2 x y' z2"), true);
  assert.equal(isValidNotation('R Q U'), false);
  assert.equal(isValidNotation(''), false);
});

test('spaced repetition schedules again, hard, good and easy ratings', () => {
  const now = 1_800_000_000_000;
  const again = scheduleReview(null, 'again', now);
  const hard = scheduleReview(null, 'hard', now);
  const good = scheduleReview(null, 'good', now);
  const easy = scheduleReview(null, 'easy', now);
  assert.equal(again.dueAt, now + 10 * 60 * 1000);
  assert.equal(hard.dueAt, now + 86400000);
  assert.equal(good.dueAt, now + 86400000);
  assert.equal(easy.dueAt, now + 4 * 86400000);
  assert.equal(again.status, 'learning');
  assert.equal(easy.status, 'known');
});

test('CFOP library includes 41 F2L, 57 OLL and 21 PLL cases with valid algorithms', () => {
  assert.equal(F2L_CASES.length, 41);
  assert.equal(OLL_CASES.length, 57);
  assert.equal(PLL_CASES.length, 21);
  assert.equal(CFOP_CASES.length, 119);
  assert.equal(new Set(CFOP_CASES.map(item => item.id)).size, 119);
  assert.ok(CFOP_CASES.every(item => item.name && isValidNotation(item.moves)));
  assert.ok(F2L_CASES.every(item => item.family && item.whiteSticker));
});

test('3D cube engine maps all six solved faces to their expected uniform colors', () => {
  const grids = cubeFaceGrids(createSolvedCube());
  for (const face of ['U', 'R', 'F', 'D', 'L', 'B']) {
    assert.equal(new Set(grids[face]).size, 1);
    assert.equal(grids[face].length, 9);
  }
});

test('3D cube engine applies inverse pairs, half turns and four quarter turns for supported move families', () => {
  const solved = createSolvedCube();
  const moves = ['R', 'L', 'U', 'D', 'F', 'B', 'M', 'E', 'S', 'r', 'l', 'u', 'd', 'f', 'b', 'Rw', 'Lw', 'Uw', 'Dw', 'Fw', 'Bw', 'x', 'y', 'z'];
  for (const move of moves) {
    assert.equal(isCubeSolved(applyCubeMoves(solved, `${move} ${move}'`)), true, `${move} inverse`);
    assert.equal(isCubeSolved(applyCubeMoves(solved, `${move} ${move} ${move} ${move}`)), true, `${move} four turns`);
  }
  assert.equal(isCubeSolved(applyCubeMoves(solved, 'U2 U2')), true, 'U2 half turns');
});

test('3D cube engine supports every notation token used in the complete CFOP library', () => {
  for (const item of CFOP_CASES) {
    assert.deepEqual(parseCubeMoves(item.moves).length, item.moves.split(/\s+/).length, item.name);
    const state = applyCubeMoves(createSolvedCube(), item.moves);
    const restored = applyCubeMoves(state, invertCubeMoves(item.moves).join(' '));
    assert.equal(isCubeSolved(restored), true, item.name);
  }
});


test('V4 facelet validation accepts solved and legally scrambled states', () => {
  assert.equal(validateFacelets(SOLVED_FACELETS).valid, true);
  const scrambled = applyCubeMoves(createSolvedCube(), "R U R' U' F2 D L2 B'");
  const facelets = cubeToFaceletString(scrambled);
  assert.equal(facelets.length, 54);
  assert.equal(validateFacelets(facelets).valid, true);
  const rebuilt = createCubeFromFaceletString(facelets);
  assert.equal(isCubeSolved(applyCubeMoves(rebuilt, "B L2 D' F2 U R U' R'")), true);
});

test('V4 facelet validation rejects wrong counts, moved centers and impossible single-edge flips', () => {
  assert.equal(validateFacelets(SOLVED_FACELETS.slice(1)).valid, false);
  const wrongCenter = `${SOLVED_FACELETS.slice(0, 4)}R${SOLVED_FACELETS.slice(5)}`;
  assert.equal(validateFacelets(wrongCenter).valid, false);
  const edgeFlip = [...SOLVED_FACELETS];
  [edgeFlip[5], edgeFlip[10]] = [edgeFlip[10], edgeFlip[5]];
  assert.equal(validateFacelets(edgeFlip.join('')).valid, false);
  assert.equal(FACE_ORDER, 'URFDLB');
});

test('V4 facelet validation rejects a single twisted corner and mismatched permutation parity', () => {
  const twistedCorner = [...SOLVED_FACELETS];
  const corner = [8, 9, 20];
  [twistedCorner[corner[0]], twistedCorner[corner[1]], twistedCorner[corner[2]]] = [
    twistedCorner[corner[2]], twistedCorner[corner[0]], twistedCorner[corner[1]]
  ];
  assert.equal(validateFacelets(twistedCorner.join('')).valid, false);

  const oddEdgeSwap = [...SOLVED_FACELETS];
  const firstEdge = [5, 10];
  const secondEdge = [7, 19];
  [oddEdgeSwap[firstEdge[0]], oddEdgeSwap[secondEdge[0]]] = [oddEdgeSwap[secondEdge[0]], oddEdgeSwap[firstEdge[0]]];
  [oddEdgeSwap[firstEdge[1]], oddEdgeSwap[secondEdge[1]]] = [oddEdgeSwap[secondEdge[1]], oddEdgeSwap[firstEdge[1]]];
  assert.equal(validateFacelets(oddEdgeSwap.join('')).valid, false);
});


test('V4 backup migration keeps training goals and the 54-sticker solver draft', () => {
  const draft = SOLVED_FACELETS.slice(0, 9) + 'R'.repeat(9) + SOLVED_FACELETS.slice(18);
  const source = {
    version: 2, activeSessionId: 's-v4',
    sessions: [{ id: 's-v4', name: 'V4', puzzle: '3x3', createdAt: '2026-01-01T00:00:00.000Z' }],
    solves: [], algorithms: [],
    training: { targetSeconds: 14.5, dailyMinutes: 35, weeklySolves: 120, completions: [{ date: '2026-11-15', taskIds: ['cross'] }] },
    solverDraft: draft
  };
  const migrated = migrateData(source);
  assert.equal(migrated.training.targetSeconds, 14.5);
  assert.equal(migrated.training.completions[0].taskIds[0], 'cross');
  assert.equal(migrated.solverDraft, draft);
});


test('V4 data migrates to V5 without losing sessions, solves, training or solver draft', () => {
  const v4 = { ...createDefaultData(), version: 2, training: { targetSeconds: 20, dailyMinutes: 25, weeklySolves: 80, completions: [] }, solverDraft: 'U'.repeat(54), sessions: [{ id: 's1', name: 'CFOP', puzzle: '3x3', createdAt: new Date().toISOString() }], activeSessionId: 's1', solves: [{ id: 'x', sessionId: 's1', rawMs: 12000, penalty: 'none', createdAt: new Date().toISOString() }] };
  const migrated = migrateData(v4);
  assert.equal(migrated.version, 3);
  assert.equal(migrated.solves.length, 1);
  assert.equal(migrated.training.targetSeconds, 20);
  assert.equal(migrated.solverDraft, 'U'.repeat(54));
  assert.deepEqual(migrated.scrambleHistory, []);
  assert.deepEqual(migrated.academyProgress, { completed: [] });
});

test('NxN practice scramble generator emits valid face and wide-turn notation', () => {
  for (const size of [2, 3, 4, 5, 6, 7]) {
    const scramble = generateCubePracticeScramble(size);
    const moves = scramble.split(' ');
    assert.ok(moves.length >= 11);
    assert.ok(moves.every(move => /^(?:[2-6])?[RLUDFB]w?(?:2|')?$/.test(move)));
    assert.ok(moves.every((move, index) => index === 0 || move.replace(/^(?:[2-6])?/, '')[0] !== moves[index - 1].replace(/^(?:[2-6])?/, '')[0]));
  }
});


test('V5 backup round-trip preserves scramble history and Academy progress', () => {
  const data = createDefaultData();
  data.scrambleHistory = [{ id: 'scr-1', puzzle: '3x3', scramble: "R U R'", source: 'single', isWca: false, createdAt: new Date().toISOString() }];
  data.academyProgress = { completed: ['cross-plan', 'f2l-pairs'] };
  const storage = { value: null, getItem() { return this.value; }, setItem(key, value) { this.value = value; } };
  assert.equal(saveData(data, storage), true);
  const loaded = loadData(storage);
  assert.deepEqual(loaded.scrambleHistory, data.scrambleHistory);
  assert.deepEqual(loaded.academyProgress, data.academyProgress);
});
