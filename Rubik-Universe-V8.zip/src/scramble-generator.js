// WCA-format NxN scrambles powered by cubing.js.
// Random-state generation is used where required by the WCA regulations;
// big-cube events use the library's event-specific WCA-style move scrambles.
const CUBING_SCRAMBLE_URL = 'https://cdn.cubing.net/v0/js/cubing/scramble';
const WCA_NXN_EVENT_CODES = Object.freeze({
  2: '222',
  3: '333',
  4: '444',
  5: '555',
  6: '666',
  7: '777'
});


export function getWcaNxNEventCode(size) {
  return WCA_NXN_EVENT_CODES[Number(size)] || null;
}

export async function generateWcaNxNScrambles(size, count = 1, loadModule = () => import(CUBING_SCRAMBLE_URL)) {
  const eventCode = getWcaNxNEventCode(size);
  if (!eventCode) throw new RangeError('Chỉ hỗ trợ scramble WCA cho cube 2×2 đến 7×7.');
  const safeCount = Math.max(1, Math.min(20, Math.trunc(Number(count) || 1)));
  const cubing = await loadModule();
  if (typeof cubing?.randomScrambleForEvent !== 'function') {
    throw new Error('Thư viện scramble không cung cấp randomScrambleForEvent.');
  }
  const scrambles = [];
  for (let index = 0; index < safeCount; index += 1) {
    const algorithm = await cubing.randomScrambleForEvent(eventCode);
    const scramble = algorithm?.toString?.().trim();
    if (!scramble) throw new Error(`Không tạo được scramble WCA cho sự kiện ${eventCode}.`);
    scrambles.push(scramble);
  }
  return scrambles;
}
