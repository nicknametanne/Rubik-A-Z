// Event-specific practice scrambles ported from the user's reference HTML file.
// NxN cube (2x2–7x7) WCA generation remains in scramble-generator.js / solver-worker.js.

const randomInt = max => Math.floor(Math.random() * max);
const pick = values => values[randomInt(values.length)];

function nxn(size, length, faces = 'UDLRFB') {
  const moves = [];
  let previousAxis = -1;
  let previousPreviousAxis = -1;
  let previousFace = -1;
  while (moves.length < length) {
    const faceIndex = randomInt(faces.length);
    const axis = faces.length > 3 ? faceIndex >> 1 : faceIndex;
    if (faceIndex === previousFace || (axis === previousAxis && axis === previousPreviousAxis)) continue;
    const layer = 1 + randomInt(size >> 1);
    previousPreviousAxis = previousAxis;
    previousAxis = axis;
    previousFace = faceIndex;
    moves.push(`${layer > 2 ? layer : ''}${faces[faceIndex]}${layer > 1 ? 'w' : ''}${pick(['', "'", '2'])}`);
  }
  return moves.join(' ');
}

function small(faces, length, tips = false) {
  const moves = [];
  let previousFace = '';
  while (moves.length < length) {
    const face = pick(faces);
    if (face === previousFace) continue;
    previousFace = face;
    moves.push(face + pick(['', "'"]));
  }
  if (tips) {
    moves.push(...[...'lrub'].filter(() => randomInt(2)).map(tip => tip + pick(['', "'"])));
  }
  return moves.join(' ');
}

function megaminx() {
  return Array.from({ length: 7 }, () =>
    Array.from({ length: 10 }, (_, index) => `${index % 2 ? 'D' : 'R'}${randomInt(2) ? '++' : '--'}`)
      .concat(randomInt(2) ? 'U' : "U'")
      .join(' ')
  ).join('\n');
}

function squareOne() {
  const shift = (values, amount) => values.map((_, index) => values[(index + amount) % 12]);
  const normalize = value => value > 6 ? value - 12 : value;
  const moves = [];
  let top = [0, 1, 1, 2, 3, 3, 4, 5, 5, 6, 7, 7];
  let bottom = [9, 9, 8, 11, 11, 10, 13, 13, 12, 15, 15, 14];
  const isLegal = (upper, lower) => {
    const nextTop = shift(top, upper);
    const nextBottom = shift(bottom, lower);
    return nextTop[5] !== nextTop[6] && nextTop[11] !== nextTop[0] &&
      nextBottom[5] !== nextBottom[6] && nextBottom[11] !== nextBottom[0];
  };

  while (moves.length < 20) {
    const options = [];
    for (let upper = 0; upper < 12; upper += 1) {
      for (let lower = 0; lower < 12; lower += 1) {
        if ((upper || lower) && isLegal(upper, lower)) options.push([upper, lower]);
      }
    }
    const [upper, lower] = pick(options);
    const nextTop = shift(top, upper);
    const nextBottom = shift(bottom, lower);
    top = nextTop.slice(0, 6).concat(nextBottom.slice(0, 6));
    bottom = nextTop.slice(6).concat(nextBottom.slice(6));
    moves.push(`(${normalize(upper)},${normalize(lower)})/`);
  }
  return moves.join(' ');
}

function clock() {
  const wheels = ['UR', 'DR', 'DL', 'UL', 'U', 'R', 'D', 'L', 'ALL'];
  const turn = face => {
    const value = randomInt(12) - 5;
    return `${face}${Math.abs(value)}${value < 0 ? '-' : '+'}`;
  };
  return `${wheels.map(turn).join(' ')} y2 ${wheels.slice(4).map(turn).join(' ')} ${wheels.slice(0, 4).filter(() => randomInt(2)).join(' ')}`.trim();
}

export const SPECIAL_SCRAMBLE_PUZZLES = Object.freeze([
  { value: 'Pyraminx', label: 'Pyraminx', description: '10 nước xoay chính và các tip ngẫu nhiên.' },
  { value: 'Skewb', label: 'Skewb', description: 'Chuỗi xoay U, L, R, B.' },
  { value: 'Megaminx', label: 'Megaminx', description: 'Scramble 7 dòng kiểu Pochmann.' },
  { value: 'Square-1', label: 'Square-1', description: '20 cặp xoay/trượt theo kiểm tra trạng thái hợp lệ.' },
  { value: 'Clock', label: 'Clock', description: 'Ký hiệu bánh răng theo dạng Clock.' }
]);

export function isNxNPuzzle(value) {
  return /^[2-7]x[2-7]$/.test(String(value || '')) && String(value).charAt(0) === String(value).charAt(2);
}

export function getPuzzleLabel(value) {
  const puzzle = String(value || '');
  if (isNxNPuzzle(puzzle)) return puzzle.replace('x', '×');
  return SPECIAL_SCRAMBLE_PUZZLES.find(item => item.value === puzzle)?.label || puzzle;
}

export function generateSpecialScramble(puzzle) {
  switch (puzzle) {
    case 'Pyraminx': return small(['U', 'L', 'R', 'B'], 10, true);
    case 'Skewb': return small(['U', 'L', 'R', 'B'], 11);
    case 'Megaminx': return megaminx();
    case 'Square-1': return squareOne();
    case 'Clock': return clock();
    default: throw new RangeError(`Loại Rubik chưa được hỗ trợ: ${puzzle}`);
  }
}

export function generatePracticeNxNScramble(size) {
  const lengths = { 2: 12, 3: 25, 4: 40, 5: 60, 6: 80, 7: 100 };
  if (!lengths[size]) throw new RangeError('Chỉ hỗ trợ cube 2×2 đến 7×7.');
  if (size === 2) return nxn(2, lengths[size], 'URF');
  return nxn(size, lengths[size]);
}
