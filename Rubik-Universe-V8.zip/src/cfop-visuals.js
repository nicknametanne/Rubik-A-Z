import { createSolvedCube, applyCubeMoves, invertCubeMoves } from './cube.js';

const COLORS = Object.freeze({
  U: '#f5d90a',
  D: '#f4f4f4',
  F: '#1fa84f',
  B: '#2a62d9',
  R: '#f07a13',
  L: '#d62e2e'
});
const GRAY = '#8b9099';
const diagramCache = new Map();

function coordinateKey(position, normal) {
  return `${position.join(',')}|${normal.join(',')}`;
}

function createCaseState(moves) {
  const inverse = invertCubeMoves(moves).join(' ');
  return applyCubeMoves(createSolvedCube(), inverse);
}

function renderTopDiagram(state, isOll) {
  const stickers = new Map(state.map(sticker => [coordinateKey(sticker.position, sticker.normal), sticker.color]));
  const rect = (x, y, width, height, color) =>
    `<rect x="${x}" y="${y}" width="${width}" height="${height}" rx="2" fill="${color}" stroke="rgba(0,0,0,.3)" stroke-width=".45"/>`;
  const colorFor = (position, normal) => {
    const color = stickers.get(coordinateKey(position, normal));
    if (!color) return GRAY;
    return isOll ? (color === 'U' ? COLORS.U : GRAY) : (COLORS[color] || GRAY);
  };

  let shapes = '';
  for (let x = -1; x <= 1; x += 1) {
    const left = (x + 1) * 18 + 17;
    for (let z = -1; z <= 1; z += 1) {
      const top = (z + 1) * 18 + 17;
      shapes += rect(left, top, 17, 17, colorFor([x, 1, z], [0, 1, 0]));
    }
    shapes += rect(left, 73, 17, 8, colorFor([x, 1, 1], [0, 0, 1]));
    shapes += rect(left, 7, 17, 8, colorFor([x, 1, -1], [0, 0, -1]));
    shapes += rect(73, left, 8, 17, colorFor([1, 1, x], [1, 0, 0]));
    shapes += rect(7, left, 8, 17, colorFor([-1, 1, x], [-1, 0, 0]));
  }

  const label = isOll
    ? 'Hình nhận diện OLL nhìn từ trên xuống; vàng là sticker U hướng lên'
    : 'Hình nhận diện PLL nhìn từ trên xuống với màu các miếng';
  return `<svg viewBox="0 0 88 88" role="img" aria-label="${label}" focusable="false">${shapes}</svg>`;
}

function renderF2lIsometric(state) {
  const width = 52 / 3;
  const project = ([x, y, z]) => [
    ((x - z) * 0.866 * width).toFixed(1),
    (((x + z) * 0.5 - y) * width).toFixed(1)
  ];
  const polygons = [];

  for (const sticker of state) {
    const normal = sticker.normal;
    if (normal[0] + normal[1] + normal[2] < 1) continue;
    const freeAxes = [0, 1, 2].filter(axis => !normal[axis]);
    const center = sticker.position.map((value, axis) => value + normal[axis] * 0.5);
    const corners = [[1, 1], [1, -1], [-1, -1], [-1, 1]];
    const points = corners.map(([a, b]) => project(center.map((value, axis) =>
      value + (axis === freeAxes[0] ? a : axis === freeAxes[1] ? b : 0) * 0.45
    )).join(',')).join(' ');
    const fill = COLORS[sticker.color] || GRAY;
    polygons.push({ depth: center[0] + center[1] + center[2], markup: `<polygon points="${points}" fill="${fill}" stroke="rgba(0,0,0,.45)" stroke-width=".55"/>` });
  }

  polygons.sort((a, b) => a.depth - b.depth);
  return `<svg viewBox="-60 -60 120 120" role="img" aria-label="Hình nhận diện F2L phối cảnh nhìn từ trên, trước và phải" focusable="false">${polygons.map(item => item.markup).join('')}</svg>`;
}

export function renderCfopCaseDiagram(item, moves = item?.moves) {
  if (!item || !['F2L', 'OLL', 'PLL'].includes(item.type) || !String(moves || '').trim()) return '';
  const key = `${item.type}:${item.id}:${moves}`;
  if (diagramCache.has(key)) return diagramCache.get(key);

  try {
    const state = createCaseState(moves);
    const svg = item.type === 'F2L'
      ? renderF2lIsometric(state)
      : renderTopDiagram(state, item.type === 'OLL');
    const result = `<div class="case-diagram case-diagram-${item.type.toLowerCase()}">${svg}</div>`;
    diagramCache.set(key, result);
    if (diagramCache.size > 240) diagramCache.delete(diagramCache.keys().next().value);
    return result;
  } catch (error) {
    console.warn(`Không thể vẽ hình ${item.name || item.id}:`, error);
    return `<div class="case-diagram case-diagram-fallback" role="img" aria-label="Không thể tạo sơ đồ cho ${String(item.name || item.id).replace(/[<>&\"']/g, '')}"><span>Hình minh họa chưa khả dụng</span></div>`;
  }
}

export function clearCfopDiagramCache() {
  diagramCache.clear();
}
