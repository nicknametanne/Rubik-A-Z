# Rubik Universe V8

Nền tảng speedcubing cá nhân chạy bằng HTML, CSS và JavaScript ES Modules thuần. Không cần framework, backend hay bước build.

## Chạy trên Windows

1. Giải nén `Rubik-Universe-V8.zip`.
2. Mở Terminal/CMD trong thư mục `rubik-universe`.
3. Chạy:

   ```bash
   py -m http.server 8080
   ```

4. Mở `http://localhost:8080` trong Chrome hoặc Edge.

Không mở `index.html` trực tiếp bằng `file://`; module và Web Worker cần HTTP/HTTPS.

## V5.4 — Knowledge Base

- 29 bài viết biên soạn sẵn, hoạt động không cần backend.
- 6 nhóm: Rubik cơ bản, notation, phương pháp giải, speedcubing, các loại puzzle, cấu tạo và bảo dưỡng.
- Nội dung gồm cấu tạo 3×3, trạng thái Rubik, face/wide/slice/rotation notation, Beginner, CFOP, Cross, F2L, OLL, PLL, 2-Look, Roux, ZZ, Petrus, inspection, lookahead, fingertricks, TPS/turning accuracy, phân tích solve, 2×2, NxN, Pyraminx, Megaminx, Skewb, Square-1, Clock và cơ chế/bảo dưỡng cube.
- Tìm kiếm, lọc theo danh mục, trang đọc bài riêng và liên kết chủ đề liên quan.
- Tìm kiếm toàn cục có thể tìm cả nội dung bài viết.

## V5.5 — UX & Quality

- Tùy biến Dashboard: bật/tắt Lượt giải gần đây và Công cụ truy cập nhanh.
- Giao diện gọn và chế độ giảm chuyển động.
- Bảng phím tắt: `Ctrl/⌘ + K`, `Space`, `N`, `?`, `Esc`.
- Bổ sung nhãn truy cập, focus hiển thị, skip link, quản lý focus hộp thoại và tinh chỉnh giao diện màn hình nhỏ.
- Dữ liệu cài đặt mới được migrate tự động, giữ nguyên dữ liệu V5 cũ.
- PWA: có manifest, icon và Service Worker; sau lần tải đầu trên HTTPS, các tài nguyên cốt lõi được cache để mở lại khi mất mạng.
- Solver vẫn cần tải thư viện `cubejs@1.3.2` từ jsDelivr khi chạy lần đầu; do đó Solver có thể không hoạt động offline nếu thư viện chưa được tải/cache.

## Các module được giữ từ V5.1–V5.3

- **Scramble Center:** tạo scramble theo định dạng WCA cho 2×2–7×7, tạo theo lô, sao chép và lưu lịch sử tối đa 200 mục. Random-state được dùng ở các sự kiện được yêu cầu; big cubes dùng kiểu scramble theo lượt xoay. Đây là công cụ luyện tập, không thay thế chương trình scramble chính thức tại giải WCA.
- **CFOP Academy:** Cross planning, F2L pair, Lookahead, giảm rotation, OLL/PLL recognition và 2-Look.
- **Advanced Statistics:** Best Ao50, Mean of 3, Current Ao100, độ lệch chuẩn, bộ lọc ngày/session, biểu đồ và so sánh session.
- **CFOP Library:** 119 case (41 F2L, 57 OLL, 21 PLL), công thức cá nhân và Algorithm Trainer lặp lại ngắt quãng.
- **Timer, Sessions, Training Center, 3D Visualizer, 3×3 Solver, backup JSON và CSV** được giữ lại.

## Đưa V8 lên GitHub Pages

### Cập nhật repository đang có (ví dụ `Rubik-A-Z`)

1. Mở `.github/workflows/deploy-pages.yml` trong repository, chọn **Edit** và thay toàn bộ nội dung bằng workflow ở bản V8 (`.github/workflows/deploy-pages.yml` hoặc `deploy-pages.yml`), rồi commit. Workflow mới ưu tiên tìm `Rubik-Universe-V8*.zip` trước các gói V6–V7/V5.5 cũ.
2. Chọn **Add file → Upload files**, tải `Rubik-Universe-V8.zip` lên thư mục gốc repository và commit. Không giải nén ZIP vào thư mục con.
3. Vào **Actions** và chờ workflow `Publish Rubik Universe to GitHub Pages` hoàn tất với dấu tích xanh.
4. Mở website Pages cũ và nhấn `Ctrl + Shift + R`. Địa chỉ website không đổi chỉ vì cập nhật ZIP.

Nếu **Settings → Pages → Build and deployment → Source** đã là **GitHub Actions** từ bản trước thì không cần cấu hình lại. Nếu repository dùng nhánh khác `main`, đổi `branches: [main]` trong workflow.

### Đưa lên repository mới

1. Tạo repository và thêm file `.github/workflows/deploy-pages.yml` từ bản V8.
2. Tải `Rubik-Universe-V8.zip` lên thư mục gốc repository và commit.
3. Đặt **Settings → Pages → Source → GitHub Actions**, rồi kiểm tra tab **Actions**.

GitHub không tự giải nén ZIP khi bạn tải nó lên. Workflow trong bộ V8 làm việc đó, lấy các tài nguyên website và triển khai Pages.

## Dữ liệu cá nhân

GitHub Pages chỉ host các tệp website tĩnh. Solve, session, công thức cá nhân, tiến độ và cài đặt được lưu trong LocalStorage của trình duyệt. Chúng không tự đồng bộ giữa máy tính/điện thoại hoặc giữa các trình duyệt. Trước khi đổi thiết bị, hãy xuất backup JSON trong Cài đặt rồi nhập lại trên thiết bị mới.

## Chạy kiểm thử

Yêu cầu Node.js 18+:

```bash
npm test
```

Các test kiểm tra thống kê, penalty, migration và backup, notation, 119 case CFOP, engine 3D, trạng thái Solver, bàn phím Space, bộ tạo scramble WCA 2×2–7×7, Academy và Knowledge Base.

## Cấu trúc

```text
rubik-universe/
├── .github/workflows/deploy-pages.yml
├── index.html
├── styles.css
├── manifest.webmanifest
├── sw.js
├── icon.svg
├── icon-192.png
├── icon-512.png
├── README.md
├── THIRD-PARTY-LICENSES.md
├── package.json
├── src/
│   ├── app.js
│   ├── academy-data.js
│   ├── scramble-generator.js
│   ├── multi-scramble.js
│   ├── cfop-visuals.js
│   ├── core.js
│   ├── cfop-data.js
│   ├── cube.js
│   ├── solver.js
│   ├── solver-worker.js
│   └── knowledge-data.js
└── tests/
    ├── core.test.mjs
    ├── deployment.test.mjs
    ├── v8-features.test.mjs
    └── knowledge-data.test.mjs
```


## Lịch sử nền tảng

V8 kế thừa các nền tảng V5.4–V7 dưới đây; các chức năng trước đó tiếp tục được giữ trong bản tích hợp.

### V8 — CFOP Case Visuals & Multi-Puzzle Scrambles

- Phát triển trực tiếp trên nền V6–V7; giữ Timer, Sessions, 3D Visualizer, Solver, CFOP Library (119 case), Academy, Trainer, Statistics, backup và các tiến độ đã lưu.
- Bổ sung sơ đồ nhận diện riêng cho 41 F2L, 57 OLL và 21 PLL: F2L dạng phối cảnh; OLL và PLL dạng nhìn từ trên xuống. Hình được dựng từ chính thuật toán của từng case trong thư viện hiện tại.
- Sơ đồ case xuất hiện trong thư viện CFOP, Academy ôn case và Algorithm Trainer.
- Scramble Center, Timer, Session và lịch sử hỗ trợ thêm Pyraminx, Skewb, Megaminx, Square-1 và Clock; tổng cộng 11 loại puzzle. Lịch sử có thể chuyển scramble thuộc các loại này sang Timer.
- Bộ sinh scramble WCA cho 2×2–7×7 của V6–V7 được giữ nguyên. 5 puzzle bổ sung dùng bộ sinh chuỗi luyện tập theo định dạng sự kiện được chuyển từ file HTML tham khảo; đây không phải cam kết random-state chính thức của WCA.
- Service Worker dùng cache revision V8 để tránh giữ giao diện/JS cũ sau cập nhật.

### V6 — Scramble & Timer
- 3×3 random-state scramble generation through cubejs in a Web Worker; each generated state is checked by solving it back to solved.
- Timer supports 2×2 through 7×7 sessions. Scramble Center uses cubing.js event generators for 2×2 and 4×4–7×7; the generators follow the event scramble format, using random-state where required and move-based scrambles for big cubes.
- Space handling releases on keyup even if focus moved, and resets a held key when the tab is hidden or the browser window loses focus.
- New service-worker cache revision, network-first asset refresh, and update check to reduce stale JS/CSS after deployment.

### V7 — CFOP Academy
- Expanded course from 7 overview cards to 25 structured lessons across Cross, F2L, OLL, PLL and full-solve integration.
- Stage filtering, saved completion progress, random CFOP case practice, answer reveal, 3D visualization and spaced-review ratings.

### Known scope
- The Solver remains a 3×3 facelet solver. Timer sessions support 2×2–7×7 plus Pyraminx, Skewb, Megaminx, Square-1 and Clock.
- The 3×3 random-state worker uses cubejs from jsDelivr. Scramble Center uses cubing.js over HTTPS for other NxN WCA-format scrambles. Internet is needed the first time these CDN modules load; when unavailable, the app falls back to labelled practice sequences.
- Full browser end-to-end testing across all browsers/devices is not claimed; unit tests, JavaScript syntax checks and static deployment checks are included in this package.
