export const KNOWLEDGE_CATEGORIES = [
  { id: 'all', label: 'Tất cả chủ đề' },
  { id: 'basics', label: 'Rubik cơ bản' },
  { id: 'notation', label: 'Ký hiệu & move' },
  { id: 'methods', label: 'Phương pháp giải' },
  { id: 'speedcubing', label: 'Speedcubing' },
  { id: 'puzzles', label: 'Các loại Rubik' },
  { id: 'hardware', label: 'Cấu tạo & bảo dưỡng' }
];

// Articles are intentionally self-contained so the knowledge base works without a backend.
export const KNOWLEDGE_ARTICLES = [
  {
    id: 'cube-anatomy', category: 'basics', title: 'Cấu tạo Rubik 3×3', readMinutes: 4,
    excerpt: 'Phân biệt tâm, cạnh, góc và hiểu vì sao các mảnh có thể hoán đổi vị trí nhưng không thể thay đổi tùy ý.',
    sections: [
      { heading: 'Ba loại mảnh chính', paragraphs: ['Một Rubik 3×3 tiêu chuẩn có 6 mảnh tâm, 12 mảnh cạnh và 8 mảnh góc. Mỗi mảnh nhìn thấy nhiều sticker, nhưng số mảnh cơ học nhỏ hơn tổng số sticker.', 'Mảnh tâm có một màu, mảnh cạnh có hai màu, mảnh góc có ba màu. Tâm xác định màu của mỗi mặt trong cách giải thông thường.'] },
      { heading: 'Các mảnh di chuyển như thế nào?', paragraphs: ['Khi xoay một mặt, các mảnh nằm trên lớp đó di chuyển cùng nhau. Một cạnh vẫn là cạnh và một góc vẫn là góc; thao tác xoay hợp lệ không biến một cạnh thành góc.', 'Vì các mảnh chỉ di chuyển theo những chu trình nhất định, không phải mọi cách sắp sticker đều là trạng thái có thể đạt được bằng cách xoay Rubik.'] },
      { heading: 'Điều cần nhớ', bullets: ['Tâm: 1 màu, dùng để định hướng màu các mặt.', 'Cạnh: 2 màu, có thể ở đúng vị trí nhưng bị lật hướng.', 'Góc: 3 màu, có thể ở đúng vị trí nhưng bị xoắn hướng.', 'Không tháo rời và lắp lại tùy tiện nếu muốn giữ trạng thái hợp lệ.'] }
    ], related: ['cube-state', 'notation-basic']
  },
  {
    id: 'cube-state', category: 'basics', title: 'Trạng thái và lời giải Rubik', readMinutes: 3,
    excerpt: 'Trạng thái là cách sắp xếp và định hướng các mảnh tại một thời điểm; lời giải đưa trạng thái đó về trạng thái đã giải.',
    sections: [
      { heading: 'Trạng thái đã giải', paragraphs: ['Rubik ở trạng thái đã giải khi mỗi mặt có một màu đồng nhất theo quy ước màu của chiếc cube đó. Không nhất thiết mọi hãng đều dùng cùng một cách phối màu đối diện, vì vậy hãy quan sát chiếc cube thực tế.'] },
      { heading: 'Move và trạng thái', paragraphs: ['Một move là thao tác xoay lớp hoặc mặt theo ký hiệu. Một chuỗi move biến đổi trạng thái hiện tại thành trạng thái mới. Lời giải là chuỗi move đưa trạng thái ban đầu về trạng thái đã giải.', 'Áp dụng chuỗi move rồi áp dụng chuỗi nghịch đảo theo thứ tự ngược sẽ đưa cube về trạng thái trước đó. Đây là nguyên tắc hữu ích khi học thuật toán.'] },
      { heading: 'Scramble không đồng nghĩa với lời giải', paragraphs: ['Một chuỗi move ngẫu nhiên để luyện tập có thể tạo ra trạng thái hợp lệ, nhưng không tự động trở thành scramble random-state theo tiêu chuẩn thi đấu. Nên đọc rõ nhãn của công cụ trước khi dùng scramble cho mục đích đo thành tích.'] }
    ], related: ['cube-anatomy', 'notation-basic', 'inspection']
  },
  {
    id: 'notation-basic', category: 'notation', title: 'Ký hiệu xoay cơ bản R L U D F B', readMinutes: 4,
    excerpt: 'Đọc sáu ký hiệu mặt, dấu prime và số 2 theo góc nhìn của người đang nhìn trực diện vào mặt được xoay.',
    sections: [
      { heading: 'Sáu mặt cơ bản', paragraphs: ['R là Right (phải), L là Left (trái), U là Up (trên), D là Down (dưới), F là Front (trước) và B là Back (sau). Chữ cái viết hoa biểu thị xoay một mặt theo một phần tư vòng.'] },
      { heading: 'Dấu prime và số 2', bullets: ['R: xoay mặt phải 90° theo chiều kim đồng hồ khi nhìn thẳng vào mặt R.', "R': xoay mặt phải 90° ngược chiều kim đồng hồ khi nhìn thẳng vào mặt R.", 'R2: xoay mặt phải 180°; chiều xoay không tạo khác biệt cho nửa vòng.'], paragraphs: ['Quy tắc chiều kim đồng hồ luôn được xác định từ góc nhìn trực diện vào chính mặt đang xoay, không phải từ góc nhìn cố định phía trước cube.'] },
      { heading: 'Cách luyện đọc', paragraphs: ['Đọc từng token thành tiếng, xác định mặt tương ứng trên cube rồi mới xoay. Khi mới học, hãy tập chậm và chính xác trước khi tăng tốc.'] }
    ], related: ['notation-advanced', 'cube-state']
  },
  {
    id: 'notation-advanced', category: 'notation', title: 'Wide moves, slice moves và cube rotations', readMinutes: 5,
    excerpt: 'Phân biệt xoay nhiều lớp, xoay lát giữa và xoay toàn bộ cube trong thuật toán.',
    sections: [
      { heading: 'Wide moves', paragraphs: ["Ký hiệu như Rw hoặc r thường dùng để chỉ xoay hai lớp bên phải cùng nhau. Một số tài liệu dùng chữ thường, một số dùng chữ hoa kèm w; cần theo quy ước của tài liệu đang học.", 'Trên cube lớn, ký hiệu có số đứng trước như 3Rw có thể chỉ độ sâu nhiều lớp theo quy ước notation được chọn.'] },
      { heading: 'Slice moves', paragraphs: ['M, E và S là các lớp giữa: M song song với L/R, E song song với U/D và S song song với F/B. Chiều dương thường được quy ước tương ứng với L, D và F; hãy kiểm tra chú giải notation của công cụ nếu không chắc.'] },
      { heading: 'Cube rotations', paragraphs: ['x, y và z xoay toàn bộ cube quanh trục tương ứng với R, U và F. Rotation không làm thay đổi trạng thái tương đối của các mảnh, nhưng thay đổi hướng cầm cube và cách đọc mặt trước.', 'Rotation có thể hữu ích để tiếp cận một trường hợp, nhưng xoay quá nhiều trong F2L có thể làm mất định hướng và tăng thời gian.'] }
    ], related: ['notation-basic', 'f2l', 'fingertricks']
  },
  {
    id: 'beginner-method', category: 'methods', title: 'Phương pháp giải từng tầng (Beginner)', readMinutes: 5,
    excerpt: 'Lộ trình dễ tiếp cận để giải 3×3 từ tầng đầu, tầng giữa đến tầng cuối.',
    sections: [
      { heading: 'Trình tự phổ biến', bullets: ['Tạo dấu cộng ở tầng đầu và ghép các góc tầng đầu.', 'Giải các cạnh tầng giữa.', 'Tạo dấu cộng ở tầng cuối.', 'Định hướng các góc tầng cuối.', 'Đưa các góc và cạnh tầng cuối về đúng vị trí.'] },
      { heading: 'Ưu tiên hiểu thay vì học thuộc', paragraphs: ['Ở giai đoạn đầu, hãy quan sát mảnh cần đưa đi đâu, lớp nào cần xoay và vì sao chuỗi move không phá phần đã hoàn thành. Khi hiểu mục đích, việc ghi nhớ thuật toán sẽ dễ hơn.', 'Phương pháp từng tầng thường cần nhiều bước hơn CFOP tối ưu, nhưng rất phù hợp để hiểu cách các mảnh di chuyển.'] },
      { heading: 'Khi nào chuyển sang CFOP?', paragraphs: ['Khi bạn có thể giải ổn định mà không cần nhìn hướng dẫn ở từng bước, có thể học Cross ở mặt D và ghép F2L để giảm số bước chuyển giữa các tầng.'] }
    ], related: ['cfop-overview', 'cross', 'f2l']
  },
  {
    id: 'cfop-overview', category: 'methods', title: 'Tổng quan phương pháp CFOP', readMinutes: 5,
    excerpt: 'Cross, First Two Layers, Orientation of Last Layer và Permutation of Last Layer tạo thành bốn giai đoạn giải.',
    sections: [
      { heading: 'Bốn giai đoạn', bullets: ['Cross: tạo dấu cộng ở tầng D.', 'F2L: ghép bốn cặp góc–cạnh để hoàn thành hai tầng đầu.', 'OLL: định hướng toàn bộ sticker tầng U.', 'PLL: hoán vị các mảnh tầng U để hoàn thành cube.'] },
      { heading: 'Học CFOP theo tiến trình', paragraphs: ['Không cần học toàn bộ OLL và PLL ngay lập tức. Có thể bắt đầu với Cross, F2L trực giác, sau đó dùng 2-Look OLL và 2-Look PLL trước khi mở rộng bộ công thức.', 'Một solve nhanh không chỉ phụ thuộc số thuật toán đã thuộc. Khả năng lập kế hoạch, nhận diện, lookahead, độ chính xác và sự ổn định đều quan trọng.'] },
      { heading: 'Theo dõi tiến bộ', paragraphs: ['Ghi lại thời gian từng giai đoạn hoặc tự nhận xét điểm dừng sau solve. Chọn một vấn đề cụ thể để luyện trong mỗi buổi thay vì cố sửa mọi thứ cùng lúc.'] }
    ], related: ['cross', 'f2l', 'oll', 'pll', 'two-look']
  },
  {
    id: 'cross', category: 'methods', title: 'Cross: lập kế hoạch dấu cộng', readMinutes: 5,
    excerpt: 'Tìm bốn cạnh của dấu cộng, xác định màu bên và lập kế hoạch trước khi bắt đầu timer.',
    sections: [
      { heading: 'Mục tiêu của Cross', paragraphs: ['Cross hoàn thành bốn cạnh có màu của mặt D và ghép màu bên của từng cạnh với tâm tương ứng. Cross đúng không chỉ là dấu cộng cùng màu ở mặt D; các màu bên cũng phải khớp với tâm.'] },
      { heading: 'Lập kế hoạch khi inspection', bullets: ['Tìm vị trí ban đầu của cả bốn cạnh Cross.', 'Xác định cạnh nào có thể giải trước và cạnh nào đang chắn đường.', 'Theo dõi hướng của cạnh và màu bên sau từng thao tác dự kiến.', 'Ưu tiên chuỗi move ít phá những cạnh đã đặt đúng.', 'Tập hoàn thành Cross ở mặt D để sẵn sàng vào F2L.'] },
      { heading: 'Lỗi thường gặp', paragraphs: ['Chỉ nhìn mặt D mà quên kiểm tra màu bên; xoay cube nhiều lần khi đang thực hiện; hoặc bắt đầu xoay trước khi biết vị trí của cả bốn cạnh. Hãy tập nhìn đủ bốn cạnh trước khi bấm timer.'] }
    ], related: ['inspection', 'f2l', 'solve-review']
  },
  {
    id: 'f2l', category: 'methods', title: 'F2L: ghép corner–edge thành pair', readMinutes: 6,
    excerpt: 'Hiểu quan hệ giữa góc tầng đầu và cạnh tầng giữa để ghép thành cặp rồi đưa vào slot.',
    sections: [
      { heading: 'Một F2L pair gồm gì?', paragraphs: ['Mỗi pair gồm một góc tầng đầu và một cạnh tầng giữa có chung hai màu bên. Sau Cross, cần giải bốn pair để hoàn thành hai tầng đầu.', 'Mục tiêu là ghép góc và cạnh trước, sau đó đưa pair vào đúng slot. Không phải mọi trường hợp đều cần đưa cả hai mảnh lên tầng U theo cùng một cách.'] },
      { heading: 'Quy trình quan sát', bullets: ['Xác định góc và cạnh cùng thuộc một slot.', 'Quan sát hướng của hai mảnh và vị trí slot.', 'Chọn cách ghép phù hợp: ghép trực tiếp, tách pair hoặc xử lý mảnh đang bị mắc.', 'Đưa pair vào slot mà hạn chế phá Cross và các pair đã giải.'] },
      { heading: 'Luyện tập', paragraphs: ['Học các trường hợp trực giác trước, sau đó mở rộng các case khó. Tập từng slot và giữ cube ở hướng cầm ổn định; chỉ tăng TPS khi bạn nhìn và nhận diện kịp.'] }
    ], related: ['lookahead', 'cross', 'cfop-overview']
  },
  {
    id: 'oll', category: 'methods', title: 'OLL: định hướng tầng cuối', readMinutes: 4,
    excerpt: 'OLL đưa toàn bộ sticker của mặt U về cùng hướng, nhưng chưa nhất thiết các mảnh đã đúng vị trí.',
    sections: [
      { heading: 'OLL làm gì?', paragraphs: ['OLL là viết tắt của Orientation of the Last Layer. Sau Cross và F2L, thuật toán OLL định hướng các cạnh và góc tầng cuối để mặt U có một màu đồng nhất.', 'OLL đầy đủ thường được chia thành 57 trường hợp. Hình dáng sticker trên mặt U là một phần quan trọng khi nhận diện, nhưng các màu bên cũng có thể cung cấp tín hiệu.'] },
      { heading: 'Hai-Look OLL', paragraphs: ['2-Look OLL chia công việc thành hai lượt: định hướng các cạnh tầng cuối, sau đó định hướng các góc. Cách học này giảm số công thức cần thuộc ban đầu, đổi lại cần nhiều bước hơn OLL đầy đủ.'] },
      { heading: 'Mẹo nhận diện', bullets: ['Giữ cube theo một góc nhìn cố định.', 'Nhận diện pattern tổng quát trước khi tìm case cụ thể.', 'Luyện gọi tên case trước khi xem công thức.', 'Không nhầm OLL với PLL: OLL thay đổi hướng, PLL thay đổi vị trí.'] }
    ], related: ['two-look', 'pll', 'cfop-overview']
  },
  {
    id: 'pll', category: 'methods', title: 'PLL: hoán vị tầng cuối', readMinutes: 4,
    excerpt: 'PLL sắp các góc và cạnh tầng cuối về đúng vị trí sau khi mặt U đã được định hướng.',
    sections: [
      { heading: 'PLL làm gì?', paragraphs: ['PLL là viết tắt của Permutation of the Last Layer. Khi mặt U đã có một màu đồng nhất, PLL hoán vị các mảnh tầng cuối để màu các mặt bên khớp với tâm.', 'Bộ PLL đầy đủ phổ biến có 21 trường hợp. Một số trường hợp có thể được nhận diện qua block màu, headlights hoặc vị trí các cạnh.'] },
      { heading: 'Hai-Look PLL', paragraphs: ['2-Look PLL chia việc hoán vị thành hai giai đoạn: hoán vị góc, sau đó hoán vị cạnh (hoặc theo trình tự tương đương trong tài liệu học). Nhờ vậy người mới chỉ cần học số công thức ít hơn trước khi chuyển lên PLL đầy đủ.'] },
      { heading: 'Luyện nhận diện', paragraphs: ['Quan sát cả mặt trên và màu bên, rồi xoay U để đưa mẫu về góc nhìn quen thuộc. Tập nhận diện trước khi bắt đầu thuật toán để tránh phải dừng giữa chừng.'] }
    ], related: ['oll', 'two-look', 'cfop-overview']
  },
  {
    id: 'two-look', category: 'methods', title: '2-Look OLL và 2-Look PLL', readMinutes: 5,
    excerpt: 'Lộ trình học tầng cuối với ít công thức hơn trước khi chuyển lên OLL 57 và PLL 21.',
    sections: [
      { heading: '2-Look OLL', paragraphs: ['Lượt đầu định hướng bốn cạnh tầng U để tạo dấu cộng. Lượt sau định hướng các góc để toàn bộ mặt U có cùng màu.'] },
      { heading: '2-Look PLL', paragraphs: ['Một lượt đưa các góc về đúng vị trí; lượt còn lại đưa các cạnh về đúng vị trí. Sau mỗi lượt, kiểm tra màu bên và hướng cube trước khi dùng công thức tiếp theo.'] },
      { heading: 'Khi nào nâng cấp?', paragraphs: ['Khi nhận diện và thực hiện 2-Look ổn định, bạn có thể học dần OLL/PLL đầy đủ. Không cần học dồn; ưu tiên những case dễ nhầm hoặc xuất hiện thường xuyên trong quá trình luyện của mình.'] }
    ], related: ['oll', 'pll', 'cfop-overview']
  },
  {
    id: 'roux-method', category: 'methods', title: 'Phương pháp Roux', readMinutes: 4,
    excerpt: 'Một phương pháp giải 3×3 xây dựng block hai bên, giải các góc CMLL rồi hoàn tất các cạnh giữa.',
    sections: [
      { heading: 'Các giai đoạn chính', bullets: ['Tạo block 1×2×3 ở bên trái.', 'Tạo block 1×2×3 ở bên phải.', 'Giải các góc tầng cuối bằng CMLL.', 'Giải các cạnh còn lại ở M-slice (LSE).'] },
      { heading: 'Đặc điểm', paragraphs: ['Roux sử dụng nhiều thao tác M-slice và có thể hạn chế rotations. Cách xây dựng block đòi hỏi quan sát quan hệ giữa nhiều mảnh, vì vậy cần luyện trực giác và khả năng lập kế hoạch.', 'Không có phương pháp nào nhanh nhất với mọi người. Hãy chọn theo cách tư duy, sở thích và khả năng luyện tập của bạn.'] }
    ], related: ['cfop-overview', 'notation-advanced', 'lookahead']
  },
  {
    id: 'zz-method', category: 'methods', title: 'Phương pháp ZZ', readMinutes: 4,
    excerpt: 'Định hướng cạnh trước (EOLine), sau đó giải các block với hướng cube ít thay đổi hơn.',
    sections: [
      { heading: 'Ý tưởng chính', paragraphs: ['ZZ bắt đầu bằng bước EOLine: định hướng các cạnh và đặt hai cạnh E-line theo cách của phương pháp. Sau đó người giải hoàn thiện các block hai tầng đầu và giải tầng cuối.', 'Khi các cạnh đã được định hướng, người giải có thể tránh một số thao tác xoay cube và slice move trong các giai đoạn sau.'] },
      { heading: 'Điểm cần luyện', bullets: ['Nhận diện hướng của cạnh ngay từ inspection.', 'Lập kế hoạch EOLine chính xác.', 'Xây dựng block với ít regrip.', 'Luyện tầng cuối phù hợp với biến thể ZZ đang học.'] }
    ], related: ['roux-method', 'cfop-overview', 'inspection']
  },
  {
    id: 'petrus-method', category: 'methods', title: 'Phương pháp Petrus', readMinutes: 4,
    excerpt: 'Xây dựng block nhỏ, mở rộng thành block 2×2×3, định hướng cạnh rồi hoàn thành các phần còn lại.',
    sections: [
      { heading: 'Các bước khái quát', bullets: ['Tạo một block 2×2×2.', 'Mở rộng thành block 2×2×3.', 'Định hướng các cạnh chưa định hướng.', 'Hoàn thành hai tầng đầu còn lại.', 'Giải tầng cuối.'] },
      { heading: 'Điểm đặc trưng', paragraphs: ['Petrus là phương pháp block-building. Nó giúp người học suy nghĩ về cấu trúc khối và hướng cạnh thay vì chỉ giải từng tầng độc lập. Có nhiều biến thể và cách tổ chức tầng cuối khác nhau.'] }
    ], related: ['roux-method', 'zz-method', 'cfop-overview']
  },
  {
    id: 'inspection', category: 'speedcubing', title: 'Inspection: quan sát trước solve', readMinutes: 4,
    excerpt: 'Sử dụng thời gian quan sát để lên kế hoạch Cross và chuẩn bị bước đầu của F2L.',
    sections: [
      { heading: 'Mục tiêu', paragraphs: ['Inspection là khoảng thời gian quan sát scramble trước khi bắt đầu solve. Trong luyện tập, hãy dùng inspection để xác định vị trí mảnh và lập kế hoạch; không nên chỉ nhìn cube rồi bắt đầu xoay theo phản xạ.'] },
      { heading: 'Bài tập Cross', bullets: ['Tìm bốn cạnh Cross.', 'Theo dõi màu bên và vị trí mục tiêu.', 'Lập chuỗi move dự kiến.', 'Thử dự đoán vị trí của một góc/cạnh F2L sau Cross.'] },
      { heading: 'Tránh quá tải', paragraphs: ['Khi mới tập, lập kế hoạch Cross rõ ràng đã là mục tiêu tốt. Khi tiến bộ, bạn có thể mở rộng dự đoán sang một phần F2L đầu tiên. Chất lượng kế hoạch quan trọng hơn việc cố nhớ quá nhiều thông tin.'] }
    ], related: ['cross', 'lookahead', 'solve-review']
  },
  {
    id: 'lookahead', category: 'speedcubing', title: 'Lookahead: quan sát trước bước tiếp theo', readMinutes: 5,
    excerpt: 'Dùng mắt tìm pair tiếp theo trong khi tay đang hoàn thành pair hiện tại để giảm khoảng dừng.',
    sections: [
      { heading: 'Lookahead là gì?', paragraphs: ['Lookahead là khả năng nhận biết thông tin cần cho thao tác tiếp theo trong khi vẫn đang thực hiện thao tác hiện tại. Trong F2L, mắt tìm corner và edge kế tiếp trong lúc tay hoàn thành pair hiện tại.', 'Lookahead không có nghĩa là nhìn thật nhanh. Nhiều người tiến bộ hơn khi giảm tốc độ xoay đủ để mắt theo kịp.'] },
      { heading: 'Bài tập chậm có kiểm soát', bullets: ['Giải F2L ở tốc độ thấp, hạn chế dừng hoàn toàn.', 'Khi tay xử lý pair hiện tại, tìm hai mảnh của pair tiếp theo.', 'Giữ ánh mắt ở vùng cần quan sát thay vì nhìn tay.', 'Tăng tốc từ từ khi vẫn duy trì được khả năng nhận diện.'] },
      { heading: 'Đánh giá', paragraphs: ['Sau mỗi solve, ghi nhận số khoảng dừng lớn và nguyên nhân: không tìm thấy mảnh, nhận diện sai, hay chưa quyết định được cách ghép.'] }
    ], related: ['f2l', 'solve-review', 'turning-accuracy']
  },
  {
    id: 'fingertricks', category: 'speedcubing', title: 'Fingertricks và cách cầm cube', readMinutes: 4,
    excerpt: 'Dùng ngón tay phù hợp cho từng move để giảm regrip và giữ nhịp xoay ổn định.',
    sections: [
      { heading: 'Nguyên tắc', paragraphs: ['Fingertricks là cách dùng ngón tay để thực hiện move hiệu quả. Mục tiêu không phải xoay mạnh nhất mà là hoàn thành move chính xác, ít đổi cách cầm và không làm mất kiểm soát cube.'] },
      { heading: 'Luyện cơ bản', bullets: ['Giữ cube thoải mái, không bóp quá chặt.', 'Tập các move U, U’, R và R’ riêng lẻ.', 'Dùng ngón trỏ hoặc ngón áp út phù hợp với hướng move.', 'Tập chuỗi ngắn ở tốc độ chậm để tránh lockup.', 'Chỉ tăng tốc khi các move vẫn chính xác.'] },
      { heading: 'Lưu ý', paragraphs: ['Cách fingertrick tối ưu có thể khác nhau tùy bàn tay, cube và thuật toán. Không nên ép một cách cầm gây đau hoặc khó chịu; dừng nghỉ khi tay mỏi.'] }
    ], related: ['notation-basic', 'turning-accuracy', 'cube-setup']
  },
  {
    id: 'turning-accuracy', category: 'speedcubing', title: 'TPS và độ chính xác khi xoay', readMinutes: 4,
    excerpt: 'TPS chỉ là số move mỗi giây; tốc độ hữu ích phải đi cùng khả năng kiểm soát và hạn chế lockup.',
    sections: [
      { heading: 'TPS', paragraphs: ['TPS (turns per second) mô tả số lượt xoay trung bình mỗi giây trong một khoảng thời gian. TPS cao không tự động đồng nghĩa với solve nhanh hơn nếu có nhiều pause, move thừa hoặc lockup.'] },
      { heading: 'Turning accuracy', paragraphs: ['Độ chính xác thể hiện ở việc move đi hết góc xoay, không bị kẹt và không phải sửa lại. Khi tập, ưu tiên nhịp xoay có thể kiểm soát thay vì đẩy tốc độ vượt khả năng nhận diện.'] },
      { heading: 'Cách cải thiện', bullets: ['Tập từng thuật toán ở tốc độ đều.', 'Giảm lực bóp cube và điều chỉnh cách cầm.', 'Ghi nhận move nào thường bị lockup.', 'Kết hợp luyện nhận diện để giảm pause giữa các bước.'] }
    ], related: ['fingertricks', 'lookahead', 'solve-review']
  },
  {
    id: 'solve-review', category: 'speedcubing', title: 'Phân tích solve để biết mình cần luyện gì', readMinutes: 4,
    excerpt: 'Thay vì chỉ nhìn single, hãy tìm nguyên nhân làm mất thời gian trong Cross, F2L và tầng cuối.',
    sections: [
      { heading: 'Ghi nhận sau solve', bullets: ['Cross có được lập kế hoạch trước không?', 'F2L bị dừng ở pair nào và vì sao?', 'Có rotation hoặc regrip không cần thiết không?', 'OLL/PLL nhận diện có ngay lập tức không?', 'Có move nào bị lockup hoặc phải sửa lại không?'] },
      { heading: 'Chọn một mục tiêu nhỏ', paragraphs: ['Chọn một điểm gây pause nhiều nhất và dành một phần buổi luyện cho nó. Ví dụ: luyện Cross mặt D, tập F2L chậm không dừng, hoặc nhận diện PLL riêng.', 'So sánh trung bình của nhiều solve thay vì kết luận từ một single. Một kết quả đơn lẻ có thể bị ảnh hưởng bởi scramble và sai số ngẫu nhiên.'] }
    ], related: ['cross', 'f2l', 'lookahead', 'turning-accuracy']
  },
  {
    id: 'puzzle-2x2', category: 'puzzles', title: 'Rubik 2×2', readMinutes: 3,
    excerpt: 'Cube chỉ gồm tám góc; các phương pháp thường tập trung vào giải góc và định hướng/hoán vị tầng cuối.',
    sections: [
      { heading: 'Cấu tạo', paragraphs: ['2×2 có tám mảnh góc và không có mảnh cạnh hay tâm cố định như 3×3. Trên nhiều cube, phần cơ cấu bên trong vẫn có lõi và các chi tiết giữ góc.'] },
      { heading: 'Phương pháp', paragraphs: ['Người mới có thể dùng phương pháp từng tầng. Ortega là phương pháp phổ biến gồm giải một mặt, định hướng mặt đối diện rồi hoán vị góc; CLL giải tầng cuối theo một bước sau khi hoàn thiện tầng đầu.'] },
      { heading: 'Khi luyện tập', paragraphs: ['Scramble 2×2 có quy tắc riêng và không nên dùng chuỗi move 3×3 bất kỳ rồi gọi là scramble chuẩn. Kiểm tra công cụ sinh scramble đang dùng phương pháp nào.'] }
    ], related: ['beginner-method', 'cfop-overview']
  },
  {
    id: 'puzzle-nxn', category: 'puzzles', title: 'Rubik NxN: 4×4 đến 7×7', readMinutes: 5,
    excerpt: 'Các cube lớn có nhiều tâm và cạnh cần ghép; phương pháp Reduction giải chúng bằng cách đưa về trạng thái gần 3×3.',
    sections: [
      { heading: 'Điểm khác 3×3', paragraphs: ['Cube NxN lớn hơn có nhiều mảnh tâm và cạnh tạo thành các nhóm. Ở cube chẵn như 4×4 và 6×6 không có một mảnh tâm đơn lẻ cố định ở chính giữa mỗi mặt theo cách của 3×3.', 'Khi giải cube lớn, người chơi thường phải ghép tâm và ghép các cạnh trước khi dùng các bước tương tự 3×3.'] },
      { heading: 'Reduction', bullets: ['Giải các tâm thành từng khối màu.', 'Ghép các mảnh cạnh thành cạnh hoàn chỉnh.', 'Giải cube gần như một 3×3.', 'Xử lý parity nếu xuất hiện ở cube chẵn.'] },
      { heading: 'Biến thể', paragraphs: ['Yau là một cách tổ chức giải phổ biến cho 4×4, thay đổi thứ tự hoàn thành tâm và cạnh để hỗ trợ Cross sớm hơn. Có nhiều biến thể và cách tối ưu khác nhau.'] }
    ], related: ['cube-anatomy', 'beginner-method']
  },
  {
    id: 'puzzle-pyraminx', category: 'puzzles', title: 'Pyraminx', readMinutes: 3,
    excerpt: 'Câu đố hình tứ diện có các đầu tip, phần trung tâm và các cạnh; cách giải cơ bản thường khá ngắn.',
    sections: [
      { heading: 'Cấu tạo và thao tác', paragraphs: ['Pyraminx là puzzle hình tứ diện. Các tip ở bốn đỉnh có thể xoay độc lập; phần thân gồm các mảnh trung tâm và cạnh. Ký hiệu move khác với Rubik 3×3.'] },
      { heading: 'Lộ trình cơ bản', bullets: ['Đưa các tip về đúng hướng.', 'Giải hoặc căn chỉnh các trung tâm.', 'Giải các cạnh theo phương pháp beginner.', 'Học thêm các trường hợp L4E khi muốn tối ưu.'] }
    ], related: ['puzzle-skewb', 'notation-basic']
  },
  {
    id: 'puzzle-megaminx', category: 'puzzles', title: 'Megaminx', readMinutes: 4,
    excerpt: 'Puzzle 12 mặt có cấu trúc cạnh và góc phong phú; nhiều người dùng cách giải theo tầng.',
    sections: [
      { heading: 'Đặc điểm', paragraphs: ['Megaminx có 12 mặt hình ngũ giác, với các mảnh cạnh và góc. Do có nhiều mặt hơn 3×3, số lượng mảnh và trình tự giải dài hơn đáng kể.'] },
      { heading: 'Phương pháp', paragraphs: ['Người mới thường giải lần lượt các ngôi sao/cạnh và góc, sau đó tiếp tục theo tầng. Một số bước có thể mượn ý tưởng từ 3×3, nhưng notation và cách xử lý cần phù hợp với Megaminx.'] }
    ], related: ['puzzle-nxn', 'beginner-method']
  },
  {
    id: 'puzzle-skewb', category: 'puzzles', title: 'Skewb', readMinutes: 3,
    excerpt: 'Skewb xoay quanh các góc, làm các phần lớn của puzzle di chuyển cùng lúc.',
    sections: [
      { heading: 'Cơ chế', paragraphs: ['Skewb có hình dạng gần lập phương nhưng các trục xoay đi qua các góc. Một lần xoay làm di chuyển một nhóm mảnh quanh góc thay vì chỉ một lớp mặt như 3×3.'] },
      { heading: 'Bắt đầu học', paragraphs: ['Hãy học cách đọc ký hiệu riêng của Skewb, nhận diện các center và corner, rồi dùng phương pháp beginner trước khi học các hệ công thức nâng cao.'] }
    ], related: ['puzzle-pyraminx', 'notation-basic']
  },
  {
    id: 'puzzle-square1-clock', category: 'puzzles', title: 'Square-1 và Clock', readMinutes: 4,
    excerpt: 'Hai puzzle có cơ chế và notation rất khác 3×3: Square-1 thay đổi hình dạng, Clock điều khiển các kim.',
    sections: [
      { heading: 'Square-1', paragraphs: ['Square-1 có thể thay đổi hình dạng khi xoay các lớp và cắt ở vị trí cho phép. Người giải thường phải đưa puzzle về hình dạng cube trước khi giải các lớp. Ký hiệu thường ghi góc xoay của hai lớp cùng thao tác cắt.'] },
      { heading: 'Clock', paragraphs: ['Clock có các mặt đồng hồ và kim chỉ giờ. Người chơi xoay bánh xe và dùng các nút/pin để điều khiển nhóm kim. Cách giải tập trung đưa các kim về vị trí mục tiêu trên cả hai mặt.'] },
      { heading: 'Lưu ý', paragraphs: ['Không sử dụng notation 3×3 cho Square-1 hoặc Clock. Hãy chọn tài liệu và scramble generator đúng puzzle.'] }
    ], related: ['notation-basic', 'puzzle-megaminx']
  },
  {
    id: 'cube-mechanics', category: 'hardware', title: 'Cơ chế bên trong cube', readMinutes: 4,
    excerpt: 'Lõi, trục, chân mảnh, nam châm và bề mặt tiếp xúc ảnh hưởng đến cảm giác xoay.',
    sections: [
      { heading: 'Cơ cấu', paragraphs: ['Các cube speed hiện đại thường dùng một lõi giữ các mảnh tâm và các cơ cấu chân mảnh để giữ các lớp liên kết khi xoay. Thiết kế cụ thể thay đổi theo hãng và mẫu cube.', 'Một số thiết kế dùng hệ thống điều chỉnh lực căng hoặc khoảng nén; mẫu khác có cơ cấu không cần dụng cụ. Không có một thiết lập phù hợp với tất cả người chơi.'] },
      { heading: 'Cảm giác xoay', paragraphs: ['Độ nhẹ, độ ổn định, độ êm và độ cắt góc là các cảm nhận khác nhau. Cube xoay nhẹ không nhất thiết ổn định hơn; cần chọn thiết lập phù hợp với lực tay và thói quen xoay.'] }
    ], related: ['magnet-system', 'cube-setup', 'corner-cutting']
  },
  {
    id: 'magnet-system', category: 'hardware', title: 'Hệ thống nam châm trong Rubik', readMinutes: 4,
    excerpt: 'Nam châm có thể hỗ trợ căn chỉnh lớp xoay; hệ thống core-magnetic bổ sung tương tác giữa mảnh và lõi.',
    sections: [
      { heading: 'Magnetic cube', paragraphs: ['Ở cube có nam châm, các nam châm đặt giữa một số mảnh tạo lực hút khi lớp tiến gần vị trí căn chỉnh. Cảm giác này có thể giúp cube tự căn chỉnh nhẹ, nhưng mức tác động tùy thiết kế và lực nam châm.'] },
      { heading: 'Core magnets', paragraphs: ['Hệ thống core-magnetic bổ sung nam châm tương tác giữa các mảnh góc/cạnh và lõi hoặc cơ cấu trung tâm. Mục tiêu thường là tăng cảm giác ổn định và định vị lớp, nhưng trải nghiệm còn phụ thuộc cấu trúc tổng thể.'] },
      { heading: 'Chọn theo cảm nhận', paragraphs: ['Nhiều nam châm hơn không tự động tốt hơn. Hãy xem xét tốc độ, độ ổn định, độ nặng tay và khả năng kiểm soát khi chọn cube.'] }
    ], related: ['cube-mechanics', 'cube-setup']
  },
  {
    id: 'corner-cutting', category: 'hardware', title: 'Corner cutting là gì?', readMinutes: 3,
    excerpt: 'Khả năng cube tiếp tục xoay khi các lớp chưa thẳng hàng hoàn toàn, trong giới hạn thiết kế.',
    sections: [
      { heading: 'Khái niệm', paragraphs: ['Corner cutting mô tả khả năng một lớp tiếp tục xoay khi các lớp khác chưa được căn chỉnh hoàn toàn. Mức corner cutting phụ thuộc hình dạng chân mảnh, khe hở, cơ cấu và thiết lập cube.'] },
      { heading: 'Không nên lạm dụng', paragraphs: ['Khả năng cắt góc tốt có thể giảm lockup trong những tình huống lệch nhẹ, nhưng không thay thế turning accuracy. Xoay lệch liên tục có thể làm giảm kiểm soát và khiến solve không ổn định.'] }
    ], related: ['cube-mechanics', 'turning-accuracy']
  },
  {
    id: 'cube-setup', category: 'hardware', title: 'Vệ sinh và bảo dưỡng Rubik', readMinutes: 4,
    excerpt: 'Giữ cube sạch, kiểm tra cơ cấu và dùng chất bôi trơn tương thích theo hướng dẫn của nhà sản xuất.',
    sections: [
      { heading: 'Vệ sinh', bullets: ['Tháo và vệ sinh theo hướng dẫn của mẫu cube.', 'Loại bỏ bụi và cặn bám ở bề mặt tiếp xúc.', 'Lắp lại đúng vị trí, kiểm tra các mảnh trước khi xoay.', 'Tránh để chất lỏng không phù hợp tiếp xúc với nhựa hoặc chi tiết bên trong.'] },
      { heading: 'Bôi trơn và điều chỉnh', paragraphs: ['Chỉ dùng lube được thiết kế cho cube và làm theo khuyến nghị của nhà sản xuất. Bắt đầu với lượng nhỏ; quá nhiều lube có thể làm cube nặng hoặc bết.', 'Thay đổi từng yếu tố một để biết tác động của nó. Ghi lại thiết lập ban đầu để có thể quay về khi cần.'] },
      { heading: 'Bảo quản', paragraphs: ['Giữ cube tránh bụi, nhiệt độ cao và nơi dễ rơi. Nếu cube có tiếng kêu hoặc xoay bất thường, hãy kiểm tra lắp ráp trước khi tiếp tục sử dụng.'] }
    ], related: ['cube-mechanics', 'magnet-system', 'corner-cutting']
  }
];
