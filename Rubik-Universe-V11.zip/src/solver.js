export const FACE_ORDER = 'URFDLB';
export const SOLVED_FACELETS = FACE_ORDER.split('').map(face => face.repeat(9)).join('');

const CORNER_FACELETS = [
  [8, 9, 20], [6, 18, 38], [0, 36, 47], [2, 45, 11],
  [29, 26, 15], [27, 44, 24], [33, 53, 42], [35, 17, 51]
];
const EDGE_FACELETS = [
  [5, 10], [7, 19], [3, 37], [1, 46], [32, 16], [28, 25],
  [30, 43], [34, 52], [23, 12], [21, 41], [50, 39], [48, 14]
];
const CORNER_COLORS = [
  ['U', 'R', 'F'], ['U', 'F', 'L'], ['U', 'L', 'B'], ['U', 'B', 'R'],
  ['D', 'F', 'R'], ['D', 'L', 'F'], ['D', 'B', 'L'], ['D', 'R', 'B']
];
const EDGE_COLORS = [
  ['U', 'R'], ['U', 'F'], ['U', 'L'], ['U', 'B'], ['D', 'R'], ['D', 'F'],
  ['D', 'L'], ['D', 'B'], ['F', 'R'], ['F', 'L'], ['B', 'L'], ['B', 'R']
];

function permutationParity(values) {
  let parity = 0;
  for (let i = 0; i < values.length; i += 1) {
    for (let j = i + 1; j < values.length; j += 1) {
      if (values[i] > values[j]) parity ^= 1;
    }
  }
  return parity;
}

export function validateFacelets(input) {
  const facelets = String(input ?? '').trim().toUpperCase();
  if (facelets.length !== 54) return { valid: false, error: 'Cần nhập đủ 54 ô màu.' };
  if (!/^[URFDLB]{54}$/.test(facelets)) return { valid: false, error: 'Có ô màu không hợp lệ.' };

  const counts = Object.fromEntries([...FACE_ORDER].map(face => [face, 0]));
  for (const color of facelets) counts[color] += 1;
  const wrongCount = Object.entries(counts).find(([, count]) => count !== 9);
  if (wrongCount) return { valid: false, error: `Màu ${wrongCount[0]} đang có ${wrongCount[1]} ô; mỗi màu phải có đúng 9 ô.` };

  for (let face = 0; face < 6; face += 1) {
    if (facelets[face * 9 + 4] !== FACE_ORDER[face]) {
      return { valid: false, error: `Tâm mặt ${FACE_ORDER[face]} phải giữ nguyên màu của mặt đó.` };
    }
  }

  const cornerPermutation = [];
  let cornerOrientationSum = 0;
  for (const positions of CORNER_FACELETS) {
    const colors = positions.map(index => facelets[index]);
    const orientation = colors.findIndex(color => color === 'U' || color === 'D');
    if (orientation < 0) return { valid: false, error: 'Có góc không chứa màu trắng hoặc vàng; trạng thái không hợp lệ.' };
    const first = colors[(orientation + 1) % 3];
    const second = colors[(orientation + 2) % 3];
    const piece = CORNER_COLORS.findIndex(candidate => candidate[1] === first && candidate[2] === second);
    if (piece < 0) return { valid: false, error: 'Có bộ ba màu góc không tồn tại trên Rubik chuẩn.' };
    cornerPermutation.push(piece);
    cornerOrientationSum += orientation;
  }
  if (new Set(cornerPermutation).size !== 8) return { valid: false, error: 'Một viên góc bị lặp hoặc thiếu.' };
  if (cornerOrientationSum % 3 !== 0) return { valid: false, error: 'Tổng hướng xoay các góc không hợp lệ.' };

  const edgePermutation = [];
  let edgeOrientationSum = 0;
  for (const positions of EDGE_FACELETS) {
    const colors = positions.map(index => facelets[index]);
    let piece = EDGE_COLORS.findIndex(candidate => candidate[0] === colors[0] && candidate[1] === colors[1]);
    if (piece >= 0) {
      edgeOrientationSum += 0;
    } else {
      piece = EDGE_COLORS.findIndex(candidate => candidate[0] === colors[1] && candidate[1] === colors[0]);
      if (piece < 0) return { valid: false, error: 'Có cặp màu cạnh không tồn tại trên Rubik chuẩn.' };
      edgeOrientationSum += 1;
    }
    edgePermutation.push(piece);
  }
  if (new Set(edgePermutation).size !== 12) return { valid: false, error: 'Một viên cạnh bị lặp hoặc thiếu.' };
  if (edgeOrientationSum % 2 !== 0) return { valid: false, error: 'Tổng hướng lật các cạnh không hợp lệ.' };
  if (permutationParity(cornerPermutation) !== permutationParity(edgePermutation)) {
    return { valid: false, error: 'Parity góc và cạnh không khớp; trạng thái này không thể xuất hiện khi xoay Rubik bình thường.' };
  }
  return { valid: true, error: '', facelets };
}
