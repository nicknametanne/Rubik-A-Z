/* cube.js by Petri Lehtinen and Ludovic Fernandez; MIT License. */
const CDN = 'https://cdn.jsdelivr.net/npm/cubejs@1.3.2/lib/';

try {
  importScripts(`${CDN}cube.js`, `${CDN}solve.js`);
  const SolverCube = self.Cube;
  SolverCube.initSolver();
  self.postMessage({ type: 'ready' });

  self.onmessage = event => {
    const message = event.data || {};
    if (message.type === 'scramble') {
      const requestId = message.requestId;
      try {
        const count = Math.max(1, Math.min(20, Math.trunc(Number(message.count) || 1)));
        const scrambles = [];
        for (let index = 0; index < count; index += 1) {
          const scramble = SolverCube.scramble();
          if (typeof scramble !== 'string' || !scramble.trim()) throw new Error('Bộ sinh không trả về chuỗi scramble hợp lệ.');
          const scrambledCube = new SolverCube().move(scramble);
          const solution = scrambledCube.solve(22);
          if (!solution || !scrambledCube.clone().move(solution).isSolved()) {
            throw new Error('Không xác minh được trạng thái random-state vừa tạo.');
          }
          scrambles.push(scramble);
        }
        self.postMessage({ type: 'scrambles', requestId, scrambles });
      } catch (error) {
        self.postMessage({ type: 'scramble-error', requestId, message: error?.message || 'Không tạo được scramble random-state.' });
      }
      return;
    }

    if (message.type !== 'solve') return;
    const requestId = message.requestId;
    try {
      const facelets = String(message.facelets || '');
      if (!/^[URFDLB]{54}$/.test(facelets)) throw new Error('Dữ liệu cube phải có đúng 54 ký tự URFDLB.');
      const cube = SolverCube.fromString(facelets);
      if (cube.asString() !== facelets) throw new Error('Không thể chuyển trạng thái màu thành các viên góc/cạnh hợp lệ.');
      const solution = cube.solve(22);
      if (solution === null) throw new Error('Không tìm được lời giải cho trạng thái này.');
      const check = cube.clone().move(solution);
      if (!check.isSolved()) throw new Error('Không xác minh được lời giải; hãy kiểm tra lại trạng thái cube.');
      self.postMessage({ type: 'solution', requestId, solution, moves: solution ? solution.split(/\s+/).filter(Boolean).length : 0 });
    } catch (error) {
      self.postMessage({ type: 'solve-error', requestId, message: error?.message || 'Solver gặp lỗi không xác định.' });
    }
  };
} catch (error) {
  self.postMessage({ type: 'error', message: `Không tải được solver hoặc scramble generator. Kiểm tra kết nối Internet. (${error?.message || 'CDN error'})` });
}
