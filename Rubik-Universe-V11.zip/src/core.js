export const STORAGE_KEY = 'rubik-universe-v1';
export const CURRENT_VERSION = 5;
export const DEFAULT_SESSION_ID = 'session-default';

export function createDefaultData() {
  const now = new Date().toISOString();
  return {
    version: CURRENT_VERSION,
    settings: { theme: 'dark', inspection: true, sound: false, timerDecimals: 2, dashboardWidgets: { recent: true, quickAccess: true }, reducedMotion: false, compactMode: false },
    activeSessionId: DEFAULT_SESSION_ID,
    sessions: [{ id: DEFAULT_SESSION_ID, name: '3x3 CFOP', puzzle: '3x3', createdAt: now }],
    solves: [],
    algorithms: [],
    caseProgress: {},
    scrambleHistory: [],
    academyProgress: { completed: [] },
    cfopPractice: { crossLogs: [], f2lLogs: [] }
  };
}

export function migrateData(parsed) {
  if (!parsed || ![1, 2, 3, 4, CURRENT_VERSION].includes(parsed.version) || !Array.isArray(parsed.sessions) || !Array.isArray(parsed.solves) || !Array.isArray(parsed.algorithms)) return null;
  const fallback = createDefaultData();
  const sessions = parsed.sessions.filter(s => s && typeof s.id === 'string' && typeof s.name === 'string');
  if (!sessions.length) sessions.push(...fallback.sessions);
  const sessionIds = new Set(sessions.map(s => s.id));
  const solves = parsed.solves.filter(s => isValidSolve(s) && sessionIds.has(s.sessionId));
  const algorithms = parsed.algorithms.filter(isValidAlgorithm).map(alg => ({
    ...alg,
    favorite: Boolean(alg.favorite),
    mastered: Boolean(alg.mastered),
    review: normalizeReview(alg.review, alg.mastered)
  }));
  const sourceSettings = parsed.settings && typeof parsed.settings === 'object' && !Array.isArray(parsed.settings) ? parsed.settings : {};
  const sourceWidgets = sourceSettings.dashboardWidgets && typeof sourceSettings.dashboardWidgets === 'object' ? sourceSettings.dashboardWidgets : {};
  const settings = {
    ...fallback.settings,
    ...sourceSettings,
    theme: sourceSettings.theme === 'light' ? 'light' : 'dark',
    inspection: sourceSettings.inspection !== false,
    sound: Boolean(sourceSettings.sound),
    timerDecimals: Number(sourceSettings.timerDecimals) === 3 ? 3 : 2,
    dashboardWidgets: {
      recent: sourceWidgets.recent !== false,
      quickAccess: sourceWidgets.quickAccess !== false
    },
    reducedMotion: Boolean(sourceSettings.reducedMotion),
    compactMode: Boolean(sourceSettings.compactMode)
  };
  return {
    ...fallback,
    ...parsed,
    version: CURRENT_VERSION,
    settings,
    sessions,
    solves,
    algorithms,
    caseProgress: parsed.caseProgress && typeof parsed.caseProgress === 'object' && !Array.isArray(parsed.caseProgress) ? parsed.caseProgress : {},
    scrambleHistory: Array.isArray(parsed.scrambleHistory) ? parsed.scrambleHistory.filter(item => item && typeof item.id === 'string' && typeof item.scramble === 'string' && typeof item.puzzle === 'string').slice(-200) : [],
    academyProgress: { completed: Array.isArray(parsed.academyProgress?.completed) ? [...new Set(parsed.academyProgress.completed.filter(id => typeof id === 'string'))] : [] },
    cfopPractice: normalizeCfopPractice(parsed.cfopPractice),
    activeSessionId: sessions.some(s => s.id === parsed.activeSessionId) ? parsed.activeSessionId : sessions[0].id
  };
}

function normalizeCfopPractice(value) {
  const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const crossLogs = (Array.isArray(source.crossLogs) ? source.crossLogs : []).filter(entry =>
    entry && typeof entry.id === 'string' && typeof entry.scramble === 'string' &&
    typeof entry.moves === 'string' && Number.isFinite(entry.moveCount) &&
    Number.isFinite(entry.rotationCount) && typeof entry.createdAt === 'string'
  ).map(entry => ({
    id: entry.id, scramble: entry.scramble, moves: entry.moves,
    moveCount: Math.max(0, Math.min(100, Math.trunc(entry.moveCount))),
    rotationCount: Math.max(0, Math.min(100, Math.trunc(entry.rotationCount))),
    createdAt: entry.createdAt
  })).slice(-200);
  const f2lLogs = (Array.isArray(source.f2lLogs) ? source.f2lLogs : []).filter(entry =>
    entry && typeof entry.id === 'string' && typeof entry.caseId === 'string' &&
    Number.isFinite(entry.rotationCount) && Number.isFinite(entry.pauseCount) &&
    Number.isFinite(entry.durationMs) && typeof entry.createdAt === 'string'
  ).map(entry => ({
    id: entry.id, caseId: entry.caseId,
    rotationCount: Math.max(0, Math.min(100, Math.trunc(entry.rotationCount))),
    pauseCount: Math.max(0, Math.min(100, Math.trunc(entry.pauseCount))),
    durationMs: Math.max(0, Math.min(3600000, Math.trunc(entry.durationMs))),
    createdAt: entry.createdAt
  })).slice(-200);
  return { crossLogs, f2lLogs };
}

export function filterSolvesByPuzzle(solves, puzzle = 'all', sessions = []) {
  if (!Array.isArray(solves)) return [];
  if (!puzzle || puzzle === 'all') return [...solves];
  const sessionPuzzles = new Map((Array.isArray(sessions) ? sessions : []).map(session => [session.id, session.puzzle]));
  return solves.filter(solve => (solve.puzzle || sessionPuzzles.get(solve.sessionId) || '3x3') === puzzle);
}

export function loadData(storage = globalThis.localStorage) {
  const fallback = createDefaultData();
  try {
    const raw = storage?.getItem(STORAGE_KEY);
    if (!raw) return fallback;
    return migrateData(JSON.parse(raw)) || fallback;
  } catch {
    return fallback;
  }
}

export function saveData(data, storage = globalThis.localStorage) {
  try {
    storage?.setItem(STORAGE_KEY, JSON.stringify({ ...data, version: CURRENT_VERSION }));
    return true;
  } catch {
    return false;
  }
}

export function isValidSolve(solve) {
  return Boolean(solve && typeof solve.id === 'string' && typeof solve.sessionId === 'string' &&
    Number.isFinite(solve.rawMs) && solve.rawMs >= 0 &&
    ['none', '+2', 'DNF'].includes(solve.penalty) && typeof solve.createdAt === 'string');
}

export function isValidAlgorithm(alg) {
  return Boolean(alg && typeof alg.id === 'string' && typeof alg.name === 'string' &&
    typeof alg.moves === 'string' && ['OLL', 'PLL', 'F2L', 'OTHER'].includes(alg.type));
}

export function isValidNotation(moves) {
  const tokens = String(moves ?? '').trim().split(/\s+/).filter(Boolean);
  if (!tokens.length) return false;
  return tokens.every(token => /^(?:[RLUDFB]w?|[MES]|[rludfb]|[xyz])(?:2|')?$/.test(token));
}

export function inspectionPenalty(elapsedMs) {
  if (!Number.isFinite(elapsedMs) || elapsedMs < 0) return 'none';
  if (elapsedMs > 17000) return 'DNF';
  if (elapsedMs > 15000) return '+2';
  return 'none';
}

export function effectiveTime(solve) {
  if (!solve || solve.penalty === 'DNF') return Infinity;
  return solve.rawMs + (solve.penalty === '+2' ? 2000 : 0);
}

export function averageOf(solves, size) {
  if (!Array.isArray(solves) || solves.length < size || size < 3) return null;
  const window = solves.slice(-size);
  const values = window.map(effectiveTime).sort((a, b) => a - b);
  values.shift();
  values.pop();
  if (values.some(value => !Number.isFinite(value))) return Infinity;
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

export function bestAverage(solves, size) {
  if (!Array.isArray(solves) || solves.length < size) return null;
  let best = Infinity;
  for (let end = size; end <= solves.length; end += 1) {
    const average = averageOf(solves.slice(0, end), size);
    if (average !== null && average < best) best = average;
  }
  return Number.isFinite(best) ? best : (best === Infinity ? Infinity : null);
}

export function meanOf(solves) {
  if (!solves.length) return null;
  const values = solves.map(effectiveTime);
  if (values.some(value => !Number.isFinite(value))) return Infinity;
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

export function formatTime(ms, decimals = 2) {
  if (ms === null || ms === undefined || !Number.isFinite(ms)) return ms === Infinity ? 'DNF' : '—';
  const safe = Math.max(0, ms);
  const totalSeconds = safe / 1000;
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds - minutes * 60;
  if (minutes > 0) return `${minutes}:${seconds.toFixed(decimals).padStart(decimals + 3, '0')}`;
  return seconds.toFixed(decimals);
}

export function parseTime(input) {
  const text = String(input ?? '').trim().replace(',', '.');
  if (!text) return null;
  if (/^\d+:\d{1,2}(?:\.\d{1,3})?$/.test(text)) {
    const [minutes, seconds] = text.split(':');
    const sec = Number(seconds);
    if (sec >= 60) return null;
    return (Number(minutes) * 60 + sec) * 1000;
  }
  if (/^\d+(?:\.\d{1,3})?$/.test(text)) return Number(text) * 1000;
  return null;
}

const FACES = ['R', 'L', 'U', 'D', 'F', 'B'];
const SUFFIXES = ['', "'", '2'];

export function generatePracticeScramble(length = 20, random = Math.random) {
  const moves = [];
  let previousFace = '';
  for (let i = 0; i < length; i += 1) {
    let face;
    do { face = FACES[Math.floor(random() * FACES.length)]; } while (face === previousFace);
    const suffix = SUFFIXES[Math.floor(random() * SUFFIXES.length)];
    moves.push(face + suffix);
    previousFace = face;
  }
  return moves.join(' ');
}


// Legal face-turn practice sequences for NxN cubes. These are explicitly not WCA random-state scrambles.
export function generateCubePracticeScramble(size = 3, length = null, random = Math.random) {
  const n = Number(size);
  if (!Number.isInteger(n) || n < 2 || n > 7) throw new RangeError('Cube size must be between 2 and 7.');
  const count = Number.isInteger(length) ? Math.max(1, Math.min(120, length)) : (n === 2 ? 11 : n === 3 ? 20 : 40 + (n - 4) * 10);
  const faces = ['R', 'L', 'U', 'D', 'F', 'B'];
  const suffixes = ['', "'", '2'];
  const moves = [];
  let previousFace = '';
  while (moves.length < count) {
    const candidates = faces.filter(face => face !== previousFace);
    const face = candidates[Math.min(candidates.length - 1, Math.floor(random() * candidates.length))];
    const wideAllowed = n >= 4 && random() < 0.28;
    const wideDepth = wideAllowed && n >= 5 && random() < 0.2 ? 2 + Math.floor(random() * (n - 2)) : 0;
    const suffix = suffixes[Math.min(suffixes.length - 1, Math.floor(random() * suffixes.length))];
    moves.push(`${wideDepth ? `${wideDepth}` : ''}${face}${wideAllowed ? 'w' : ''}${suffix}`);
    previousFace = face;
  }
  return moves.join(' ');
}

export function getSessionSolves(data, sessionId) {
  return data.solves.filter(solve => solve.sessionId === sessionId).sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
}

export function normalizeReview(review, mastered = false) {
  const safe = review && typeof review === 'object' ? review : {};
  const now = Date.now();
  return {
    status: ['new', 'learning', 'known'].includes(safe.status) ? safe.status : (mastered ? 'known' : 'new'),
    intervalDays: Number.isFinite(safe.intervalDays) && safe.intervalDays >= 0 ? safe.intervalDays : (mastered ? 7 : 0),
    ease: Number.isFinite(safe.ease) ? Math.min(3, Math.max(1.3, safe.ease)) : 2.5,
    repetitions: Number.isInteger(safe.repetitions) && safe.repetitions >= 0 ? safe.repetitions : (mastered ? 1 : 0),
    lapses: Number.isInteger(safe.lapses) && safe.lapses >= 0 ? safe.lapses : 0,
    dueAt: Number.isFinite(safe.dueAt) ? safe.dueAt : (mastered ? now + 7 * 86400000 : now),
    lastReviewedAt: Number.isFinite(safe.lastReviewedAt) ? safe.lastReviewedAt : null
  };
}

export function scheduleReview(previous, rating, now = Date.now()) {
  const review = normalizeReview(previous);
  const next = { ...review, lastReviewedAt: now };
  if (rating === 'again') {
    next.status = 'learning';
    next.intervalDays = 0;
    next.dueAt = now + 10 * 60 * 1000;
    next.repetitions = 0;
    next.lapses += 1;
    next.ease = Math.max(1.3, next.ease - 0.2);
  } else if (rating === 'hard') {
    next.status = 'learning';
    next.intervalDays = Math.max(1, review.intervalDays * 1.2 || 1);
    next.dueAt = now + next.intervalDays * 86400000;
    next.repetitions += 1;
    next.ease = Math.max(1.3, next.ease - 0.15);
  } else if (rating === 'good') {
    next.status = review.repetitions === 0 ? 'learning' : 'known';
    next.intervalDays = review.intervalDays === 0 ? 1 : Math.max(1, review.intervalDays * review.ease);
    next.dueAt = now + next.intervalDays * 86400000;
    next.repetitions += 1;
  } else if (rating === 'easy') {
    next.status = 'known';
    next.intervalDays = Math.max(4, review.intervalDays * review.ease * 1.3 || 4);
    next.dueAt = now + next.intervalDays * 86400000;
    next.repetitions += 1;
    next.ease = Math.min(3, next.ease + 0.15);
  } else {
    throw new Error('Invalid review rating');
  }
  return next;
}

export function makeId(prefix = 'id') {
  if (globalThis.crypto?.randomUUID) return `${prefix}-${crypto.randomUUID()}`;
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
}
