import { createSolvedCube, applyCubeMoves, invertCubeMoves } from './cube.js';

const COLORS = Object.freeze({
  U: '#f5d90a',
  D: '#f4f4f4',
  F: '#1fa84f',
  B: '#2a62d9',
  R: '#f07a13',
  L: '#d62e2e'
});
const GRAY = '#8b9099';
const diagramCache = new Map();

function coordinateKey(position, normal) {
  return `${position.join(',')}|${normal.join(',')}`;
}

function createCaseState(moves) {
  const inverse = invertCubeMoves(moves).join(' ');
  return applyCubeMoves(createSolvedCube(), inverse);
}

function renderTopDiagram(state, isOll, mode = 'standard') {
  const stickers = new Map(state.map(sticker => [coordinateKey(sticker.position, sticker.normal), sticker.color]));
  const rect = (x, y, width, height, color) =>
    `<rect x="${x}" y="${y}" width="${width}" height="${height}" rx="2" fill="${color}" stroke="rgba(0,0,0,.3)" stroke-width=".45"/>`;
  const colorFor = (position, normal) => {
    const color = stickers.get(coordinateKey(position, normal));
    if (!color) return GRAY;
    const edgeIndex = Math.abs(position[0]) + Math.abs(position[2]);
    if (mode === 'cmll' && (edgeIndex !== 2 || position[1] !== 1)) return GRAY;
    if (mode === 'lse' && (edgeIndex !== 1 || position[1] !== 1)) return GRAY;
    return isOll ? (color === 'U' ? COLORS.U : GRAY) : (COLORS[color] || GRAY);
  };

  let shapes = '';
  for (let x = -1; x <= 1; x += 1) {
    const left = (x + 1) * 18 + 17;
    for (let z = -1; z <= 1; z += 1) {
      const top = (z + 1) * 18 + 17;
      shapes += rect(left, top, 17, 17, colorFor([x, 1, z], [0, 1, 0]));
    }
    shapes += rect(left, 73, 17, 8, colorFor([x, 1, 1], [0, 0, 1]));
    shapes += rect(left, 7, 17, 8, colorFor([x, 1, -1], [0, 0, -1]));
    shapes += rect(73, left, 8, 17, colorFor([1, 1, x], [1, 0, 0]));
    shapes += rect(7, left, 8, 17, colorFor([-1, 1, x], [-1, 0, 0]));
  }

  const label = mode === 'cmll'
    ? 'CMLL: chỉ tô nổi bốn góc tầng trên; cạnh bị làm mờ vì không thuộc bước này'
    : mode === 'lse'
      ? 'LSE: chỉ tô nổi các cạnh liên quan tới bước Last Six Edges'
      : isOll
        ? 'Hình nhận diện OLL nhìn từ trên xuống; vàng là sticker U hướng lên'
        : 'Hình nhận diện PLL nhìn từ trên xuống với màu các miếng';
  return `<svg viewBox="0 0 88 88" role="img" aria-label="${label}" focusable="false">${shapes}</svg>`;
}


function renderLseDiagram(state) {
  const stickers = new Map(state.map(sticker => [coordinateKey(sticker.position, sticker.normal), sticker.color]));
  const edges = [
    ['UL', [-1,1,0], [0,1,0], [-1,0,0]],
    ['UR', [1,1,0], [0,1,0], [1,0,0]],
    ['UF', [0,1,1], [0,1,0], [0,0,1]],
    ['UB', [0,1,-1], [0,1,0], [0,0,-1]],
    ['DF', [0,-1,1], [0,-1,0], [0,0,1]],
    ['DB', [0,-1,-1], [0,-1,0], [0,0,-1]]
  ];
  const tile = (label, position, firstNormal, secondNormal, index) => {
    const first = stickers.get(coordinateKey(position, firstNormal));
    const second = stickers.get(coordinateKey(position, secondNormal));
    const firstColor = COLORS[first] || GRAY;
    const secondColor = COLORS[second] || GRAY;
    const x = 12 + (index % 3) * 56;
    const y = 8 + Math.floor(index / 3) * 48;
    return `<g transform="translate(${x} ${y})"><rect x="0" y="0" width="30" height="14" rx="2" fill="${firstColor}" stroke="rgba(0,0,0,.45)"/><rect x="15" y="0" width="15" height="14" rx="2" fill="${secondColor}" stroke="rgba(0,0,0,.45)"/><text x="15" y="28" text-anchor="middle" fill="currentColor" font-size="9" font-weight="700">${label}</text></g>`;
  };
  const items = edges.map(([label, position, firstNormal, secondNormal], index) => tile(label, position, firstNormal, secondNormal, index)).join('');
  return `<svg viewBox="0 0 184 106" role="img" aria-label="Roux LSE six-edge recognition diagram: UL, UR, UF, UB, DF, DB" focusable="false"><text x="92" y="7" text-anchor="middle" fill="currentColor" font-size="6">SIX EDGES · U/D STICKER + SIDE STICKER</text>${items}</svg>`;
}

function renderF2lIsometric(state) {
  const width = 52 / 3;
  const project = ([x, y, z]) => [
    ((x - z) * 0.866 * width).toFixed(1),
    (((x + z) * 0.5 - y) * width).toFixed(1)
  ];
  const polygons = [];

  for (const sticker of state) {
    const normal = sticker.normal;
    if (normal[0] + normal[1] + normal[2] < 1) continue;
    const freeAxes = [0, 1, 2].filter(axis => !normal[axis]);
    const center = sticker.position.map((value, axis) => value + normal[axis] * 0.5);
    const corners = [[1, 1], [1, -1], [-1, -1], [-1, 1]];
    const points = corners.map(([a, b]) => project(center.map((value, axis) =>
      value + (axis === freeAxes[0] ? a : axis === freeAxes[1] ? b : 0) * 0.45
    )).join(',')).join(' ');
    const fill = COLORS[sticker.color] || GRAY;
    polygons.push({ depth: center[0] + center[1] + center[2], markup: `<polygon points="${points}" fill="${fill}" stroke="rgba(0,0,0,.45)" stroke-width=".55"/>` });
  }

  polygons.sort((a, b) => a.depth - b.depth);
  return `<svg viewBox="-60 -60 120 120" role="img" aria-label="Hình nhận diện F2L phối cảnh nhìn từ trên, trước và phải" focusable="false">${polygons.map(item => item.markup).join('')}</svg>`;
}

export function renderCfopCaseDiagram(item, moves = item?.moves) {
  if (!item || !String(moves || '').trim()) return '';
  const mode = String(item.diagramType || item.type || '').toLowerCase();
  const supported = ['f2l', 'oll', 'pll', 'cmll', 'lse', 'beginner', 'ocll', '2-look oll', '2-look pll'];
  if (!supported.includes(mode)) return '';
  const key = `${mode}:${item.id}:${moves}`;
  if (diagramCache.has(key)) return diagramCache.get(key);

  try {
    const state = createCaseState(moves);
    const svg = mode === 'f2l' || mode === 'beginner'
      ? renderF2lIsometric(state)
      : mode === 'lse'
        ? renderLseDiagram(state)
        : renderTopDiagram(state, mode === 'oll' || mode === 'ocll' || mode === '2-look oll', mode);
    const result = `<div class="case-diagram case-diagram-${mode.replace(/[^a-z0-9]+/g, '-')}">${svg}</div>`;
    diagramCache.set(key, result);
    if (diagramCache.size > 600) diagramCache.delete(diagramCache.keys().next().value);
    return result;
  } catch (error) {
    console.warn(`Không thể vẽ hình ${item.name || item.id}:`, error);
    return `<div class="case-diagram case-diagram-fallback" role="img" aria-label="Không thể tạo sơ đồ cho ${String(item.name || item.id).replace(/[<>&\"']/g, '')}"><span>Hình minh họa chưa khả dụng</span></div>`;
  }
}

export function clearCfopDiagramCache() {
  diagramCache.clear();
}
