# Rubik Universe V11

Nền tảng speedcubing cá nhân dùng HTML/CSS/JavaScript ES Modules thuần; không cần framework hoặc bước build. V11 được phát triển trực tiếp trên V9, giữ nguyên Timer, Scramble Center, Solver, Visualizer, Sessions, Statistics, PWA, CFOP 119 case, Academy và dữ liệu hiện có.

## V11 — thư viện phương pháp giải

Trang **Thư viện thuật toán** có các tab riêng:

- **CFOP chuẩn:** giữ 41 F2L + 57 OLL + 21 PLL. Bộ 2-Look OLL/PLL đã tách thành khu riêng ở bên trong CFOP chuẩn, gồm 10 OLL + 6 PLL; không trộn nhãn 2-Look vào danh sách full OLL/PLL.
- **Công thức cá nhân:** giữ nguyên hệ thống thêm/sửa/lưu công thức do người dùng nhập.
- **Beginner chuẩn:** 8 công thức cốt lõi + lộ trình 7 bước. Cross và block-building là kỹ năng trực quan, không có một danh sách công thức đóng duy nhất.
- **Roux chuẩn:** 42 CMLL + 15 LSE; LSE tách riêng 11 case định hướng cạnh và 4 case hoán vị cuối. First Block và Second Block là blockbuilding trực quan.
- **ZZ chuẩn:** 7 OCLL + 21 PLL (lộ trình Last Layer hai bước), bên cạnh hướng dẫn EO/EOCross/EOLine và ZZF2L. ZBLL 493 case là một nhánh một-look nâng cao riêng, không được gắn nhãn là đã bao gồm trong bộ 28 case này.
- **Petrus chuẩn:** 7 OCLL + 21 PLL (lộ trình Last Layer hai bước), bên cạnh hướng dẫn block 2×2×2, mở rộng 2×2×3, EO và hoàn thiện F2L.

Mỗi case công thức có sơ đồ SVG được tạo từ cube move engine, tên/nhóm, hướng nhận diện, hướng cầm, công thức đầy đủ, tips, lỗi thường gặp, ghi chú cá nhân, sửa công thức, thêm công thức thay thế đã tự kiểm chứng, đánh dấu yêu thích/đã thuộc, Trainer và mô phỏng 3D. Các bước trực quan có hình mục tiêu, giải thích nhận diện, hướng cầm và tips; không tạo công thức giả cho blockbuilding, EO hoặc Cross.

**Giới hạn thuật toán được nêu rõ:** Beginner không có bộ case đóng cho mọi tình huống Cross và insertion trực quan. Roux blockbuilding không phải tập thuật toán hữu hạn; Roux formula library ở đây gồm CMLL 42 và LSE 15. ZZ/Petrus cung cấp bộ Last Layer hai bước OCLL+PLL 28 case mỗi phương pháp; ZBLL 493 không được tuyên bố đã có.

## Giữ dữ liệu & tương thích

- LocalStorage key vẫn là `rubik-universe-v1`; dữ liệu cũ không bị xóa hay thay khóa.
- Tiến độ case mới được thêm bằng ID riêng trong `caseProgress`; không ghi đè các CFOP case cũ.
- Service Worker dùng cache `rubik-universe-v11-0` và precache `src/methods-data.js`.
- Timer, scramble 11 puzzle, bộ lọc Statistics, Solver 3×3, Visualizer, Trainer và CFOP Academy tiếp tục được giữ.

## Chạy local trên Windows

1. Giải nén `Rubik-Universe-V11.zip`.
2. Mở Terminal trong thư mục có `index.html`.
3. Chạy `py -m http.server 8080`.
4. Mở `http://localhost:8080`.

Không mở bằng `file://`; ứng dụng dùng ES Modules, Worker và Service Worker.

## Cập nhật GitHub Pages

1. Mở `.github/workflows/deploy-pages.yml` trong repository hiện tại và thay bằng workflow V11 trong Upload Kit; commit workflow trước.
2. Tải `Rubik-Universe-V11.zip` lên thư mục gốc repository rồi commit.
3. Vào Actions, đợi workflow hoàn tất thành công.
4. Mở URL Pages cũ và nhấn `Ctrl + Shift + R`. Không cần repository mới nếu Pages đã dùng GitHub Actions.

## Kiểm thử

Chạy `npm test` (Node.js 18+). Các test xác minh counts, notation, metadata, hình SVG, tabs/trainer và offline precache. Kiểm thử tự động không thay thế việc thử đầy đủ giao diện trên Chrome/Edge và đối chiếu từng case trên cube thật.

## Nguồn dữ liệu thuật toán

Các nguồn tham khảo cụ thể được trỏ trực tiếp trong `src/methods-data.js`: Yasin Alev beginner algorithms; HCubist CMLL, LSE và 2-Look OLL/PLL; Cube Tools method overview; tài liệu ZZ method. Thuật toán thay thế cá nhân chỉ lưu khi người dùng chủ động nhập, không tự sinh dữ liệu không kiểm chứng.

Dữ liệu solve/session/thuật toán/tiến độ vẫn nằm trong LocalStorage của trình duyệt. Hãy xuất backup JSON trước khi cập nhật lớn hoặc đổi thiết bị.
