# Cập nhật Rubik Universe V11 lên GitHub Pages

## V11 gồm những gì?

V11 được phát triển trực tiếp trên mã nguồn V9, giữ nguyên các trang Timer, Scramble Center, Statistics, Sessions, Solver, Visualizer, CFOP 119 case, Trainer, Academy và cấu trúc lưu dữ liệu LocalStorage `rubik-universe-v1`.

Trang **Thư viện thuật toán** được mở rộng với các thư viện riêng:

- **CFOP chuẩn:** 41 F2L, 57 OLL, 21 PLL. Khu **2-Look OLL/PLL** nằm riêng bên trong CFOP (10 OLL + 6 PLL).
- **Công thức cá nhân:** tiếp tục lưu các công thức do người dùng tự thêm.
- **Beginner chuẩn:** lộ trình 7 bước và 8 công thức cốt lõi. Cross là bước trực quan; không có một tập case Cross đóng duy nhất.
- **Roux chuẩn:** 42 CMLL + 15 LSE (11 EO + 4 permutation). First Block/Second Block là blockbuilding trực quan, không có tập công thức hữu hạn duy nhất.
- **ZZ chuẩn:** 7 OCLL + 21 PLL cho lộ trình Last Layer hai bước; có hướng dẫn EOCross/EOLine và ZZF2L. ZBLL là nhánh nâng cao riêng, chưa nhập bộ 493 case.
- **Petrus chuẩn:** 7 OCLL + 21 PLL cho lộ trình hai bước; có hướng dẫn 2×2×2, 2×2×3, EO và F2L.

Mỗi case công thức có hình SVG tạo từ cube move engine, tên/nhóm, mô tả nhận diện, hướng cầm, công thức, tips, lỗi thường gặp, ghi chú cá nhân, sửa công thức, thêm biến thể đã tự kiểm chứng, yêu thích/đã thuộc, Trainer và Visualizer. Các bước trực quan có sơ đồ mục tiêu thay vì công thức giả.

## Cập nhật repository hiện tại

Không cần tạo repository mới. Thực hiện với repository `Rubik-A-Z` đang dùng.

1. Giải nén **GitHub Upload Kit V11** trên máy tính.
2. Trong repository, mở `.github/workflows/deploy-pages.yml`, chọn Edit và thay toàn bộ nội dung bằng file cùng đường dẫn trong gói V11. Commit workflow trước.
3. Quay lại tab **Code** → **Add file** → **Upload files**. Tải file `Rubik-Universe-V11.zip` (nằm trong gói Upload Kit) lên thư mục gốc repository, rồi commit. Không đổi tên ZIP và không đặt trong thư mục con.
4. Mở **Actions**. Đợi workflow `Publish Rubik Universe to GitHub Pages` hoàn tất thành công.
5. Mở URL Pages cũ và nhấn `Ctrl + Shift + R`.

Nếu Pages đã đặt **Settings → Pages → Build and deployment → Source → GitHub Actions**, không cần cấu hình lại. Workflow mới vẫn nhận các ZIP V9/V8/V6–V7/V5.5 cũ làm phương án dự phòng; sau khi upload V11, ZIP V11 sẽ được ưu tiên.

## Kiểm tra trước khi cập nhật

Nên xuất backup JSON trong mục Settings trước khi cập nhật. V11 giữ nguyên khóa `rubik-universe-v1` và chỉ thêm các ID tiến độ mới; không chủ động xóa dữ liệu cũ. Khi đổi thiết bị hoặc trình duyệt, LocalStorage không tự đồng bộ.

## Chạy thử trên máy tính

Cần Node.js 18+ để chạy test:

```bash
npm test
```

Để mở website, chạy server tĩnh trong thư mục có `index.html`:

```bash
py -m http.server 8080
```

Sau đó mở `http://localhost:8080`. Không mở trực tiếp qua `file://` vì website dùng ES Modules, Worker và Service Worker.

## Lưu ý về phạm vi công thức

- Beginner Cross và các bước Roux/Petrus/ZZ dạng blockbuilding hoặc EO phụ thuộc trạng thái và cách dựng; chúng được mô tả bằng mục tiêu, nhận diện và tips, không thể liệt kê thành một tập thuật toán chuẩn hữu hạn.
- Roux có 42 CMLL và 15 LSE trong bản này.
- ZZ/Petrus hiện cung cấp bộ Last Layer hai bước OCLL + PLL (28 case mỗi phương pháp). ZBLL 493 case hoặc COLL/EPLL là lựa chọn nâng cao riêng, không tuyên bố đã tích hợp.
- Kiểm thử tự động xác minh cấu trúc dữ liệu, notation, SVG, tabs, Trainer và precache; vẫn nên kiểm tra trải nghiệm trên Chrome/Edge thực tế.
